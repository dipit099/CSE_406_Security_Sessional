"""Sponge-style LLM resource-exhaustion project."""
