"""
Smoke tests for the two REAL graded attacks: LoopLLM (white-box) and AutoDoS
(black-box).

Like test_ahnaf_parts.py, these run on CPU with a tiny model and check
CORRECTNESS (parsing, slicing, gradient flow, control flow, plotting, no
crashes), NOT attack strength -- strength needs the 8B on a GPU (Kaggle).

Two groups:
  * no-model tests (always run): JSON repair, stub orchestration, stealth
    metrics, plotting;
  * tiny-model tests (skipped if the model can't be downloaded): marker/slice
    mechanics, a 1-step LoopLLM craft, and tiny end-to-end runs of both
    experiments.

Run:  python tests/test_real_attacks.py
"""

import sys
import os
import json
import tempfile

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
except Exception:
    pass

# ---- local-only torchvision workaround (harmless; we never use torchvision) --
try:
    import transformers.utils.import_utils as _iu
    _iu._torchvision_available = False
    for _m in list(sys.modules):
        if "torchvision" in _m:
            del sys.modules[_m]
except Exception:
    pass

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch

from attacks.autodos.attack import _repair_and_load
from attacks.autodos.local_backend import ChatOutput
from attacks.autodos import run_autodos
from common import stealth
from experiments import plots_attacks as pa

TINY_MODEL = os.environ.get("TEST_MODEL", "HuggingFaceTB/SmolLM2-135M-Instruct")
_results = []


def check(name, cond):
    _results.append((name, bool(cond)))
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}")
    return cond


# ---------------------------------------------------------------------------
# no-model tests
# ---------------------------------------------------------------------------
def test_json_parser():
    print("test_json_parser")
    ok = True
    ok &= _repair_and_load('{"prompt": "hi"}', ["prompt"])["prompt"] == "hi"
    ok &= _repair_and_load('```json\n{"evaluate": "x"}\n```', ["evaluate"])["evaluate"] == "x"
    ok &= _repair_and_load('pre {"a":"b",}', ["a"])["a"] == "b"
    ok &= _repair_and_load('{"prompt":"has QUESTION_{number}"}', ["prompt"])["prompt"].startswith("has")
    fail1 = fail2 = False
    try:
        _repair_and_load('{"foo":"bar"}', ["prompt"])
    except ValueError:
        fail1 = True
    try:
        _repair_and_load('not json', ["prompt"])
    except ValueError:
        fail2 = True
    check("json_parser: valid + fenced + repair", ok)
    check("json_parser: rejects bad input", fail1 and fail2)


class _StubBackend:
    """Canned valid JSON per role; target fills the window on the 2nd call."""
    def __init__(self):
        self.target_calls = 0

    def chat(self, system, user, max_new_tokens=1024, temperature=0.0, top_p=1.0):
        if "Deconstruct the problem to form" in system:
            return ChatOutput(json.dumps({"total_prompt": "CPX",
                              "subtask_question": [f"s{i}" for i in range(3)]}),
                              10, 10, 0.0, False)
        if "Enhance the given question" in system:
            return ChatOutput(json.dumps({"prompt": "EXP"}), 10, 10, 0.0, False)
        if "design logical prompt statements" in system:
            return ChatOutput(json.dumps({"improvement": "i", "Prepare_prompt": "P<",
                              "Post_prompt": ">Q"}), 10, 10, 0.0, False)
        if "Judge agent" in system:
            return ChatOutput(json.dumps({"evaluate": "e"}), 10, 10, 0.0, False)
        self.target_calls += 1
        if self.target_calls == 1:
            return ChatOutput("short", 100, 20, 0.1, False)
        return ChatOutput("x " * 60, 100, 96, 0.5, True)


def test_stub_orchestration():
    print("test_stub_orchestration")
    b = _StubBackend()
    res = run_autodos(b, b, function_descript="demo", n_question=3,
                      question_length=50, n_streams=1, n_iterations=3,
                      target_max_n_tokens=100, attack_max_new_tokens=64,
                      attempts=2, verbose=False)
    check("stub: no fallback with valid JSON", res.used_fallback is False)
    check("stub: uses model total_prompt", res.total_prompt == "CPX")
    check("stub: 3 QUESTION blocks", res.general_prompt.count("<QUESTION_") == 3)
    check("stub: attack = Prepare + general + Post",
          res.attack_prompt.startswith("P<") and res.attack_prompt.endswith(">Q"))
    check("stub: early-return on window fill",
          res.succeeded and res.best_output_tokens == 96)


def test_stealth_metrics():
    print("test_stealth_metrics")
    loop = "* * * * * * * * * * * * * * * *"
    prose = "The quick brown fox jumps over the lazy dog near the riverbank."
    check("compression: loop >> prose",
          stealth.compression_ratio(loop) > stealth.compression_ratio(prose))
    check("ncd: identical ~ 0", stealth.ncd(prose, prose) < 0.3)
    check("ncd: different > identical",
          stealth.ncd(prose, loop) > stealth.ncd(prose, prose))


def test_plots():
    print("test_plots")
    loop = {"measure_ceiling": 4096, "baseline_normal_avg_len": 200.0,
            "baseline_normal_asr": 0.0, "baseline_naive": {"out_tokens": 600},
            "variants": [{"c": 1, "label": "LoopLLM-t", "avg_out_tokens": 3900.0, "asr": 0.94},
                         {"c": 5, "label": "LoopLLM-p", "avg_out_tokens": 3400.0, "asr": 0.81}],
            "ppl": {"normal": 42.0, "LoopLLM-t": 30.0, "LoopLLM-p": 55.0},
            "defenses": [{"variant": "LoopLLM-t", "l3_killed": True, "l3_out_tokens": 60, "l1_out_tokens": 256},
                         {"variant": "LoopLLM-p", "l3_killed": False, "l3_out_tokens": 3400, "l1_out_tokens": 256}]}
    autod = {"target_max_n_tokens": 8192, "benign": {"out_tokens": 120},
             "attack": {"out_tokens": 8192},
             "amplification": {"length_x": 68.0, "latency_x": 250.0},
             "defenses": {"l2_blocked": False, "l3_killed": False,
                          "l3_out_tokens": 8192, "l1_out_tokens": 256}}
    d = tempfile.mkdtemp()
    for fn, res in ((pa.plot_loopllm_lengths, loop), (pa.plot_loopllm_defense, loop),
                    (pa.plot_loopllm_ppl, loop), (pa.plot_autodos_amplification, autod),
                    (pa.plot_autodos_defense, autod)):
        p = os.path.join(d, fn.__name__ + ".png")
        fn(res, p)
        check(f"plot {fn.__name__}", os.path.exists(p) and os.path.getsize(p) > 1000)


# ---------------------------------------------------------------------------
# tiny-model tests
# ---------------------------------------------------------------------------
def _load_tiny():
    from transformers import AutoModelForCausalLM, AutoTokenizer
    tok = AutoTokenizer.from_pretrained(TINY_MODEL)
    model = AutoModelForCausalLM.from_pretrained(TINY_MODEL, dtype=torch.float32).eval()
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    return model, tok


def test_loopllm_slices(tok):
    print("test_loopllm_slices")
    from attacks import loopllm
    from attacks.loopllm import optimize as O
    for c in (1, 5):
        cyc = loopllm.attack._marker_ids(tok, c)
        sm = O.SuffixManager(tok, "Explain gravity.", cyc, adv_len=12, chat=True)
        ctrl = sm.get_input_ids().tolist()[sm._control_slice]
        check(f"slice c={c}: len==adv_len and all cyclic",
              len(ctrl) == 12 and all(t in set(cyc) for t in ctrl))


def test_loopllm_craft(model, tok):
    print("test_loopllm_craft")
    from attacks import loopllm
    res = loopllm.craft_suffix(model, tok, "Explain gravity.", c=1, adv_len=10,
                               steps=1, topk=32, num_candidate=16,
                               once_forward_batch=4, fitness_ceiling=16,
                               chat=True, verbose=False, seed=0)
    check("craft: returns a suffix", isinstance(res.suffix_text, str) and len(res.suffix_ids) > 0)
    check("craft: recorded a loss", len(res.loss_curve) == 1 and res.loss_curve[0] == res.loss_curve[0])


def test_loopllm_experiment(model, tok):
    print("test_loopllm_experiment (per_input + sampled ASR)")
    from experiments import exp_loopllm
    r = exp_loopllm.run_loopllm(model, tok, c_values=(1,), craft_mode="per_input",
                                adv_len=8, craft_steps=1, craft_fitness_ceiling=16,
                                measure_ceiling=24, topk=32, num_candidate=16,
                                once_forward_batch=4, asr_samples=3, asr_prompts=1,
                                test_instructions=["What is 2+2?", "Name a color."],
                                verbose=False)
    json.dumps(r)
    v = r["variants"][0]
    ok = ("variants" in r and "defenses" in r and "ppl" in r
          and r["craft_mode"] == "per_input" and len(v["suffixes"]) == 2
          and "asr_sampled_rate" in v
          and any("sampled_success_rate" in p for p in v["per_prompt"]))
    check("loopllm per_input exp: modes + sampled ASR + serialisable", ok)


def test_loopllm_modes(model, tok):
    print("test_loopllm_modes (reuse + universal)")
    from experiments import exp_loopllm
    for mode in ("reuse", "universal"):
        r = exp_loopllm.run_loopllm(
            model, tok, c_values=(1,), craft_mode=mode, adv_len=8, craft_steps=1,
            craft_fitness_ceiling=16, measure_ceiling=24, topk=32, num_candidate=16,
            once_forward_batch=4, asr_samples=1,
            test_instructions=["What is 2+2?", "Name a color."],
            universal_train=["Explain gravity.", "Describe rain."], verbose=False)
        json.dumps(r)
        check(f"loopllm mode={mode}: runs + serialisable",
              r["craft_mode"] == mode and len(r["variants"][0]["suffixes"]) == 2)


def test_autodos_experiment(model, tok):
    print("test_autodos_experiment")
    from experiments import exp_autodos
    r = exp_autodos.run_autodos_experiment(
        model, tok, function_descript="demo", n_question=2, question_length=30,
        n_streams=1, n_iterations=1, target_max_n_tokens=24,
        attack_max_new_tokens=48, attempts=1, verbose=False)
    json.dumps(r)
    check("autodos exp: keys + serialisable",
          "amplification" in r and "stealth" in r and "defenses" in r)


def main():
    print("=" * 60, "\nNO-MODEL TESTS\n", "=" * 60, sep="")
    test_json_parser()
    test_stub_orchestration()
    test_stealth_metrics()
    test_plots()

    print("=" * 60, "\nTINY-MODEL TESTS\n", "=" * 60, sep="")
    try:
        model, tok = _load_tiny()
    except Exception as e:
        print(f"  [SKIP] could not load {TINY_MODEL} ({e}); skipping model tests")
        model = None
    if model is not None:
        test_loopllm_slices(tok)
        test_loopllm_craft(model, tok)
        test_loopllm_experiment(model, tok)
        test_loopllm_modes(model, tok)
        test_autodos_experiment(model, tok)

    print("=" * 60)
    n_pass = sum(1 for _, ok in _results if ok)
    n_total = len(_results)
    print(f"RESULT: {n_pass}/{n_total} checks passed")
    failed = [n for n, ok in _results if not ok]
    if failed:
        print("FAILED:", failed)
        sys.exit(1)
    print("ALL CHECKS PASSED")


if __name__ == "__main__":
    main()
