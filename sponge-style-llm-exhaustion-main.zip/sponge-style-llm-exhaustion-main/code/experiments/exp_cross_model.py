"""
Experiment: cross-model check (Qwen2.5-0.5B-Instruct vs Qwen3-0.6B).

Owner: DIPIT.  ***STUB — to be implemented.***

Show the attack direction holds on a newer model. For each model, measure the
amplification of a crafted sponge over a natural baseline (output tokens /
latency). For Qwen3, run with thinking mode OFF (enable_thinking=False) so the
comparison is about the sponge, not the thinking tokens.

Use:
    model, tok = model_utils.load_model_and_tokenizer(name, enable_thinking=...)
    then metrics.measure_prompt(...) for natural vs crafted.

Report both models' numbers honestly. The point (from the report) is that a
newer model does not remove the lever; it is not to claim a specific factor.

Model names live in common.config: MODEL_NAME and ALT_MODEL_NAME.

Grounding: design report Section 7 (cross-model note).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from common import model_utils, metrics, config
from attacks import tier1_baselines as t1


DEFAULT_NATURAL_PROMPT = "What is the capital of France?"


@dataclass
class CrossModelRow:
    model_name: str
    natural_out_tokens: int
    sponge_out_tokens: int
    out_amp: float
    natural_latency_s: float
    sponge_latency_s: float
    latency_amp: float


def run_cross_model(sponge_prompt=None, natural_prompt=DEFAULT_NATURAL_PROMPT,
                    ceiling=256, model_names=None) -> List[CrossModelRow]:
    """
    Measure a crafted sponge's amplification over a natural baseline on each of
    two models (default: config.MODEL_NAME and config.ALT_MODEL_NAME), showing
    the lever still works on a newer model.

    Qwen3 is loaded with enable_thinking=False so the comparison is about the
    sponge, not thinking tokens. Each model is loaded, measured, and released
    before the next, so this runs on modest memory.
    """
    if sponge_prompt is None:
        sponge_prompt = t1.output_forcing_prompt()
    names = model_names or [config.MODEL_NAME, config.ALT_MODEL_NAME]

    rows = []
    for name in names:
        config.set_seed()
        model, tok = model_utils.load_model_and_tokenizer(
            name, enable_thinking=False)
        natural = metrics.measure_prompt(model, tok, natural_prompt,
                                         max_new_tokens=ceiling)
        sponge = metrics.measure_prompt(model, tok, sponge_prompt,
                                        max_new_tokens=ceiling)
        rows.append(CrossModelRow(
            model_name=name,
            natural_out_tokens=natural.out_tokens,
            sponge_out_tokens=sponge.out_tokens,
            out_amp=metrics.amplification(sponge.out_tokens, natural.out_tokens),
            natural_latency_s=natural.latency_s,
            sponge_latency_s=sponge.latency_s,
            latency_amp=metrics.amplification(sponge.latency_s, natural.latency_s),
        ))

        # free the model before loading the next one
        del model
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass

    return rows


def print_table(rows: List[CrossModelRow]):
    print(f"\n{'Model':28s} {'Nat tok':>7s} {'Spng tok':>8s} {'Out x':>6s} "
          f"{'Lat x':>6s}")
    print("-" * 60)
    for r in rows:
        print(f"{r.model_name:28s} {r.natural_out_tokens:7d} "
              f"{r.sponge_out_tokens:8d} {r.out_amp:5.1f}x {r.latency_amp:5.1f}x")


def main():
    rows = run_cross_model()
    print_table(rows)
    return rows


if __name__ == "__main__":
    main()
