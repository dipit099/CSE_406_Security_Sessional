"""
Experiment: latency vs output length sweep.

Owner: DIPIT.  ***STUB — to be implemented.***

Show that per-request cost grows with output length (the lever). Force the
model to produce a target number of tokens for lengths in, e.g.,
[16, 32, 64, 128, 256, 512] and record latency, energy, and GPU memory at each.
The simplest honest way is to set max_new_tokens = L and min_new_tokens = L (or
use a prompt that reliably runs to the cap) so the measured length matches L.

Use common.metrics.measure_generation for each length. Produce a small table
and (optionally) note that latency rises roughly linearly with L while KV-cache
memory also grows.

Grounding: design report Section 2 (cost is set by output tokens) and the
latency-vs-length sweep described in the implementation plan.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from common import model_utils, metrics, config
from attacks import tier1_baselines as t1


@dataclass
class SweepRow:
    target_len: int
    out_tokens: int
    latency_s: float
    energy_j: Optional[float]
    gpu_mem_mb: Optional[float]


def run_length_sweep(model, tokenizer,
                     lengths=(16, 32, 64, 128, 256, 512)) -> List[SweepRow]:
    """
    Force the model to produce ~L tokens for each L in `lengths` and record the
    cost, showing that per-request cost grows with output length (the lever).

    We drive generation with the Tier-1 output_forcing_prompt (which reliably
    runs long) and cap max_new_tokens = L, so the model is cut off at exactly L
    tokens and the measured length matches the target. Cost is measured through
    the shared metrics harness so numbers are comparable with the other tables.
    """
    eos_ids = model_utils.get_eos_ids(tokenizer, model)
    input_ids = model_utils.build_chat_prompt(
        tokenizer, t1.output_forcing_prompt(),
        enable_thinking=getattr(model, "_enable_thinking", False),
    )

    rows = []
    for L in lengths:
        m = metrics.measure_generation(model, tokenizer, input_ids,
                                       max_new_tokens=L, eos_ids=eos_ids)
        rows.append(SweepRow(target_len=L, out_tokens=m.out_tokens,
                             latency_s=m.latency_s, energy_j=m.energy_j,
                             gpu_mem_mb=m.gpu_mem_mb))
    return rows


def print_table(rows: List[SweepRow]):
    print(f"\n{'Target L':>8s} {'Out tok':>7s} {'Latency(s)':>11s} "
          f"{'ms/token':>9s} {'GPU MB':>8s}")
    print("-" * 48)
    for r in rows:
        ms_per_tok = 1000 * r.latency_s / r.out_tokens if r.out_tokens else 0.0
        gpu = f"{r.gpu_mem_mb:8.0f}" if r.gpu_mem_mb is not None else "     n/a"
        print(f"{r.target_len:8d} {r.out_tokens:7d} {r.latency_s:11.3f} "
              f"{ms_per_tok:9.1f} {gpu}")

    # A one-line linearity note: compare ms/token at the shortest vs longest L.
    valid = [r for r in rows if r.out_tokens]
    if len(valid) >= 2:
        first = 1000 * valid[0].latency_s / valid[0].out_tokens
        last = 1000 * valid[-1].latency_s / valid[-1].out_tokens
        print(f"\nms/token stays ~flat ({first:.1f} -> {last:.1f}) => latency "
              f"scales roughly linearly with output length.")


def main():
    config.set_seed()
    model, tokenizer = model_utils.load_model_and_tokenizer()
    rows = run_length_sweep(model, tokenizer)
    print_table(rows)
    return rows


if __name__ == "__main__":
    main()
