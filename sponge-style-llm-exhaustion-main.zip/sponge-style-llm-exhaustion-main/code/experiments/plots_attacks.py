"""
Plots for the two real attacks (LoopLLM white-box, AutoDoS black-box).

Owner: Ahnaf.

Each function takes an experiment results dict (from exp_loopllm.run_loopllm or
exp_autodos.run_autodos_experiment) and returns a matplotlib Figure, saving a
PNG when `save_path` is given. Colours reuse the project palette from plots.py
(attack = red, honest = green, neutral = blue) so every figure in the report
reads the same way.

Figures:
  LoopLLM
    plot_loopllm_lengths   : avg output length + ASR, baselines vs -t / -p
    plot_loopllm_defense   : output tokens with no defense vs L3 vs L1
    plot_loopllm_ppl       : input PPL, normal vs crafted (PPL-filter evasion)
  AutoDoS
    plot_autodos_amplification : output tokens benign vs AutoDoS (+ latency x)
    plot_autodos_defense       : output tokens no-defense vs L3 vs L1
  Shared
    plot_stealth_ppl       : generic PPL bar for either attack
"""

from __future__ import annotations

from typing import Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from .plots import ATTACK, HONEST, NEUTRAL, GREY, _save


# ---------------------------------------------------------------------------
# LoopLLM
# ---------------------------------------------------------------------------
def plot_loopllm_lengths(results, save_path: Optional[str] = None):
    """Average output length for normal / naive / each LoopLLM variant, with ASR
    printed above each bar. Reproduces the shape of LoopLLM Table 1."""
    ceiling = results["measure_ceiling"]
    labels = ["normal", "naive\nforcing"]
    vals = [results["baseline_normal_avg_len"],
            results["baseline_naive"]["out_tokens"]]
    annos = [f"ASR\n{results['baseline_normal_asr']:.0%}",
             f"ASR\n{1.0 if results['baseline_naive']['out_tokens'] >= ceiling else 0.0:.0%}"]
    colors = [HONEST, GREY]
    for v in results["variants"]:
        labels.append(v["label"])
        vals.append(v["avg_out_tokens"])
        # show greedy ASR, plus sampled ASR in parentheses when available
        a = f"ASR\n{v['asr']:.0%}"
        if v.get("asr_sampled_rate"):
            a += f"\n(smp {v['asr_sampled_rate']:.0%})"
        annos.append(a)
        colors.append(ATTACK)

    fig, ax = plt.subplots(figsize=(7, 4.2))
    bars = ax.bar(labels, vals, color=colors)
    ax.axhline(ceiling, ls="--", color=GREY, lw=1)
    ax.text(len(labels) - 0.4, ceiling, f" ceiling={ceiling}", va="bottom",
            ha="right", color=GREY, fontsize=8)
    for b, anno in zip(bars, annos):
        ax.text(b.get_x() + b.get_width() / 2, b.get_height(),
                anno, ha="center", va="bottom", fontsize=8)
    ax.set_ylabel("avg output tokens")
    ax.set_title("LoopLLM: output length vs baselines")
    ax.set_ylim(0, ceiling * 1.18)
    return _save(fig, save_path)


def plot_loopllm_defense(results, save_path: Optional[str] = None):
    """Grouped bars per variant: no defense vs single-token monitor vs n-gram
    monitor vs L1 cap. The single-token monitor (LoopLLM Table 3) should catch
    LoopLLM-t but be EVADED by a genuine phrase-level LoopLLM-p; the n-gram
    monitor catches both; L1 always bounds it."""
    variants = results["variants"]
    defs = {d["variant"]: d for d in results["defenses"]}
    names = [v["label"] for v in variants]
    no_def = [v["avg_out_tokens"] for v in variants]
    single = [defs[v["label"]].get("l3_singletoken_out_tokens",
              defs[v["label"]]["l3_out_tokens"]) for v in variants]
    ngram = [defs[v["label"]]["l3_out_tokens"] for v in variants]
    l1v = [defs[v["label"]]["l1_out_tokens"] for v in variants]

    x = range(len(names))
    w = 0.2
    fig, ax = plt.subplots(figsize=(7.5, 4.3))
    ax.bar([i - 1.5 * w for i in x], no_def, w, label="no defense", color=ATTACK)
    ax.bar([i - 0.5 * w for i in x], single, w, label="L3 single-token monitor",
           color="#E67E22")
    ax.bar([i + 0.5 * w for i in x], ngram, w, label="L3 n-gram monitor", color=NEUTRAL)
    ax.bar([i + 1.5 * w for i in x], l1v, w, label="L1 output cap", color=HONEST)
    for i, v in enumerate(variants):
        d = defs[v["label"]]
        if d.get("l3_singletoken_killed"):
            ax.text(i - 0.5 * w, single[i], "kill", ha="center", va="bottom", fontsize=7)
        if d["l3_killed"]:
            ax.text(i + 0.5 * w, ngram[i], "kill", ha="center", va="bottom", fontsize=7)
    ax.set_xticks(list(x))
    ax.set_xticklabels(names)
    ax.set_ylabel("output tokens")
    ax.set_title("LoopLLM under defenses")
    ax.legend(fontsize=7)
    return _save(fig, save_path)


def plot_loopllm_ppl(results, save_path: Optional[str] = None):
    return plot_stealth_ppl(results["ppl"], title="LoopLLM: input perplexity "
                            "(a PPL filter rejects HIGH-PPL inputs)", save_path=save_path)


# ---------------------------------------------------------------------------
# AutoDoS
# ---------------------------------------------------------------------------
def plot_autodos_amplification(results, save_path: Optional[str] = None):
    """Output tokens benign vs AutoDoS, with the latency amplification annotated
    (AutoDoS Table 2: 250x+ latency)."""
    benign = results["benign"].get("avg_out_tokens", results["benign"]["out_tokens"])
    attack = results["attack"]["out_tokens"]
    ceiling = results["target_max_n_tokens"]
    fig, ax = plt.subplots(figsize=(5.5, 4.2))
    bars = ax.bar(["benign", "AutoDoS"], [benign, attack], color=[HONEST, ATTACK])
    ax.axhline(ceiling, ls="--", color=GREY, lw=1)
    ax.text(-0.45, ceiling, f"window={ceiling}", va="bottom", ha="left",
            color=GREY, fontsize=8)
    ax.set_ylim(0, ceiling * 1.28)   # headroom so the amp annotation clears the line
    amp = results["amplification"]
    anno = f"{amp['length_x']}x len\n{amp['latency_x']}x latency"
    if amp.get("energy_x"):
        anno += f"\n{amp['energy_x']}x energy"
    ax.text(bars[1].get_x() + bars[1].get_width() / 2, attack, anno,
            ha="center", va="bottom", fontsize=9)
    ax.set_ylabel("output tokens")
    ax.set_title("AutoDoS: output length amplification")
    return _save(fig, save_path)


def plot_autodos_defense(results, save_path: Optional[str] = None):
    """Output tokens: AutoDoS with no defense vs L3 vs L1, plus whether L2 input
    validation blocked it (it should not -- AutoDoS is fluent text)."""
    d = results["defenses"]
    vals = [results["attack"]["out_tokens"], d["l3_out_tokens"], d["l1_out_tokens"]]
    labels = ["no defense", "L3 repeat\nmonitor", "L1 output\ncap"]
    colors = [ATTACK, NEUTRAL, HONEST]
    fig, ax = plt.subplots(figsize=(6, 4.2))
    ax.bar(labels, vals, color=colors)
    if d["l3_killed"]:
        ax.text(1, d["l3_out_tokens"], " killed", ha="center", va="bottom",
                fontsize=8, color=NEUTRAL)
    else:
        ax.text(1, d["l3_out_tokens"], " not killed\n(no tight loop)", ha="center",
                va="bottom", fontsize=8, color=NEUTRAL)
    blocked = d["l2_blocked"]
    ax.set_title(f"AutoDoS under defenses  (L2 input-filter blocked: {blocked})")
    ax.set_ylabel("output tokens")
    return _save(fig, save_path)


# ---------------------------------------------------------------------------
# shared
# ---------------------------------------------------------------------------
def plot_stealth_ppl(ppl_dict, title="input perplexity", save_path=None):
    """Bar of input PPL per label; the normal row is green, crafted rows red."""
    items = [(k, v) for k, v in ppl_dict.items() if v is not None]
    labels = [k for k, _ in items]
    vals = [v for _, v in items]
    colors = [HONEST if k.lower().startswith(("normal", "benign")) else ATTACK
              for k in labels]
    fig, ax = plt.subplots(figsize=(5.5, 4))
    ax.bar(labels, vals, color=colors)
    ax.set_ylabel("perplexity (PPL)")
    ax.set_title(title)
    return _save(fig, save_path)
