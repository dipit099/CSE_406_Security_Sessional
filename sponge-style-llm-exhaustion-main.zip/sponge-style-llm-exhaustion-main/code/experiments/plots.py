"""
Plotting helpers for the results in Ahnaf's half.

Owner: Ahnaf.

Every function takes already-computed data and returns a matplotlib Figure,
saving a PNG if `save_path` is given. They are safe to call in a Kaggle
notebook (call plt.show() after) or headless (Agg backend, just saved).

Figures provided:
  * plot_engorgio_curve  : EOS probability driven down + self-mentor loss vs iter
  * plot_ga_progress     : best / mean output tokens per GA generation
  * plot_queue_dos       : honest-user latency and slowdown vs queued sponges
  * plot_roc             : ROC curve for the L5 latent detector
  * plot_latent_pca      : 2-D PCA of hidden-state features, benign vs sponge
  * plot_tokens_per_char : L2's tokenizer-abuse fingerprint, benign vs sponge

Colours follow the report's palette: benign/honest = green, attack/sponge = red.
"""

from __future__ import annotations

from typing import List, Optional, Sequence

import numpy as np

import matplotlib
matplotlib.use("Agg")  # safe default; notebooks can still display the figure
import matplotlib.pyplot as plt

ATTACK = "#C0392B"   # red
HONEST = "#1E8449"   # green
NEUTRAL = "#1F618D"  # blue
GREY = "#566573"


def _save(fig, save_path):
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


# ---------------------------------------------------------------------------
# Tier 2b: Engorgio optimisation curve
# ---------------------------------------------------------------------------
def plot_engorgio_curve(history: List[dict], save_path: Optional[str] = None):
    """
    history: list of {'iter','loss','self_mentor','eos_prob_sum'} from
    EngorgioAttack.fit(). Shows EOS probability (the thing we suppress) falling,
    with the self-mentor loss on a second axis.
    """
    it = [h["iter"] for h in history]
    eos = [h["eos_prob_sum"] for h in history]
    sm = [h["self_mentor"] for h in history]

    fig, ax1 = plt.subplots(figsize=(6.5, 4))
    ax1.plot(it, eos, color=ATTACK, lw=2, label="EOS probability (summed)")
    ax1.set_xlabel("optimisation step")
    ax1.set_ylabel("summed P(EOS) over positions", color=ATTACK)
    ax1.tick_params(axis="y", labelcolor=ATTACK)

    ax2 = ax1.twinx()
    ax2.plot(it, sm, color=NEUTRAL, lw=1.5, ls="--", label="self-mentor loss")
    ax2.set_ylabel("self-mentor loss", color=NEUTRAL)
    ax2.tick_params(axis="y", labelcolor=NEUTRAL)

    ax1.set_title("Tier 2b (Engorgio): driving EOS probability down")
    fig.tight_layout()
    return _save(fig, save_path)


def plot_engorgio_discrete(eval_history: List[dict], best_out_tokens=None,
                           cap=None, save_path: Optional[str] = None):
    """
    eval_history: list of {'iter','out_tokens'} -- the REAL greedy output length
    of the discretised trigger measured during optimisation. This is the honest
    attack strength (the soft EOS curve is only the surrogate objective). The
    star marks the strongest trigger, which is the one the attack returns.
    """
    it = [h["iter"] for h in eval_history]
    out = [h["out_tokens"] for h in eval_history]

    fig, ax = plt.subplots(figsize=(6.5, 4))
    ax.plot(it, out, color=ATTACK, lw=2, marker="o",
            label="discrete trigger output length")
    if cap:
        ax.axhline(cap, color=GREY, ls="--", lw=1.2,
                   label=f"generation cap = {cap}")
    if best_out_tokens is not None and out:
        bi = int(np.argmax(out))
        ax.scatter([it[bi]], [out[bi]], color=NEUTRAL, s=140, marker="*",
                   zorder=5, label=f"selected best = {best_out_tokens}")
    ax.set_xlabel("optimisation step")
    ax.set_ylabel("real output tokens (greedy)")
    ax.set_title("Tier 2b: real strength of the discretised trigger")
    ax.legend()
    fig.tight_layout()
    return _save(fig, save_path)


# ---------------------------------------------------------------------------
# Tier 2a: GA progress
# ---------------------------------------------------------------------------
def plot_ga_progress(history: List[dict], save_path: Optional[str] = None):
    """
    history: list of {'generation','best','mean','overall_best','frac_at_cap',
    'cap'} from GA.fit(). Plots best and pool-mean output length. When the cap
    is known and candidates reach it, the `best` line pins to the cap and is
    uninformative on its own, so we add the fraction of the pool at the cap on a
    second axis -- that rising fraction is the visible sign of selection pressure.
    """
    gen = [h["generation"] for h in history]
    best = [h["best"] for h in history]
    mean = [h["mean"] for h in history]
    has_frac = all(h.get("frac_at_cap") is not None for h in history)

    fig, ax = plt.subplots(figsize=(6.5, 4))
    ax.plot(gen, best, color=ATTACK, lw=2, marker="o", label="best in generation")
    ax.plot(gen, mean, color=GREY, lw=1.5, ls="--", marker="s", label="pool mean")
    ax.set_xlabel("generation")
    ax.set_ylabel("output tokens (fitness)")
    ax.set_title("Tier 2a (genetic algorithm): output length over generations")

    if has_frac:
        frac = [100.0 * h["frac_at_cap"] for h in history]
        ax2 = ax.twinx()
        ax2.plot(gen, frac, color=HONEST, lw=1.5, ls=":", marker="^",
                 label="% of pool at cap")
        ax2.set_ylabel("% of pool at generation cap", color=HONEST)
        ax2.tick_params(axis="y", labelcolor=HONEST)
        ax2.set_ylim(0, 105)
        lines1, labels1 = ax.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax.legend(lines1 + lines2, labels1 + labels2, loc="lower right")
    else:
        ax.legend()

    fig.tight_layout()
    return _save(fig, save_path)


# ---------------------------------------------------------------------------
# Multi-model comparison: convergence curves overlaid across models
# ---------------------------------------------------------------------------
_MM_COLORS = ["#C0392B", "#1F618D", "#1E8449", "#B7950B", "#7D3C98",
             "#D35400", "#17A2B8", "#566573", "#922B21", "#2874A6"]


def plot_multimodel_ga_progress(histories: dict, save_path: Optional[str] = None):
    """
    histories: {model_key: {"ga": [...GA history...], ...}} from
    exp_multimodel.run_multimodel(). One line per model of best-fitness vs
    generation, so the GA's convergence is visible per model, not just the
    final number in multimodel.csv.
    """
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for i, (key, h) in enumerate(histories.items()):
        hist = h.get("ga") or []
        if not hist:
            continue
        gen = [r["generation"] for r in hist]
        best = [r["best"] for r in hist]
        color = _MM_COLORS[i % len(_MM_COLORS)]
        ax.plot(gen, best, color=color, lw=1.8, marker="o", markersize=3,
                label=key)
    ax.set_xlabel("generation")
    ax.set_ylabel("best output tokens (fitness)")
    ax.set_title("Tier 2a (GA): convergence across models")
    ax.legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    return _save(fig, save_path)


def plot_multimodel_engorgio_discrete(histories: dict, cap=None,
                                      save_path: Optional[str] = None):
    """
    histories: {model_key: {"engorgio_discrete": [...eval history...], ...}}
    from exp_multimodel.run_multimodel() (needs select_by_generation=True,
    which the sweep enables by default). One line per model of the REAL
    discrete-trigger output length vs optimisation step -- the honest curve,
    not the soft-loss surrogate -- so Engorgio's convergence (or lack of it) is
    visible per model side by side.
    """
    fig, ax = plt.subplots(figsize=(7, 4.5))
    any_data = False
    for i, (key, h) in enumerate(histories.items()):
        hist = h.get("engorgio_discrete") or []
        if not hist:
            continue
        any_data = True
        it = [r["iter"] for r in hist]
        out = [r["out_tokens"] for r in hist]
        color = _MM_COLORS[i % len(_MM_COLORS)]
        ax.plot(it, out, color=color, lw=1.8, marker="o", markersize=3,
                label=key)
    if cap:
        ax.axhline(cap, color=GREY, ls="--", lw=1.2, label=f"cap = {cap}")
    ax.set_xlabel("optimisation step")
    ax.set_ylabel("real discrete output tokens (greedy)")
    ax.set_title("Tier 2b (Engorgio): convergence across models")
    if any_data:
        ax.legend(fontsize=8, loc="best")
    fig.tight_layout()
    return _save(fig, save_path)


# ---------------------------------------------------------------------------
# Queue DoS (Table 3)
# ---------------------------------------------------------------------------
def plot_queue_dos(rows, save_path: Optional[str] = None):
    """rows: list of QueueRow (n_sponges, honest_latency_s, slowdown)."""
    ks = [r.n_sponges for r in rows]
    lat = [r.honest_latency_s for r in rows]
    slow = [r.slowdown for r in rows]

    fig, ax1 = plt.subplots(figsize=(6.5, 4))
    bars = ax1.bar([str(k) for k in ks], lat, color=ATTACK, alpha=0.85,
                   label="honest-user latency")
    ax1.set_xlabel("sponge requests queued ahead")
    ax1.set_ylabel("honest-user latency (s)", color=ATTACK)
    ax1.tick_params(axis="y", labelcolor=ATTACK)
    for b, s in zip(bars, slow):
        ax1.text(b.get_x() + b.get_width() / 2, b.get_height(),
                 f"{s:.1f}x", ha="center", va="bottom", fontsize=9, color=GREY)

    ax1.set_title("Denial of service: honest latency behind queued sponges")
    fig.tight_layout()
    return _save(fig, save_path)


# ---------------------------------------------------------------------------
# L5 detector: ROC
# ---------------------------------------------------------------------------
def plot_roc(y_true: Sequence[int], scores: Sequence[float],
             title="L5 latent detector: ROC", save_path: Optional[str] = None):
    from sklearn.metrics import roc_curve, auc as sk_auc
    fpr, tpr, _ = roc_curve(y_true, scores, pos_label=1)
    roc_auc = sk_auc(fpr, tpr)

    fig, ax = plt.subplots(figsize=(5, 5))
    ax.plot(fpr, tpr, color=NEUTRAL, lw=2, label=f"AUC = {roc_auc:.3f}")
    ax.plot([0, 1], [0, 1], color=GREY, lw=1, ls="--", label="chance")
    ax.set_xlabel("false positive rate")
    ax.set_ylabel("true positive rate")
    ax.set_title(title)
    ax.legend(loc="lower right")
    fig.tight_layout()
    return _save(fig, save_path)


# ---------------------------------------------------------------------------
# L5 detector: 2-D PCA of hidden-state features
# ---------------------------------------------------------------------------
def plot_latent_pca(features: np.ndarray, labels: np.ndarray,
                    save_path: Optional[str] = None):
    """features: (N, H) mean-pooled hidden states; labels: 0 benign, 1 sponge."""
    from sklearn.decomposition import PCA
    labels = np.asarray(labels)
    proj = PCA(n_components=2).fit_transform(np.asarray(features))

    fig, ax = plt.subplots(figsize=(6, 5))
    for lab, color, name in [(0, HONEST, "benign"), (1, ATTACK, "sponge")]:
        m = labels == lab
        ax.scatter(proj[m, 0], proj[m, 1], c=color, label=name,
                   alpha=0.7, edgecolors="none")
    ax.set_xlabel("PC 1")
    ax.set_ylabel("PC 2")
    ax.set_title("L5: hidden-state features separate benign from sponge")
    ax.legend()
    fig.tight_layout()
    return _save(fig, save_path)


# ---------------------------------------------------------------------------
# L2: tokens-per-char fingerprint
# ---------------------------------------------------------------------------
def plot_tokens_per_char(benign_texts, sponge_texts, tokenizer,
                         threshold=0.35, save_path: Optional[str] = None):
    def tpc(s):
        n = len(tokenizer.encode(s, add_special_tokens=False))
        return n / len(s) if s else 0.0

    b = [tpc(s) for s in benign_texts]
    a = [tpc(s) for s in sponge_texts]

    fig, ax = plt.subplots(figsize=(6.5, 4))
    bins = np.linspace(0, 1.05, 22)
    ax.hist(b, bins=bins, color=HONEST, alpha=0.7, label="benign")
    ax.hist(a, bins=bins, color=ATTACK, alpha=0.7, label="sponge / abuse")
    ax.axvline(threshold, color=GREY, ls="--", lw=1.5,
               label=f"L2 threshold = {threshold}")
    ax.set_xlabel("tokens per character")
    ax.set_ylabel("count")
    ax.set_title("L2 input validation: tokenizer-abuse fingerprint")
    ax.legend()
    fig.tight_layout()
    return _save(fig, save_path)
