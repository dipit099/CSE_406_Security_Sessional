"""
Experiment: honest-user latency behind k queued sponge requests (Table 3).

Owner: Ahnaf.

This turns "one expensive request" into a measured denial of service. A single
worker thread serves a FIFO queue one request at a time on the GPU, exactly
like the minimal single-worker deployment in the report's topology. We enqueue
k sponge requests followed by one honest request and measure how long the
honest request takes from submission to completion (queue wait + its own run).

Output reproduces the shape of Table 3:
    Sponges queued ahead   0     1     2     3
    Honest-user latency    ...   ...   ...   ...
    Slowdown vs idle       1.0x  ...   ...   ...

No leakage: we simply time real generations. The sponge prompt can be a plain
hand-written output-forcing prompt (default) or the crafted prompt produced by
the Tier-2 attacks; both are accepted so the experiment can be run standalone.
"""

from __future__ import annotations

import time
import queue
import threading
from dataclasses import dataclass
from typing import List, Optional

from common import model_utils, config


# A plain, honest question: short answer, stops early on EOS.
DEFAULT_HONEST_PROMPT = "What is the capital of France?"

# A simple output-forcing sponge: implies a very long answer. This is the
# Tier-1 baseline sponge; swap in a Tier-2 crafted prompt for a stronger one.
DEFAULT_SPONGE_PROMPT = (
    "List every integer from 1 to 100000, one number per line, "
    "with no summary and no early stop."
)


@dataclass
class QueueRow:
    n_sponges: int
    honest_latency_s: float
    slowdown: float


def _make_worker(model, tokenizer, eos_ids, results, done_flags):
    q = queue.Queue()

    def worker():
        while True:
            job = q.get()
            if job is None:
                q.task_done()
                break
            jid, input_ids, ceiling, enq_time = job
            _, n_new = model_utils.generate(
                model, tokenizer, input_ids,
                max_new_tokens=ceiling, eos_ids=eos_ids, greedy=True)
            results[jid] = {"latency": time.time() - enq_time, "out_tokens": n_new}
            q.task_done()

    t = threading.Thread(target=worker, daemon=True)
    return q, t


def run_queue_dos(model, tokenizer, sponge_prompt=DEFAULT_SPONGE_PROMPT,
                  honest_prompt=DEFAULT_HONEST_PROMPT, ks=(0, 1, 2, 3),
                  ceiling=128, verbose=True) -> List[QueueRow]:
    """
    Measure honest-user latency behind each k in `ks`. Returns one QueueRow per
    k. `ceiling` caps every generation (honest still stops early via EOS).
    """
    eos_ids = model_utils.get_eos_ids(tokenizer, model)
    enable_thinking = getattr(model, "_enable_thinking", False)
    sponge_ids = model_utils.build_chat_prompt(tokenizer, sponge_prompt,
                                               enable_thinking=enable_thinking)
    honest_ids = model_utils.build_chat_prompt(tokenizer, honest_prompt,
                                               enable_thinking=enable_thinking)

    rows: List[QueueRow] = []
    baseline: Optional[float] = None

    for k in ks:
        results = {}
        q, worker = _make_worker(model, tokenizer, eos_ids, results, {})
        worker.start()

        # Enqueue k sponges, then the honest request (all near-simultaneously).
        now = time.time()
        for i in range(k):
            q.put((f"sponge_{k}_{i}", sponge_ids, ceiling, now))
        q.put((f"honest_{k}", honest_ids, ceiling, time.time()))
        q.join()
        q.put(None)  # stop the worker
        worker.join()

        honest_latency = results[f"honest_{k}"]["latency"]
        if k == 0:
            baseline = honest_latency
        slowdown = (honest_latency / baseline) if baseline else 1.0
        rows.append(QueueRow(n_sponges=k, honest_latency_s=honest_latency,
                             slowdown=slowdown))
        if verbose:
            print(f"[queue-dos] sponges_ahead={k}  "
                  f"honest_latency={honest_latency:6.2f}s  slowdown={slowdown:5.1f}x")

    return rows


def print_table(rows: List[QueueRow]):
    print("\nSponges queued ahead : " + "  ".join(f"{r.n_sponges:>6d}" for r in rows))
    print("Honest latency (s)   : " + "  ".join(f"{r.honest_latency_s:6.2f}" for r in rows))
    print("Slowdown vs idle     : " + "  ".join(f"{r.slowdown:5.1f}x" for r in rows))


def main():
    config.set_seed()
    model, tokenizer = model_utils.load_model_and_tokenizer()
    rows = run_queue_dos(model, tokenizer)
    print_table(rows)


if __name__ == "__main__":
    main()
