# Sponge-style LLM Resource-Exhaustion — Implementation

Code for Project 37 (CSE 406). It implements the attacks and defenses described
in `../report/design_report.pdf` against a small instruction-tuned LLM
(`Qwen/Qwen2.5-0.5B-Instruct`, fp32, greedy — Table 1 of the report).

The project is split 50/50 between **Ahnaf** and **Dipit**. Both implement some
attacks and some defenses; the harder items are Ahnaf's. See the split below.

---

## Real graded attacks: LoopLLM (white-box) + AutoDoS (black-box)

The Tier-2 re-implementations under `attacks/tier2*` (Engorgio, genetic) did not
work on instruction-tuned chat models — which matches both source papers
(Engorgio drops to ~2% ASR on chat models). The graded attacks now use the two
methods that *do* work on chat models, ported from their authors' repositories:

* **LoopLLM** (white-box, Li et al., AAAI 2026) — `attacks/loopllm/`. A GCG-style
  optimiser that appends a repetition-inducing cyclic suffix (LoopLLM-t `c=1`,
  LoopLLM-p `c=5`) to trap the model in a low-entropy loop that runs to the
  output ceiling. Needs model weights + gradients.
* **AutoDoS / "Crabs"** (black-box, Zhang et al., 2025) — `attacks/autodos/`.
  Builds a DoS Attack Tree of ~25 sub-questions and wraps it in a Length Trojan
  so the target fills its whole output window. Prompt-only; one local model plays
  attacker, judge and target (self-attack). API/fastchat layer replaced by a
  local Hugging Face backend so it runs offline on Kaggle.

**Victim model: `meta-llama/Llama-3.1-8B-Instruct`** (full bf16, no quantization)
— the single best-grounded choice for *both* attacks (it is the "Llama3-8B" /
"Llama8B" in both papers, with the best 7–8B white-box ASR of 94%). One victim,
two attack surfaces. On a 16 GB T4 the 8B white-box gradient pass does not fit,
so the notebook auto-falls-back the *white-box* victim to `Llama-3.2-3B-Instruct`
(93% ASR) while keeping the 8B as the black-box target.

Run **`kaggle_attacks.ipynb`** (not `main.ipynb`, which is the older half). Set
`WHICH = "loopllm" | "autodos" | "both"` to split across two Kaggle accounts.
Needs an `HF_TOKEN` secret with the Llama license accepted (both are gated).
Local CPU smoke tests: `python tests/test_real_attacks.py`.

**Offline RTX Pro 6000:** first run **`kaggle_download_assets.ipynb`** on a T4 x2
session (Internet ON) to stage the ~16 GB gated Llama weights, Save Version, then
attach that notebook's Output as a dataset to `kaggle_attacks.ipynb` — its
`resolve_model()` loads the local snapshot with no internet.

**LoopLLM crafting protocol** (`LOOPLLM_CRAFT_MODE`): `per_input` (default,
paper-faithful — a fresh GCG suffix per test prompt, strongest ASR), `reuse` (one
suffix for all prompts, fast), or `universal` (one suffix over a train set, tested
held-out). `per_input` reports both a greedy ASR and a sampled ASR
(`LOOPLLM_ASR_SAMPLES` stochastic decodes on `LOOPLLM_ASR_PROMPTS` prompts,
matching the paper's success rule).

**Rough runtime (RTX Pro 6000):** LoopLLM `per_input` + sampled ASR ≈ **1.5–2 h**
(dominated by one craft per prompt); `reuse` mode ≈ **~35 min**. AutoDoS ≈
**15 min–1.5 h** (early-returns when the window fills). Run the two on separate
accounts in parallel. Trim with `LOOPLLM_CRAFT_MODE=reuse`, fewer test prompts,
`LOOPLLM_ASR_SAMPLES=1`, or lower `AUTODOS_N_ITERATIONS`.

---

## Where to run (Kaggle GPU)

Recommended: **GPU T4 x2, Internet ON**.

| Accelerator | Online? | NVML energy | Notes |
|---|---|---|---|
| **T4 x2** (use one T4) | yes | yes (Turing) | **Recommended.** Model downloads from HF; 16 GB is ample for 0.5B + Engorgio. |
| P100 | yes | power-sampling only | Pascal lacks the NVML total-energy counter; the code falls back to integrating power, so energy still works. |
| RTX Pro 6000 | **no (offline)** | yes | Fastest, but no internet: the model must be pre-uploaded as a dataset before use. |

The single-worker queue experiment deliberately uses **one** GPU worker, so a
single T4 is the natural choice.

### Steps
1. Zip and upload the `code/` directory as a **Kaggle Dataset**.
2. Open `main.ipynb` on Kaggle, *Add Data* → your dataset, set Accelerator =
   GPU T4 x2 and Internet = ON.
3. Run all cells. Result figures are written to `/kaggle/working/figures/`.

---

## Directory layout

```
code/
  common/        config, model loading, energy (NVML), measurement harness,
                 stealth (PPL / NCD / compression)
  attacks/       tier1_baselines, tier2a_genetic, tier2b_engorgio (old);
                 loopllm/ (white-box), autodos/ (black-box)  <- graded attacks
  defenses/      l1..l6 + guard (layered pipeline)
  server/        FastAPI victim server + attacker/honest clients
  experiments/   per-request cost, length sweep, queue DoS, cross-model,
                 defense eval, exp_loopllm, exp_autodos, plots.py, plots_attacks.py
  tests/         test_ahnaf_parts.py, test_real_attacks.py (CPU smoke tests)
  kaggle_attacks.ipynb  Kaggle notebook for the two REAL attacks (LoopLLM+AutoDoS)
  main.ipynb            older orchestration notebook (Engorgio/genetic half)
```

---

## Task split (50 / 50)

Both members implement attacks **and** defenses. The harder attacks (the
white-box Engorgio optimisation and the genetic search) and the harder defense
(the latent detector) are Ahnaf's, along with the measurement foundation the
graded attacks depend on.

### Ahnaf  (harder attacks + hardest defense + measurement foundation)
| Area | Module | Status |
|---|---|---|
| Foundation | `common/config.py`, `common/model_utils.py`, `common/energy.py`, `common/metrics.py` | done |
| Attack — Tier 2b (white-box, hardest) | `attacks/tier2b_engorgio.py` | done |
| Attack — Tier 2a (black-box GA) | `attacks/tier2a_genetic.py` | done |
| Defense — L2 input validation | `defenses/l2_input_validation.py` | done |
| Defense — L5 latent detector (hardest) | `defenses/l5_latent_detector.py` | done |
| Experiment — queue DoS (Table 3) | `experiments/exp_queue_dos.py` | done |
| Experiment — multi-model sweep | `experiments/exp_multimodel.py` | done |
| Result figures | `experiments/plots.py` | done |
| CSV output helper | `common/csvout.py` | done |
| Tests | `tests/test_ahnaf_parts.py` | done |

### Dipit  (baselines + supporting defenses + server + straightforward experiments)
| Area | Module | Status |
|---|---|---|
| Attack — Tier 1 baselines | `attacks/tier1_baselines.py` | **stub** |
| Defense — L1 output/compute cap | `defenses/l1_output_cap.py` | **stub** |
| Defense — L3 output monitoring | `defenses/l3_output_monitor.py` | **stub** |
| Defense — L4 rate limiting/quotas | `defenses/l4_rate_limit.py` | **stub** |
| Defense — L6 configuration hygiene | `defenses/l6_config_hygiene.py` | **stub** |
| Defense — layered guard (L1–L6) | `defenses/guard.py` | **stub** |
| Server + clients (topology/packet) | `server/app.py`, `server/client.py` | **stub** |
| Experiment — per-request cost (Table 2) | `experiments/exp_per_request_cost.py` | **stub** |
| Experiment — latency vs length | `experiments/exp_length_sweep.py` | **stub** |
| Experiment — cross-model check | `experiments/exp_cross_model.py` | **stub** |
| Experiment — defense evaluation | `experiments/exp_defense_eval.py` | **stub** |

Every stub carries a full spec in its docstring (interface, report reference,
and grounding source), and imports Ahnaf's ready modules (`metrics`, `l2`, `l5`)
directly, so Dipit only fills in the marked bodies.

---

## Verifying Ahnaf's half

```bash
cd code
python tests/test_ahnaf_parts.py      # CPU smoke tests, tiny sizes
```

The tests check correctness (shapes, gradient flow, loss behaviour, the queue
mechanism, detector/validator pipelines), not attack strength — real numbers
come from a GPU run of `main.ipynb`.

---

## Multiple models and CSV outputs

* `experiments/exp_multimodel.py` sweeps every attack across several models
  (see `common/config.py: MODELS`) and writes one comparison CSV. Base models
  (gpt2, opt) babble on almost any input, so their natural baseline already runs
  near the cap and amplification is ~1x; instruct models stop early on normal
  prompts, so sponges show a large amplification. This is the honest, grounded
  reason each attack's *visible* impact depends on the model.
* Every experiment can dump a CSV via `common/csvout.py` for later diagnosis and
  re-plotting; the notebook writes them under `/kaggle/working/csv/`.

## Live demonstration

For the evaluation day there is a separate, self-contained demo harness in
`../demo/` (victim LLM server behind one worker + attacker client + a runner
that flips defenses on/off live and shows the attacks mitigated). It reuses this
package's L2 and L5 defenses. See `../demo/README.md`.

## Honesty notes

* Fitness for the genetic search is the **measured** output length via the same
  greedy path a real request takes — no gradients, no internals, no leakage.
* The Engorgio trigger is chosen by its **real** greedy output length (the
  attacker's own white-box forward pass), not by the soft-prompt loss. The soft
  loss is only a surrogate and on a 0.5B model its argmax read-off does not track
  it; selecting by real generation uses no evaluation data and leaks nothing.
* The latent detector is evaluated with leakage-free **stratified k-fold
  cross-validation** (scaler and SVM refit inside each fold); every example is
  scored once while held out. We report exactly which sponge examples it saw.
* Energy is reported only when NVML provides it; otherwise it is `None`, never
  guessed.
* Numbers in the report are measured, not hardcoded; re-running reproduces them
  (seeds pinned, greedy decoding).
