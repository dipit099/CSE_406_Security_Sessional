"""
Tiny CSV writer used across experiments for diagnosable, re-openable results.

Owner: Ahnaf.

Every experiment can dump its rows to a CSV so results can be inspected,
diffed, and re-plotted later without re-running the model. Kept dependency-free
(std-lib csv) so it works anywhere.
"""

from __future__ import annotations

import csv
import os
from dataclasses import asdict, is_dataclass
from typing import Iterable


def _rowdict(row):
    if is_dataclass(row):
        return asdict(row)
    if isinstance(row, dict):
        return row
    raise TypeError(f"cannot turn {type(row)} into a CSV row")


def write_csv(path: str, rows: Iterable, fieldnames=None) -> str:
    """
    Write `rows` (dicts or dataclasses) to `path` as CSV and return the path.

    If `fieldnames` is None it is taken from the union of keys across rows, in
    first-seen order, so partial rows still line up under the right columns.
    """
    rows = [_rowdict(r) for r in rows]
    if not rows:
        # still create an (empty) file so the caller sees the path exists
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        open(path, "w", newline="", encoding="utf-8").close()
        return path

    if fieldnames is None:
        fieldnames = []
        for r in rows:
            for k in r:
                if k not in fieldnames:
                    fieldnames.append(k)

    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)
    return path
