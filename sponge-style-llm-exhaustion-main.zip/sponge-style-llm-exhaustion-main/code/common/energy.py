"""
GPU energy measurement via NVML.

Owner: Ahnaf (foundation).

Two ways to get energy, both provided:
  1. `nvmlDeviceGetTotalEnergyConsumption` (millijoule counter). Accurate, but
     only exposed on Volta+ GPUs. On Kaggle: T4 and RTX Pro 6000 support it,
     P100 (Pascal) does NOT.
  2. `PowerSampler`: a background thread that polls instantaneous power
     (`nvmlDeviceGetPowerUsage`, milliwatt) and integrates it over time. Works
     on every NVIDIA GPU including P100, so it is the portable fallback.

Everything degrades gracefully: if pynvml is missing (e.g. a CPU box) or the
GPU does not support a call, energy is reported as None instead of crashing.
That keeps the code importable and testable off-GPU.

Threading note: the attribute is named `_stop_event`, NOT `_stop`. threading.
Thread already defines an internal `_stop()` method that join() calls during
teardown; shadowing it with an Event instance raises
`TypeError: 'Event' object is not callable`. This bit us once in the notebook.
"""

from __future__ import annotations

import time
import threading

try:
    import pynvml
    _HAS_NVML = True
except Exception:
    pynvml = None
    _HAS_NVML = False


def nvml_available():
    return _HAS_NVML


def _handle(device_index=0):
    pynvml.nvmlInit()
    return pynvml.nvmlDeviceGetHandleByIndex(device_index)


def supports_total_energy(device_index=0):
    """True if the GPU exposes the total-energy millijoule counter."""
    if not _HAS_NVML:
        return False
    try:
        h = _handle(device_index)
        pynvml.nvmlDeviceGetTotalEnergyConsumption(h)
        return True
    except Exception:
        return False


class PowerSampler(threading.Thread):
    """
    Poll GPU power in the background and integrate to joules.

    Usage:
        s = PowerSampler(device_index=0); s.start()
        ... run the workload ...
        s.stop(); s.join()
        joules = s.energy_joules()   # None if NVML unavailable
    """

    def __init__(self, device_index=0, interval=0.02):
        super().__init__(daemon=True)
        self.device_index = device_index
        self.interval = interval
        self.samples = []           # list of (timestamp, watts)
        self._stop_event = threading.Event()   # NOT self._stop (see module doc)
        self._handle = None
        if _HAS_NVML:
            try:
                self._handle = _handle(device_index)
            except Exception:
                self._handle = None

    def run(self):
        if self._handle is None:
            return
        while not self._stop_event.is_set():
            try:
                mw = pynvml.nvmlDeviceGetPowerUsage(self._handle)  # milliwatt
                self.samples.append((time.time(), mw / 1000.0))    # -> watt
            except Exception:
                pass
            self._stop_event.wait(self.interval)

    def stop(self):
        self._stop_event.set()

    def energy_joules(self):
        """Trapezoidal integral of power(t). None if we captured < 2 samples."""
        if len(self.samples) < 2:
            return None
        e = 0.0
        for (t0, p0), (t1, p1) in zip(self.samples, self.samples[1:]):
            e += 0.5 * (p0 + p1) * (t1 - t0)
        return e


class EnergyMeter:
    """
    Context-manager-style energy meter that picks the best available method.

    with EnergyMeter(device_index=0) as m:
        run_workload()
    print(m.joules)   # float, or None if no GPU energy data
    """

    def __init__(self, device_index=0, interval=0.02):
        self.device_index = device_index
        self.interval = interval
        self.joules = None
        self._use_counter = supports_total_energy(device_index)
        self._sampler = None
        self._e0 = None

    def __enter__(self):
        if self._use_counter:
            h = _handle(self.device_index)
            self._e0 = pynvml.nvmlDeviceGetTotalEnergyConsumption(h)  # mJ
        else:
            self._sampler = PowerSampler(self.device_index, self.interval)
            self._sampler.start()
        return self

    def __exit__(self, *exc):
        if self._use_counter:
            h = _handle(self.device_index)
            e1 = pynvml.nvmlDeviceGetTotalEnergyConsumption(h)
            self.joules = (e1 - self._e0) / 1000.0  # mJ -> J
        elif self._sampler is not None:
            self._sampler.stop()
            self._sampler.join()
            self.joules = self._sampler.energy_joules()
        return False
