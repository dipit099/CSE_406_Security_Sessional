"""
Model / tokenizer loading and the small helpers every other module needs.

Owner: Ahnaf (foundation).

Responsibilities:
  * load an instruction-tuned causal LM + tokenizer, with Qwen's sampling
    defaults cleared so greedy decoding is truly greedy;
  * turn a plain user string into chat-formatted input_ids;
  * expose the set of stop-token ids (a model can have more than one);
  * a single greedy `generate` wrapper that returns the number of NEW tokens,
    which is the cost quantity the whole project is built around.
"""

from __future__ import annotations

import os

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from . import config


def _hf_token():
    """
    An HF access token, if the caller set one up (needed only for gated models
    such as meta-llama/Llama-3.2-*-Instruct). We only ever READ it from the
    environment -- never hardcode or log a token. Returns None if unset, in
    which case gated repos simply fail to download with a clear HF error.
    """
    return os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")


def has_hf_token():
    """Public check other modules can use to decide whether to attempt a
    gated model at all, so a missing token can be skipped with a clear message
    instead of surfacing as a raw 401/403 mid-sweep."""
    return _hf_token() is not None


def load_model_and_tokenizer(model_name=None, device=None, dtype=None,
                             enable_thinking=False):
    """
    Load `model_name` (default: the report's Qwen2.5-0.5B-Instruct) and its
    tokenizer, put the model on `device` in eval mode, and neutralise any
    built-in sampling defaults so that greedy decoding is deterministic.

    `enable_thinking` only matters for models that support a thinking mode
    (e.g. Qwen3); it is threaded into the chat template later.
    """
    model_name = model_name or config.MODEL_NAME
    device = device or config.get_device()
    torch_dtype = config.resolve_dtype(dtype)
    token = _hf_token()

    tokenizer = AutoTokenizer.from_pretrained(
        model_name, trust_remote_code=True, token=token)
    # transformers renamed the precision kwarg from `torch_dtype` to `dtype`
    # (deprecation warning on newer versions, e.g. Kaggle's). Try the new name
    # first and fall back to the old one, so this works on any version.
    try:
        model = AutoModelForCausalLM.from_pretrained(
            model_name, dtype=torch_dtype, trust_remote_code=True, token=token
        )
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(
            model_name, torch_dtype=torch_dtype, trust_remote_code=True,
            token=token
        )
    model.to(device)
    model.eval()

    # Clear sampling defaults some instruct models ship with, so that
    # do_sample=False actually gives greedy, reproducible output.
    gc = model.generation_config
    for attr in ("temperature", "top_p", "top_k"):
        if hasattr(gc, attr):
            setattr(gc, attr, None)
    gc.do_sample = False

    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token

    # Stash for convenience.
    model._enable_thinking = enable_thinking
    # Whether this model uses a chat template. Base models (gpt2, opt, the
    # non-instruct Qwen) have none, so their inputs are fed as raw text.
    model._is_chat = has_chat_template(tokenizer)
    return model, tokenizer


def has_chat_template(tokenizer):
    """True if the tokenizer carries a chat template (instruct/SFT models)."""
    return bool(getattr(tokenizer, "chat_template", None))


def get_eos_ids(tokenizer, model):
    """
    Return every token id that should stop generation, as a list.

    Qwen chat models stop on <|im_end|> as well as the raw EOS token, so we
    collect all of them. This list is what the attacks try to keep unlikely
    and what the measurement harness treats as "done".
    """
    ids = set()
    if tokenizer.eos_token_id is not None:
        ids.add(int(tokenizer.eos_token_id))
    # model config may list several
    cfg_eos = getattr(model.config, "eos_token_id", None)
    if isinstance(cfg_eos, (list, tuple)):
        ids.update(int(x) for x in cfg_eos)
    elif cfg_eos is not None:
        ids.add(int(cfg_eos))
    # Qwen's explicit turn-end token
    for tok in ("<|im_end|>", "<|endoftext|>"):
        tid = tokenizer.convert_tokens_to_ids(tok)
        if tid is not None and tid >= 0:
            ids.add(int(tid))
    return sorted(ids)


def build_chat_prompt(tokenizer, user_text, enable_thinking=False,
                      add_generation_prompt=True, chat=None):
    """
    Turn a single user string into input_ids (1-D LongTensor, no batch dim) the
    way the victim server would. For an instruct model this applies the chat
    template; for a base model (no template) it feeds the raw text.

    `chat`: None = auto-detect from the tokenizer; True/False forces the mode.

    We deliberately split the chat path into two individually-stable steps
    (render to a string with tokenize=False, then encode) rather than calling
    apply_chat_template(tokenize=True, ...) directly. That combined call's
    return type is not stable across transformers versions: it has been
    observed to return a plain list[int], a torch.Tensor, and (on the
    transformers build installed on Kaggle at time of writing) a list of
    single-character strings, which crashes torch.tensor() with "too many
    dimensions 'str'". Rendering then encoding uses only well-defined APIs.
    """
    if chat is None:
        chat = has_chat_template(tokenizer)

    if not chat:
        # Base model: no chat template. The raw text IS the prompt; let the
        # tokenizer add whatever special tokens it normally would (e.g. BOS).
        ids = tokenizer.encode(user_text, add_special_tokens=True)
        return torch.tensor(ids, dtype=torch.long)

    messages = [{"role": "user", "content": user_text}]
    kwargs = dict(tokenize=False, add_generation_prompt=add_generation_prompt)
    # Newer Qwen templates accept enable_thinking; older ones ignore it.
    try:
        prompt_str = tokenizer.apply_chat_template(
            messages, enable_thinking=enable_thinking, **kwargs
        )
    except TypeError:
        prompt_str = tokenizer.apply_chat_template(messages, **kwargs)
    # The template already spells out every special token (<|im_start|>, ...)
    # as literal text, so add_special_tokens=False avoids double-inserting
    # a BOS/EOS on top of what the template put there.
    ids = tokenizer.encode(prompt_str, add_special_tokens=False)
    return torch.tensor(ids, dtype=torch.long)


@torch.no_grad()
def generate(model, tokenizer, input_ids, max_new_tokens=None,
             eos_ids=None, greedy=True):
    """
    Greedy generation wrapper.

    Returns (output_ids, n_new_tokens) where n_new_tokens counts only the
    tokens the model produced (excluding the prompt). n_new_tokens is the
    single most important cost quantity in the project.
    """
    if max_new_tokens is None:
        max_new_tokens = config.MAX_NEW_TOKENS
    device = next(model.parameters()).device
    if input_ids.dim() == 1:
        input_ids = input_ids.unsqueeze(0)
    input_ids = input_ids.to(device)
    prompt_len = input_ids.shape[1]

    # Pass an explicit attention mask. Our prompts are a single, unpadded
    # sequence (all-ones mask), but when pad_token_id == eos_token_id
    # transformers cannot infer the mask and warns that results may be
    # unreliable; supplying it silences that and keeps behaviour well-defined.
    attention_mask = torch.ones_like(input_ids)

    gen_kwargs = dict(
        attention_mask=attention_mask,
        max_new_tokens=max_new_tokens,
        do_sample=not greedy,
        pad_token_id=tokenizer.pad_token_id,
    )
    if eos_ids is not None:
        gen_kwargs["eos_token_id"] = eos_ids

    out = model.generate(input_ids, **gen_kwargs)
    n_new = int(out.shape[1] - prompt_len)
    return out[0], n_new
