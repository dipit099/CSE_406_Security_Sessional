"""
Central configuration: model choice, precision, decoding, seeds, ceilings.

Owner: Ahnaf (foundation for the graded attacks).

Everything here matches Table 1 of the design report:
    Model      Qwen2.5-0.5B-Instruct (any small instruct model is a drop-in)
    Precision  fp32
    Decoding   greedy (deterministic)
    Seeds      Python, NumPy, PyTorch/CUDA all pinned
    Ceiling    max_tokens = 2048
    Metrics    output tokens, latency, energy (NVML), GPU memory

Keep this file free of heavy imports so it can be read on any machine.
"""

import os
import random

# ----------------------------------------------------------------------------
# Models
# ----------------------------------------------------------------------------
# Primary victim model used for every headline number in the report.
MODEL_NAME = "Qwen/Qwen2.5-0.5B-Instruct"

# Second model, only for the cross-model check (Section: Expected outcome).
# We show the attack direction holds on a newer model, thinking mode OFF.
ALT_MODEL_NAME = "Qwen/Qwen3-0.6B"

# ----------------------------------------------------------------------------
# Victim model for the two REAL graded attacks (LoopLLM white-box, AutoDoS
# black-box). Decided after reading both source papers: Llama-3.1-8B-Instruct is
# the single best-grounded choice for BOTH attacks and is used as one victim so
# the story is "same model, two attack surfaces".
#   * LoopLLM (Li et al., AAAI 2026), Table 1: their "Llama3-8B" IS
#     Llama-3.1-8B-Instruct (Appendix D.1) and scores the best ASR of any 7-8B
#     open model (94% at max-len 4096).
#   * AutoDoS / Crabs (Zhang et al., 2025): their "Llama8B" is also
#     Llama-3.1-8B-Instruct; it is driven to the full 8192-token output window
#     (Table 1) with latency degradation on par with Qwen (Table 2).
# Runs at full bf16 precision (no quantization) on the RTX Pro 6000. On a single
# 16 GB T4 the white-box gradient pass will not fit an 8B; the documented
# fall-back there is the 3B twin below (LoopLLM Llama3-3B = 93% ASR).
VICTIM_MODEL = "meta-llama/Llama-3.1-8B-Instruct"
VICTIM_MODEL_T4_FALLBACK = "meta-llama/Llama-3.2-3B-Instruct"  # white-box on a T4
VICTIM_DTYPE = "bfloat16"   # 8B at full precision; the attacks do not need fp32

# LoopLLM (white-box) crafting defaults, from the paper's config.
LOOPLLM = dict(adv_len=30, craft_steps=20, topk=64, num_candidate=128,
               once_forward_batch=8, craft_fitness_ceiling=384,
               measure_ceiling=4096)

# AutoDoS (black-box) defaults, from the paper / repo README.
AUTODOS = dict(n_question=25, question_length=200, n_streams=3, n_iterations=10,
               target_max_n_tokens=8192, attack_max_new_tokens=4096,
               attack_temperature=0.5)

# ----------------------------------------------------------------------------
# Model registry for multi-model coverage
# ----------------------------------------------------------------------------
# Both papers show these inference-cost attacks are far stronger on *base*
# (pre-trained, non-chat) models than on aggressively-concise *instruct/SFT*
# models. Engorgio Table 9: GPT-2-large and OPT-125M reach 98-100% of the
# length cap under Engorgio, and even plain sponge examples reach ~80%; whereas
# SFT models (Table 1) are the hard case and often need a semantic prefix.
#
# To make each attack's impact visible individually, we therefore test a mix:
# an easy base model, a same-family base model, and the hard instruct model.
# `chat`: whether to wrap inputs in a chat template (instruct models) or feed
# raw text (base models, which have no template). Ordered easy -> hard.
MODELS = {
    # -- base (pre-trained, no chat template): raw-text babble baseline -------
    "distilgpt2":            {"name": "distilgpt2",                 "chat": False},
    "gpt2":                  {"name": "gpt2",                       "chat": False},
    "opt-125m":              {"name": "facebook/opt-125m",          "chat": False},
    "pythia-410m":           {"name": "EleutherAI/pythia-410m",     "chat": False},
    "qwen2.5-0.5b-base":     {"name": "Qwen/Qwen2.5-0.5B",          "chat": False},
    "smollm2-360m-base":     {"name": "HuggingFaceTB/SmolLM2-360M", "chat": False},
    # -- instruct / SFT (chat template): where amplification is meaningful ----
    "qwen2.5-0.5b-instruct": {"name": "Qwen/Qwen2.5-0.5B-Instruct", "chat": True},
    "qwen2.5-1.5b-instruct": {"name": "Qwen/Qwen2.5-1.5B-Instruct", "chat": True},
    "qwen3-0.6b":            {"name": "Qwen/Qwen3-0.6B",            "chat": True},
    "smollm2-360m-instruct": {"name": "HuggingFaceTB/SmolLM2-360M-Instruct",
                              "chat": True},
    "tinyllama-1.1b-chat":   {"name": "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
                              "chat": True},
    # -- gated (require an accepted license + HF_TOKEN) -----------------------
    # TinyLlama is Llama-*architecture* but a third-party model; these are the
    # actual Meta Llama family, so they matter for a family-diversity claim.
    # Accept the license at huggingface.co/meta-llama/Llama-3.2-1B(-Instruct)
    # first, or loading fails with a 403 regardless of the token.
    "llama3.2-1b-base":      {"name": "meta-llama/Llama-3.2-1B",
                              "chat": False, "gated": True},
    "llama3.2-1b-instruct":  {"name": "meta-llama/Llama-3.2-1B-Instruct",
                              "chat": True, "gated": True},
    # -- the graded-attack victim (gated: accept the Llama license + HF_TOKEN) --
    "llama3.1-8b-instruct":  {"name": "meta-llama/Llama-3.1-8B-Instruct",
                              "chat": True, "gated": True},
    "llama3.2-3b-instruct":  {"name": "meta-llama/Llama-3.2-3B-Instruct",
                              "chat": True, "gated": True},
}

# The default set the multi-model experiment sweeps on Kaggle (GPU). Chosen for
# a comprehensive report across three axes rather than raw count:
#   * controlled base<->instruct pairs (same family, so instruction-tuning is
#     the only variable): qwen2.5-0.5b-base/-instruct and smollm2-360m-base/
#     -instruct;
#   * family / tokenizer diversity: GPT-2, OPT, Qwen, SmolLM, Llama(TinyLlama);
#   * a size step within one instruct family: Qwen2.5 0.5B -> 1.5B.
# All are ungated causal LMs, so this list runs unattended with no setup.
DEFAULT_MODEL_KEYS = [
    "gpt2", "opt-125m",
    "qwen2.5-0.5b-base", "qwen2.5-0.5b-instruct",
    "smollm2-360m-base", "smollm2-360m-instruct",
    "tinyllama-1.1b-chat", "qwen2.5-1.5b-instruct",
]

# Gated models: a third, real base<->instruct pair from the Meta Llama family.
# Included in a sweep only when an HF_TOKEN is set AND the license has been
# accepted for both repos on huggingface.co (see MODELS above) -- the notebook
# checks for a token and appends these automatically; without one they are
# silently skipped rather than crashing the whole sweep.
GATED_MODEL_KEYS = ["llama3.2-1b-base", "llama3.2-1b-instruct"]

# A curated, CPU-friendly set offered as the live model toggle on the demo
# dashboard: two fast base models (they babble on anything), the primary
# instruct model and its base twin (amplification is visible on instruct), and
# one larger chat model. All are decoder-only causal LMs the attacks work on.
DASHBOARD_MODEL_KEYS = [
    "distilgpt2", "gpt2", "qwen2.5-0.5b-base",
    "qwen2.5-0.5b-instruct", "tinyllama-1.1b-chat",
]

# ----------------------------------------------------------------------------
# Reproducibility
# ----------------------------------------------------------------------------
SEED = 20250913  # single global seed; pinned across python / numpy / torch

# ----------------------------------------------------------------------------
# Decoding / cost ceiling
# ----------------------------------------------------------------------------
# The report sets a high ceiling so a sponge has room to run to a realistic
# worst case. On a 0.5B model a full 2048-token generation is slow, so the
# experiments expose their own smaller ceilings where noted; this is the
# default cap used when nothing else is specified.
MAX_NEW_TOKENS = 2048

# Deterministic (greedy) decoding: no sampling, so every number reproduces.
GREEDY = True

# ----------------------------------------------------------------------------
# Precision / device
# ----------------------------------------------------------------------------
# fp32 by default (Table 1). fp16 is available as an opt-in for speed but is
# NOT the default, because on a 0.5B model fp32 is fast enough and fp32 keeps
# the numbers clean and comparable.
DTYPE = "float32"  # one of {"float32", "float16", "bfloat16"}


def get_device():
    """Return 'cuda' if a GPU is visible, else 'cpu'. Imports torch lazily."""
    import torch
    return "cuda" if torch.cuda.is_available() else "cpu"


def resolve_dtype(name=None):
    """Map a dtype name to a torch dtype (imported lazily)."""
    import torch
    name = name or DTYPE
    return {
        "float32": torch.float32,
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
    }[name]


def set_seed(seed=SEED):
    """Pin every RNG we touch. Safe to call before torch is even used."""
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    try:
        import numpy as np
        np.random.seed(seed)
    except Exception:
        pass
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        # Greedy decoding is already deterministic; these make the rest so too.
        torch.use_deterministic_algorithms(False)  # some ops lack det. kernels
    except Exception:
        pass
