"""
The measurement harness: turn one generation into the row of numbers the
report reports (output tokens, latency, tokens/s, GPU memory, energy).

Owner: Ahnaf (foundation).

This is the single place cost is measured, so every experiment is comparable.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, asdict
from typing import Optional

import torch

from . import config
from .energy import EnergyMeter
from . import model_utils


@dataclass
class Measurement:
    out_tokens: int
    latency_s: float
    tokens_per_s: float
    gpu_mem_mb: Optional[float]
    energy_j: Optional[float]

    def as_dict(self):
        return asdict(self)


def _gpu_mem_mb(device):
    if device.type != "cuda":
        return None
    torch.cuda.synchronize(device)
    return torch.cuda.max_memory_allocated(device) / (1024 ** 2)


def measure_generation(model, tokenizer, input_ids, max_new_tokens=None,
                       eos_ids=None, device_index=0, measure_energy=True):
    """
    Run one greedy generation and measure it.

    Returns a Measurement. Energy is None when NVML is unavailable (e.g. CPU),
    so this function is safe to call anywhere; only the number is missing.
    """
    device = next(model.parameters()).device
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
        torch.cuda.synchronize(device)

    meter_cm = EnergyMeter(device_index) if (measure_energy and device.type == "cuda") \
        else _NullMeter()

    t0 = time.time()
    with meter_cm as meter:
        _, n_new = model_utils.generate(
            model, tokenizer, input_ids,
            max_new_tokens=max_new_tokens, eos_ids=eos_ids, greedy=True,
        )
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    latency = time.time() - t0

    tps = n_new / latency if latency > 0 else 0.0
    return Measurement(
        out_tokens=n_new,
        latency_s=latency,
        tokens_per_s=tps,
        gpu_mem_mb=_gpu_mem_mb(device),
        energy_j=getattr(meter, "joules", None),
    )


def measure_prompt(model, tokenizer, prompt_text, max_new_tokens=None,
                   eos_ids=None, chat=None, **kw):
    """
    Convenience: measure a plain user string (chat-templated first).

    `chat` controls how the prompt is fed: None auto-detects a chat template,
    while True/False forces it. Forcing chat=False lets a base model that
    happens to ship a chat template (e.g. Qwen2.5-0.5B base) be measured the way
    a base model should be -- on raw text -- rather than as a pseudo-chat model.
    """
    if eos_ids is None:
        eos_ids = model_utils.get_eos_ids(tokenizer, model)
    ids = model_utils.build_chat_prompt(
        tokenizer, prompt_text,
        enable_thinking=getattr(model, "_enable_thinking", False),
        chat=chat,
    )
    return measure_generation(model, tokenizer, ids,
                              max_new_tokens=max_new_tokens, eos_ids=eos_ids, **kw)


def amplification(value, baseline):
    """attack / baseline, guarding against divide-by-zero."""
    return float(value) / float(baseline) if baseline else float("inf")


class _NullMeter:
    """Stand-in when energy is not being measured; .joules stays None."""
    joules = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False
