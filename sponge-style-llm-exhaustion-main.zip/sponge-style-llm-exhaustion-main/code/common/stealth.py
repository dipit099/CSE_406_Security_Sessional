"""
Stealth metrics: input perplexity (PPL) and gzip Normalized Compression
Distance (NCD).

Owner: Ahnaf.

Both attack papers evaluate stealth against the same two defenses, so we
implement both here once:
  * PPL -- the input-perplexity filter of Alon & Kamfonas (2023). LoopLLM Table 7
    and AutoDoS Sec. 4.4.2 both report that their crafted inputs keep PPL LOW
    (LoopLLM's repetitive suffix is even below a normal prompt; AutoDoS is fluent
    natural language), so a PPL filter set at a normal-traffic threshold does not
    catch them. We compute PPL under the victim model itself, which is exactly
    what such a filter would use.
  * NCD -- the Kolmogorov-similarity / gzip proxy AutoDoS uses (Table 5, Eq. 14)
    to argue its prompts are diverse (a smaller NCD == more similar; the attack
    aims for high NCD == low similarity, i.e. it does not look like a repeated
    template). We also use NCD on an OUTPUT to quantify how self-similar a
    generation is -- a LoopLLM repetition loop compresses far better than normal
    text, which is a clean, model-free signature of the attack.

Everything degrades gracefully off-GPU: PPL just runs on CPU (slower) and NCD is
pure-python gzip.
"""

from __future__ import annotations

import gzip
import math

import torch

from . import model_utils


@torch.no_grad()
def perplexity(model, tokenizer, text, chat=None):
    """Perplexity of `text` under `model` (the number a PPL filter would see).

    Uses the raw text as a completion-style sequence (add_special_tokens) rather
    than the chat template, because a PPL input-filter scores the raw incoming
    prompt. Returns a float; lower == more fluent/predictable.
    """
    device = next(model.parameters()).device
    ids = tokenizer(text, return_tensors="pt", add_special_tokens=True).input_ids.to(device)
    if ids.shape[1] < 2:
        return float("nan")
    out = model(ids, labels=ids)
    # HF returns mean NLL over tokens in out.loss
    return float(torch.exp(out.loss).item())


def _clen(b: bytes) -> int:
    return len(gzip.compress(b))


def ncd(a: str, b: str) -> float:
    """Normalized Compression Distance between two strings (AutoDoS Eq. 14).

    NCD = (C(a+b) - min(C(a),C(b))) / max(C(a),C(b)).  In [0, ~1]; smaller means
    more similar. AutoDoS reports this between attack prompts to show diversity.
    """
    ba, bb = a.encode("utf-8", "ignore"), b.encode("utf-8", "ignore")
    ca, cb = _clen(ba), _clen(bb)
    cab = _clen(ba + bb)
    denom = max(ca, cb)
    return (cab - min(ca, cb)) / denom if denom else 0.0


def compression_ratio(text: str) -> float:
    """Bytes / gzip-bytes. A repetition-loop output (LoopLLM) compresses far
    more than normal prose, so a high ratio is a model-free signature of the
    repetitive-generation attack. Normal English is ~2-3x; a "* * * ..." loop is
    tens to hundreds x."""
    b = text.encode("utf-8", "ignore")
    if not b:
        return 0.0
    return len(b) / max(1, _clen(b))
