"""
Victim inference server: FastAPI + single-worker request queue.

Owner: DIPIT.

Realizes the report's topology and packet sections. The server is the victim:
a small open LLM behind a minimal HTTP API, with ONE worker so requests are
served one at a time (this is what makes the queue DoS possible over real HTTP,
the same single-worker design as experiments/exp_queue_dos.py, but exposed on
the network).

Endpoint (matches the report's Listing 1/2 exactly):
    POST /generate
    body: { "prompt": "<user text>", "max_tokens": <int> }
    returns: { "output": "<text>", "out_tokens": <int>, "latency_s": <float> }

    create_app(model_name: str = None, defense: bool = False) -> FastAPI

`defense=True` routes each request through defenses.guard.LayeredGuard instead
of raw generation, so exp_defense_eval can compare "defense off" vs "defense on"
over real HTTP. Until guard.py is implemented, defense=True falls back to the
undefended path with a printed warning rather than breaking the server.

Grounding: design report Sections 3 (topology), 4 (packet), 5 (what we build).
Run on Kaggle with uvicorn in a background thread bound to 127.0.0.1:8000
(see serve_in_background).
"""

from __future__ import annotations

import queue
import threading
import time

from fastapi import FastAPI
from pydantic import BaseModel
from starlette.concurrency import run_in_threadpool

from common import model_utils, config


class GenerateRequest(BaseModel):
    prompt: str
    max_tokens: int = 512


def create_app(model_name=None, defense=False):
    """
    Build the FastAPI app. Loads the model once, starts ONE background worker
    thread on a shared queue, and serves POST /generate.
    """
    app = FastAPI(title="Sponge victim server")

    config.set_seed()
    model, tokenizer = model_utils.load_model_and_tokenizer(model_name)
    eos_ids = model_utils.get_eos_ids(tokenizer, model)
    enable_thinking = getattr(model, "_enable_thinking", False)

    # Optional layered defense. Constructed lazily so the server does not depend
    # on guard.py being finished; a missing/stub guard degrades to undefended.
    guard = None
    if defense:
        try:
            from defenses.guard import LayeredGuard
            guard = LayeredGuard(model, tokenizer, detector=None)
            print("[server] defense ON: routing through LayeredGuard")
        except (NotImplementedError, ImportError) as exc:
            print(f"[server] WARNING: defense=True but guard unavailable "
                  f"({exc}); serving UNDEFENDED")
            guard = None

    job_queue: "queue.Queue" = queue.Queue()

    def _undefended(prompt, max_tokens):
        t0 = time.time()
        ids = model_utils.build_chat_prompt(tokenizer, prompt,
                                            enable_thinking=enable_thinking)
        out_ids, n_new = model_utils.generate(
            model, tokenizer, ids, max_new_tokens=max_tokens, eos_ids=eos_ids)
        text = tokenizer.decode(out_ids[ids.shape[-1]:], skip_special_tokens=True)
        return {"output": text, "out_tokens": n_new, "latency_s": time.time() - t0}

    def _defended(prompt, max_tokens):
        res = guard.handle("http-client", prompt)
        if res.get("blocked"):
            return {"output": f"[blocked by {res.get('reason')}]",
                    "out_tokens": 0, "latency_s": res.get("latency_s", 0.0)}
        return {"output": res.get("output", ""),
                "out_tokens": res.get("out_tokens", 0),
                "latency_s": res.get("latency_s", 0.0)}

    def worker():
        while True:
            job = job_queue.get()
            if job is None:
                job_queue.task_done()
                break
            prompt, max_tokens, result_q = job
            try:
                if guard is not None:
                    result_q.put(_defended(prompt, max_tokens))
                else:
                    result_q.put(_undefended(prompt, max_tokens))
            except Exception as exc:  # never let the worker die on one bad job
                result_q.put({"output": f"[error: {exc}]", "out_tokens": 0,
                              "latency_s": 0.0})
            finally:
                job_queue.task_done()

    worker_thread = threading.Thread(target=worker, daemon=True)
    worker_thread.start()

    # Stash handles so tests / shutdown can reach them.
    app.state.model = model
    app.state.tokenizer = tokenizer
    app.state.job_queue = job_queue
    app.state.worker_thread = worker_thread
    app.state.defense = guard is not None

    def _submit_blocking(prompt, max_tokens):
        """Enqueue one job and block until the single worker returns its result.
        Runs in a threadpool (see the handler) so the event loop stays free."""
        result_q: "queue.Queue" = queue.Queue(maxsize=1)
        job_queue.put((prompt, max_tokens, result_q))
        return result_q.get()

    @app.get("/health")
    def health():
        return {"status": "ok", "defense": app.state.defense}

    @app.post("/generate")
    async def generate(req: GenerateRequest):
        return await run_in_threadpool(_submit_blocking, req.prompt, req.max_tokens)

    return app


def serve_in_background(app, host="127.0.0.1", port=8000):
    """
    Start uvicorn for `app` in a daemon thread and return the uvicorn.Server.

    Blocking uvicorn.run() would never hand control back to the next notebook
    cell, so on Kaggle (and in tests) we run the server in a thread and poll
    /health from the client. Call server.should_exit = True to stop it.
    """
    import uvicorn

    config_ = uvicorn.Config(app, host=host, port=port, log_level="warning")
    server = uvicorn.Server(config_)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    # Wait until it is actually accepting connections.
    deadline = time.time() + 30
    while not server.started and time.time() < deadline:
        time.sleep(0.05)
    return server


def main():
    """Run the server in the foreground (local use, not for notebooks)."""
    import uvicorn
    app = create_app()
    uvicorn.run(app, host="127.0.0.1", port=8000)


if __name__ == "__main__":
    main()
