"""
HTTP clients: the attacker PC and the legitimate client PC.

Owner: DIPIT.

Two thin wrappers over the /generate endpoint (Section 3 topology):
  * the attacker client sends crafted sponge prompts;
  * the honest client sends normal prompts and times its own replies, which is
    how the denial of service is read from the user's side.

    send_request(url, prompt, max_tokens) -> dict
        # server's {"output","out_tokens","latency_s"} plus a client-side
        # "client_latency_s" (round-trip wall clock, the number a real user feels)
    attacker_blast(url, sponge_prompt, n, max_tokens) -> list[dict]
    honest_latency(url, honest_prompt, max_tokens) -> float

Grounding: design report Section 3. Uses `requests`; measures client-side
wall-clock for the honest latency.
"""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor
from typing import List

import requests


def send_request(url, prompt, max_tokens=512, timeout=600) -> dict:
    """
    POST one /generate request to `url` and return the parsed JSON, augmented
    with `client_latency_s` (the full round-trip time measured on this side).
    `url` may be the base ("http://127.0.0.1:8000") or include "/generate".
    """
    endpoint = url if url.rstrip("/").endswith("/generate") else url.rstrip("/") + "/generate"
    t0 = time.time()
    resp = requests.post(endpoint, json={"prompt": prompt, "max_tokens": max_tokens},
                         timeout=timeout)
    client_latency = time.time() - t0
    resp.raise_for_status()
    data = resp.json()
    data["client_latency_s"] = client_latency
    return data


def attacker_blast(url, sponge_prompt, n, max_tokens=512, concurrent=False) -> List[dict]:
    """
    Fire `n` sponge requests at the server.

    By default requests are sent SEQUENTIALLY, which already fills the single
    worker's queue. Set concurrent=True to fire them at once from a thread pool
    (closer to a real distributed blast); note in the writeup which you used,
    since it changes what the honest-latency measurement is timed against.
    """
    if not concurrent:
        return [send_request(url, sponge_prompt, max_tokens) for _ in range(n)]

    with ThreadPoolExecutor(max_workers=n) as pool:
        futures = [pool.submit(send_request, url, sponge_prompt, max_tokens)
                   for _ in range(n)]
        return [f.result() for f in futures]


def honest_latency(url, honest_prompt="What is the capital of France?",
                   max_tokens=512) -> float:
    """
    Send one honest request and return its client-side round-trip latency (s).
    This is the number that reproduces Table 3 over real HTTP: run it once with
    the queue idle, then again right after an attacker_blast, and compare.
    """
    return send_request(url, honest_prompt, max_tokens)["client_latency_s"]
