"""
Defense L3: output monitoring.

Owner: DIPIT.  ***STUB — to be implemented.***

From the design report (Defense idea, L3):
    "Kill a generation that repeats or runs long without stopping."

Implement a streaming check that watches tokens as they are produced and aborts
when the output looks like a runaway sponge: e.g. a repeated n-gram loop, or an
output already far past the length a normal answer to this prompt would need.
The cleanest way in transformers is a custom StoppingCriteria that inspects the
generated ids so far.

Interface expected by guard.py / exp_defense_eval.py:
    monitored_generate(model, tokenizer, input_ids, eos_ids=None,
                       repeat_ngram: int = 3, repeat_limit: int = 20,
                       max_new_tokens=None) -> (output_ids, n_new, killed: bool)

Grounding: design report Sections 5/8.
"""

from __future__ import annotations

import torch
from transformers import StoppingCriteria

from common import config


class RepeatMonitorCriteria(StoppingCriteria):
    """
    Abort a generation whose tail is stuck in a repeated n-gram loop.

    Watches only the tokens generated after the prompt (`prompt_len`). At each
    step it takes the most recent `repeat_ngram`-gram and counts how many times
    that exact n-gram has occurred in the generation so far; if that exceeds
    `repeat_limit`, generation is killed. This catches a runaway sponge that
    loops on the same phrase (the naive output-forcing prompt tends to), while
    leaving ordinary text alone -- normal answers almost never repeat an exact
    3-gram 20+ times.
    """

    def __init__(self, prompt_len: int, repeat_ngram: int = 3,
                 repeat_limit: int = 20):
        self.prompt_len = prompt_len
        self.n = repeat_ngram
        self.repeat_limit = repeat_limit
        self.killed = False

    def __call__(self, input_ids, scores, **kwargs) -> torch.BoolTensor:
        gen = input_ids[0, self.prompt_len:].tolist()
        done = False
        if len(gen) >= self.n:
            last = tuple(gen[-self.n:])
            count = 0
            for i in range(len(gen) - self.n + 1):
                if tuple(gen[i:i + self.n]) == last:
                    count += 1
                    if count > self.repeat_limit:
                        done = True
                        break
        if done:
            self.killed = True
        return torch.full((input_ids.shape[0],), done,
                          dtype=torch.bool, device=input_ids.device)


class ConsecutiveTokenCriteria(StoppingCriteria):
    """Halt when the SAME token is generated more than `limit` times IN A ROW.

    This is the "simple defense that halts generation when a token is
    consecutively generated beyond a threshold" from LoopLLM Table 3. It catches
    a token-level loop (LoopLLM-t: "* * * ...") but NOT a phrase-level loop
    (LoopLLM-p: "* % & @ # * % & @ #"), which never repeats one token in a row.
    Contrast with RepeatMonitorCriteria (n-gram), which catches BOTH.
    """

    def __init__(self, prompt_len: int, limit: int = 20):
        self.prompt_len = prompt_len
        self.limit = limit
        self.killed = False
        self._run = 0
        self._last = None

    def __call__(self, input_ids, scores, **kwargs) -> torch.BoolTensor:
        gen = input_ids[0, self.prompt_len:]
        done = False
        if gen.numel() > 0:
            cur = int(gen[-1])
            if cur == self._last:
                self._run += 1
            else:
                self._run, self._last = 1, cur
            if self._run > self.limit:
                done = True
        if done:
            self.killed = True
        return torch.full((input_ids.shape[0],), done,
                          dtype=torch.bool, device=input_ids.device)


@torch.no_grad()
def monitored_generate(model, tokenizer, input_ids, eos_ids=None,
                       repeat_ngram=3, repeat_limit=20, max_new_tokens=None,
                       mode="ngram"):
    """
    Greedy generation that aborts on a repetition runaway.

    `mode`:
      * "ngram"       -- abort when the tail n-gram (`repeat_ngram`) recurs more
                         than `repeat_limit` times (catches token- AND phrase-
                         level loops);
      * "consecutive" -- abort when one token repeats > `repeat_limit` times in a
                         row (LoopLLM Table 3; catches token-level loops only).

    Returns (output_ids, n_new, killed).
    """
    if max_new_tokens is None:
        max_new_tokens = config.MAX_NEW_TOKENS

    device = next(model.parameters()).device
    if input_ids.dim() == 1:
        input_ids = input_ids.unsqueeze(0)
    input_ids = input_ids.to(device)
    prompt_len = input_ids.shape[1]
    attention_mask = torch.ones_like(input_ids)

    if mode == "consecutive":
        monitor = ConsecutiveTokenCriteria(prompt_len, repeat_limit)
    else:
        monitor = RepeatMonitorCriteria(prompt_len, repeat_ngram, repeat_limit)

    gen_kwargs = dict(
        attention_mask=attention_mask,
        max_new_tokens=max_new_tokens,
        do_sample=False,
        pad_token_id=tokenizer.pad_token_id,
        stopping_criteria=[monitor],
    )
    if eos_ids is not None:
        gen_kwargs["eos_token_id"] = eos_ids

    out = model.generate(input_ids, **gen_kwargs)
    n_new = int(out.shape[1] - prompt_len)
    return out[0], n_new, monitor.killed
