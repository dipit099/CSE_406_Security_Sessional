"""
Defense L2: input validation.

Owner: Ahnaf.

From the design report (Defense idea, L2):
    "Reject inputs whose token-to-character ratio or length is abnormal (the
     tokenizer-abuse fingerprint); optionally flag high-perplexity or
     repetitive prompts."

This is a cheap, pre-generation gate. It targets the Tier-1 tokenizer-abuse
lever directly (odd orthography / character-splitting shows up as an unusually
high tokens-per-character ratio) and adds length, repetition and optional
perplexity checks. It does NOT catch a fluent EOS-suppressing prompt on its
own; that is what L1 (output cap) and L5 (latent detector) are for. Honesty
about each layer's reach is the point of the layered design.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

import torch


@dataclass
class ValidationThresholds:
    # Calibrated on the Qwen2.5 tokenizer: ordinary English measures ~0.18-0.25
    # tokens/char, while character-split abuse measures >=0.41 (slash-split
    # 0.52, space-split 0.50, per-character 1.0). 0.35 sits cleanly between,
    # with headroom for denser-but-legitimate text. This catches gross
    # tokenizer abuse; a near-normal-ratio prompt is left to L5, by design.
    max_tokens_per_char: float = 0.35
    # Reject prompts longer than this many tokens outright.
    max_input_tokens: int = 1024
    # Flag if the most frequent token makes up more than this share of the input.
    max_token_repeat_frac: float = 0.5
    # Optional perplexity gate (needs a model); None disables it.
    max_perplexity: Optional[float] = None
    # Short inputs are exempt from the ratio test. Ordinary short questions with
    # digits or punctuation ("What is 17 times 23?") tokenize densely and can
    # exceed the ratio threshold even though they are perfectly legitimate; more
    # importantly a short dense input carries few absolute tokens, so it cannot
    # inflate prefill cost enough to matter. The tokenizer-abuse threat only
    # bites once the input is long, so we apply the ratio fingerprint only above
    # this length. Calibrated on the eval set: every genuine abuse prompt is
    # >=435 chars, while the dense-but-benign false positives were <=31 chars, so
    # 40 removes the false positives (FPR 10% -> 0%) with no loss of detection.
    min_chars_for_ratio: int = 40


@dataclass
class ValidationResult:
    ok: bool
    reasons: List[str] = field(default_factory=list)
    stats: dict = field(default_factory=dict)


def _token_repeat_frac(token_ids: List[int]) -> float:
    if not token_ids:
        return 0.0
    counts = {}
    for t in token_ids:
        counts[t] = counts.get(t, 0) + 1
    return max(counts.values()) / len(token_ids)


@torch.no_grad()
def _perplexity(model, tokenizer, text: str) -> float:
    """Mean next-token perplexity of `text` under the model (teacher forcing)."""
    device = next(model.parameters()).device
    ids = tokenizer(text, return_tensors="pt").input_ids.to(device)
    if ids.shape[1] < 2:
        return 1.0
    out = model(ids, labels=ids)
    return float(torch.exp(out.loss).item())


def validate_input(text, tokenizer, model=None, thresholds=None):
    """
    Check one input string. Returns a ValidationResult; `ok=False` means the
    request should be rejected before generation.

    `model` is only needed if a perplexity threshold is set.
    """
    th = thresholds or ValidationThresholds()
    token_ids = tokenizer.encode(text, add_special_tokens=False)
    n_tokens = len(token_ids)
    n_chars = len(text)
    tokens_per_char = (n_tokens / n_chars) if n_chars else 0.0
    repeat_frac = _token_repeat_frac(token_ids)

    stats = {
        "n_tokens": n_tokens,
        "n_chars": n_chars,
        "tokens_per_char": tokens_per_char,
        "token_repeat_frac": repeat_frac,
    }
    reasons = []

    if n_tokens > th.max_input_tokens:
        reasons.append(f"input too long: {n_tokens} > {th.max_input_tokens} tokens")

    if n_chars >= th.min_chars_for_ratio and tokens_per_char > th.max_tokens_per_char:
        reasons.append(
            f"tokens/char {tokens_per_char:.2f} > {th.max_tokens_per_char} "
            f"(tokenizer-abuse fingerprint)")

    if repeat_frac > th.max_token_repeat_frac:
        reasons.append(
            f"repetitive input: top token is {repeat_frac:.0%} of tokens")

    if th.max_perplexity is not None and model is not None:
        ppl = _perplexity(model, tokenizer, text)
        stats["perplexity"] = ppl
        if ppl > th.max_perplexity:
            reasons.append(f"perplexity {ppl:.1f} > {th.max_perplexity}")

    return ValidationResult(ok=(len(reasons) == 0), reasons=reasons, stats=stats)


def evaluate_validator(texts, labels, tokenizer, model=None, thresholds=None):
    """
    Score the validator on a labelled set. labels: 1 = sponge/malicious,
    0 = benign. Returns a dict with accuracy and the confusion counts, treating
    "rejected" as a positive (malicious) prediction.
    """
    tp = tn = fp = fn = 0
    for text, y in zip(texts, labels):
        rejected = not validate_input(text, tokenizer, model, thresholds).ok
        if y == 1 and rejected:
            tp += 1
        elif y == 1 and not rejected:
            fn += 1
        elif y == 0 and rejected:
            fp += 1
        else:
            tn += 1
    total = tp + tn + fp + fn
    acc = (tp + tn) / total if total else 0.0
    return {"accuracy": acc, "tp": tp, "tn": tn, "fp": fp, "fn": fn,
            "detection_rate": tp / (tp + fn) if (tp + fn) else 0.0,
            "false_positive_rate": fp / (fp + tn) if (fp + tn) else 0.0}
