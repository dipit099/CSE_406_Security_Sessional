"""
Defense L5: latent anomaly detector.

Owner: Ahnaf. This is the hardest defense in the project.

From the design report (Defense idea, L5):
    "A lightweight classifier on the model's hidden state separates normal from
     resource-heavy inputs at runtime."

Method follows LLMEffiChecker's detector (train_detector.py): take the model's
last-layer hidden states for an input, mean-pool them over the real (non-pad)
token positions into one feature vector, and train an SVM to tell benign
inputs from sponge inputs. We report accuracy and ROC-AUC on a held-out split.

Why this can work when L2 cannot: an EOS-suppressing prompt is fluent (it slips
past the tokens-per-char check) but it still drives the model's internal
representation somewhere unusual, and a simple classifier can pick that up.

Honesty notes:
  * The detector is trained and evaluated on a proper train/test split; we never
    test on training inputs (no leakage).
  * It is only as good as the sponge examples it is shown; we report exactly
    which attack(s) it was trained/tested on.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import numpy as np
import torch

try:
    from sklearn.svm import SVC
    from sklearn import metrics as sk_metrics
    from sklearn.model_selection import StratifiedKFold, cross_val_predict
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler
    _HAS_SKLEARN = True
except Exception:
    _HAS_SKLEARN = False


@torch.no_grad()
def extract_features(model, tokenizer, texts: List[str], batch_size=8,
                     layer=-1, chat_template=True):
    """
    Mean-pooled last-layer hidden state for each text -> (N, hidden_dim) array.

    Pooling respects the attention mask, so padding never dilutes the mean.
    If `chat_template` is True the text is wrapped exactly as a real request
    (so the detector sees what the server would actually run).
    """
    device = next(model.parameters()).device
    feats = []
    enable_thinking = getattr(model, "_enable_thinking", False)

    for start in range(0, len(texts), batch_size):
        batch = texts[start:start + batch_size]
        if chat_template:
            rendered = []
            for t in batch:
                msgs = [{"role": "user", "content": t}]
                try:
                    s = tokenizer.apply_chat_template(
                        msgs, tokenize=False, add_generation_prompt=True,
                        enable_thinking=enable_thinking)
                except TypeError:
                    s = tokenizer.apply_chat_template(
                        msgs, tokenize=False, add_generation_prompt=True)
                rendered.append(s)
            batch = rendered

        enc = tokenizer(batch, return_tensors="pt", padding=True,
                        truncation=True, add_special_tokens=not chat_template)
        enc = {k: v.to(device) for k, v in enc.items()}
        out = model(**enc, output_hidden_states=True)
        hidden = out.hidden_states[layer]                 # (B, L, H)
        mask = enc["attention_mask"].unsqueeze(-1).to(hidden.dtype)  # (B, L, 1)
        summed = (hidden * mask).sum(dim=1)               # (B, H)
        counts = mask.sum(dim=1).clamp(min=1.0)           # (B, 1)
        pooled = (summed / counts).float().cpu().numpy()  # (B, H)
        feats.append(pooled)

    return np.concatenate(feats, axis=0)


@dataclass
class DetectorReport:
    accuracy: float
    auc: float
    n_samples: int
    n_splits: int


class LatentDetector:
    """
    SVM over mean-pooled hidden states. Benign = 0, sponge = 1.

    Typical use:
        det = LatentDetector(model, tokenizer)
        report = det.fit(benign_texts, sponge_texts)
        print(report.accuracy, report.auc)
        probs = det.predict_proba(new_texts)
    """

    def __init__(self, model, tokenizer, batch_size=8):
        if not _HAS_SKLEARN:
            raise ImportError("scikit-learn is required for LatentDetector")
        self.model = model
        self.tokenizer = tokenizer
        self.batch_size = batch_size
        self.clf = None

    def _features(self, texts):
        return extract_features(self.model, self.tokenizer, texts,
                                batch_size=self.batch_size)

    def _make_pipeline(self, seed):
        # StandardScaler before the RBF SVM. Hidden-state features have large,
        # very uneven magnitudes (mean-pooled activations), and an unscaled RBF
        # SVM then ranks fine (high AUC) but its 0.5 probability threshold lands
        # badly, giving high AUC with mediocre accuracy. Scaling fixes that.
        # Inside cross_val_predict the scaler is refit on each fold's training
        # part only, so no test information leaks into it.
        return Pipeline([
            ("scale", StandardScaler()),
            ("svm", SVC(probability=True, random_state=seed)),
        ])

    def fit(self, benign_texts, sponge_texts, n_splits=5, seed=None,
            **_ignored):
        """
        Extract features and evaluate the detector with leakage-free
        stratified k-fold cross-validation.

        Every example is scored exactly once, by a model that was trained on
        the other folds only (the scaler and SVM are both refit per fold), so
        the reported accuracy and AUC never see their own test point during
        training. With ~40 examples this is far more trustworthy than a single
        small held-out split. A final model is then fit on all data for
        predicting genuinely new inputs via predict()/predict_proba().

        `**_ignored` swallows a legacy `test_size=` argument so older callers
        keep working; the evaluation is cross-validated, not a single split.
        """
        from common import config
        seed = config.SEED if seed is None else seed

        X = np.concatenate([self._features(benign_texts),
                            self._features(sponge_texts)], axis=0)
        y = np.concatenate([np.zeros(len(benign_texts)),
                            np.ones(len(sponge_texts))])

        # Guard n_splits against a tiny minority class.
        min_class = int(min((y == 0).sum(), (y == 1).sum()))
        n_splits = max(2, min(n_splits, min_class))
        skf = StratifiedKFold(n_splits=n_splits, shuffle=True,
                              random_state=seed)

        # Out-of-fold probabilities: each point scored while held out.
        oof_proba = cross_val_predict(
            self._make_pipeline(seed), X, y, cv=skf,
            method="predict_proba")[:, 1]
        oof_pred = (oof_proba >= 0.5).astype(int)

        acc = float((oof_pred == y).mean())
        fpr, tpr, _ = sk_metrics.roc_curve(y, oof_proba, pos_label=1)
        auc = float(sk_metrics.auc(fpr, tpr))

        # Final model on all data, for predicting new inputs later.
        self.clf = self._make_pipeline(seed).fit(X, y)

        # Stash out-of-fold scores (leakage-free, every point) for the ROC plot,
        # and all features/labels for the 2-D PCA projection.
        self.test_y_ = y
        self.test_scores_ = oof_proba
        self.features_all_ = X
        self.labels_all_ = y

        return DetectorReport(accuracy=acc, auc=auc,
                              n_samples=len(y), n_splits=n_splits)

    def predict(self, texts):
        if self.clf is None:
            raise RuntimeError("detector not fitted")
        return self.clf.predict(self._features(texts))

    def predict_proba(self, texts):
        if self.clf is None:
            raise RuntimeError("detector not fitted")
        return self.clf.predict_proba(self._features(texts))[:, 1]
