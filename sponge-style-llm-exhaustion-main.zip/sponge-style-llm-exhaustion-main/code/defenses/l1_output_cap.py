"""
Defense L1: output / compute cap.

Owner: DIPIT.  ***STUB — to be implemented.***

From the design report (Defense idea, L1):
    "A strict max_new_tokens and a per-request time budget. Since output length
     is the cost driver, this bounds the worst case directly."

This is the single most effective layer: it caps the cost driver (output
length) outright. Implement a wrapper around generation that enforces BOTH a
hard max_new_tokens and a wall-clock time budget (stop generation once the
budget is exceeded, e.g. via a StoppingCriteria that checks elapsed time).

Interface expected by guard.py / exp_defense_eval.py:
    capped_generate(model, tokenizer, input_ids, max_new_tokens_cap: int,
                    time_budget_s: float, eos_ids=None) -> (output_ids, n_new, hit_cap: bool)

Grounding: design report Sections 5/8; common/model_utils.generate for the base path.
"""

from __future__ import annotations

import time

import torch
from transformers import StoppingCriteria


class TimeBudgetCriteria(StoppingCriteria):
    """
    Stop generation once wall-clock time since construction exceeds
    `time_budget_s`. The token cap (`max_new_tokens`) is the deterministic
    first line of defense; this is the safety net against a pathologically slow
    token, so the worst-case *time* per request is bounded too.

    Returns a per-row BoolTensor (transformers >=4.x contract).
    """

    def __init__(self, time_budget_s: float):
        self.time_budget_s = time_budget_s
        self.start = time.time()
        self.fired = False

    def __call__(self, input_ids, scores, **kwargs) -> torch.BoolTensor:
        done = (time.time() - self.start) > self.time_budget_s
        if done:
            self.fired = True
        return torch.full((input_ids.shape[0],), done,
                          dtype=torch.bool, device=input_ids.device)


@torch.no_grad()
def capped_generate(model, tokenizer, input_ids, max_new_tokens_cap,
                    time_budget_s, eos_ids=None):
    """
    Greedy generation with BOTH a hard token cap and a wall-clock time budget.

    Returns (output_ids, n_new, hit_cap):
      * output_ids : 1-D LongTensor of the full sequence (prompt + generation);
      * n_new      : number of newly generated tokens;
      * hit_cap    : True if generation stopped because of the token cap or the
                     time budget (i.e. was cut off), False if it stopped
                     naturally on an EOS token.

    Same call shape as common.model_utils.generate, plus the two caps. This is
    L1: it bounds the cost driver (output length) directly, which is why it is
    the single most effective layer against a sponge.
    """
    device = next(model.parameters()).device
    if input_ids.dim() == 1:
        input_ids = input_ids.unsqueeze(0)
    input_ids = input_ids.to(device)
    prompt_len = input_ids.shape[1]
    attention_mask = torch.ones_like(input_ids)

    time_crit = TimeBudgetCriteria(time_budget_s)

    gen_kwargs = dict(
        attention_mask=attention_mask,
        max_new_tokens=max_new_tokens_cap,
        do_sample=False,
        pad_token_id=tokenizer.pad_token_id,
        stopping_criteria=[time_crit],
    )
    if eos_ids is not None:
        gen_kwargs["eos_token_id"] = eos_ids

    out = model.generate(input_ids, **gen_kwargs)
    n_new = int(out.shape[1] - prompt_len)

    # Did it stop naturally (EOS) or get cut off (token/time cap)?
    last_token = int(out[0, -1])
    stopped_on_eos = eos_ids is not None and last_token in set(eos_ids)
    hit_cap = time_crit.fired or (n_new >= max_new_tokens_cap) or not stopped_on_eos
    return out[0], n_new, hit_cap
