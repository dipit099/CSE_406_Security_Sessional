"""
Defense L6: configuration hygiene.

Owner: DIPIT.  ***STUB — to be implemented.***

From the design report (Defense idea, L6):
    "Hide logprobs and logit_bias and filter glitch tokens, so an attacker
     cannot use them to optimise."

This layer is mostly about the serving configuration, not the model forward.
Implement:
  * a request sanitiser that strips/blocks attacker-controllable fields the API
    should not expose (logprobs, logit_bias, and an over-large max_tokens);
  * a glitch-token filter: reject or strip inputs containing rarely-used
    special / reserved tokens that are known to destabilise generation.

Interface expected by guard.py:
    sanitise_request(payload: dict) -> dict            # returns cleaned payload
    contains_glitch_tokens(text: str, tokenizer) -> bool
    GLITCH_TOKEN_IDS(tokenizer) -> set[int]            # the ids we filter

Grounding: design report Section 8; the white-box levers Engorgio/GA rely on.
"""

from __future__ import annotations

from typing import Set

# Attacker-controllable fields the serving API should not expose. logprobs /
# logit_bias are the white-box levers an Engorgio/GA-style attacker would use to
# steer generation toward longer output; the rest are amplifiers (echo, n,
# best_of multiply the work per request). We strip them before the request ever
# reaches the model.
_STRIP_FIELDS = (
    "logprobs", "top_logprobs", "logit_bias", "echo",
    "n", "best_of", "presence_penalty", "frequency_penalty",
)

# Default ceiling a request's max_tokens is clamped to. The server can pass its
# own configured ceiling; this is only the fallback.
DEFAULT_MAX_TOKENS_CEILING = 512


def sanitise_request(payload: dict,
                     max_tokens_ceiling: int = DEFAULT_MAX_TOKENS_CEILING) -> dict:
    """
    Return a cleaned copy of `payload` with attacker-controllable fields removed
    and an over-large `max_tokens` clamped down to `max_tokens_ceiling`.

    Never mutates the input dict. A `max_tokens` of the wrong type or <= 0 is
    replaced with the ceiling (fail closed to a bounded value rather than trust
    a malformed field).
    """
    cleaned = {k: v for k, v in payload.items() if k not in _STRIP_FIELDS}

    if "max_tokens" in cleaned:
        mt = cleaned["max_tokens"]
        if isinstance(mt, bool) or not isinstance(mt, (int, float)) or mt <= 0:
            cleaned["max_tokens"] = max_tokens_ceiling
        else:
            cleaned["max_tokens"] = int(min(mt, max_tokens_ceiling))

    return cleaned


def GLITCH_TOKEN_IDS(tokenizer) -> Set[int]:
    """
    The set of token ids we treat as reserved / "glitch" tokens for filtering.

    We take the tokenizer's own special ids plus any added control tokens of the
    `<|...|>` form (Qwen's <|im_start|>, <|im_end|>, <|endoftext|> and the block
    of reserved <|...|> slots). A benign user prompt never encodes to these when
    special tokens are not added; if one shows up in raw user text it means the
    user is trying to inject control tokens (template confusion) or hit a
    reserved slot -- exactly what this layer is meant to catch. Deriving the set
    from the tokenizer keeps it correct across model families rather than
    hardcoding numeric ids for one vocab.
    """
    ids: Set[int] = set()
    for sid in (getattr(tokenizer, "all_special_ids", None) or []):
        ids.add(int(sid))
    added = getattr(tokenizer, "get_added_vocab", lambda: {})() or {}
    for tok_str, tid in added.items():
        if tok_str.startswith("<|") and tok_str.endswith("|>"):
            ids.add(int(tid))
    return ids


def contains_glitch_tokens(text: str, tokenizer) -> bool:
    """
    True if `text`, encoded as ordinary user input (no added special tokens),
    contains any reserved/glitch token id from GLITCH_TOKEN_IDS.
    """
    if not text:
        return False
    glitch = GLITCH_TOKEN_IDS(tokenizer)
    if not glitch:
        return False
    enc = tokenizer.encode(text, add_special_tokens=False)
    return any(tid in glitch for tid in enc)
