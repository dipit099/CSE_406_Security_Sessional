"""
Layered defense pipeline: put L1-L6 in front of the model (Figure 9).

Owner: DIPIT.  ***STUB — to be implemented.***

Wires the six layers into the single guarded path drawn in the report:

    incoming request
        -> L6 sanitise_request / glitch filter
        -> L2 input validation            (reject)        [Ahnaf's module]
        -> L5 latent detector             (reject)        [Ahnaf's module]
        -> L4 rate limit / quota          (reject)
        -> L1 output/compute cap  +  L3 output monitor    (truncate)
        -> bounded response

L2 (l2_input_validation) and L5 (l5_latent_detector) are already implemented by
Ahnaf and can be imported directly. L1/L3/L4/L6 are Dipit's modules above.

Interface expected by exp_defense_eval.py:
    class LayeredGuard:
        __init__(self, model, tokenizer, detector=None, ...)
        handle(self, client_id: str, prompt: str) -> dict
            # returns {"blocked": bool, "reason": str|None,
            #          "out_tokens": int, "latency_s": float, "hit_cap": bool}

Grounding: design report Section 8, Figure 9.
"""

from __future__ import annotations

import time

import torch

from common import model_utils
from defenses import l2_input_validation as l2      # Ahnaf's
from defenses import l5_latent_detector as l5        # Ahnaf's (via detector arg)
from defenses import l4_rate_limit as l4
from defenses import l6_config_hygiene as l6
from defenses.l1_output_cap import TimeBudgetCriteria
from defenses.l3_output_monitor import RepeatMonitorCriteria


class LayeredGuard:
    """
    Compose L1-L6 into one request handler, in the order drawn in Figure 9:

        prompt
          -> L6  contains_glitch_tokens          (block: control/glitch tokens)
          -> L2  validate_input                  (block: tokenizer-abuse / too long)
          -> L5  detector.predict                (block: latent sponge signature)
          -> L4  rate_limiter.allow              (block: over quota)
          -> L1 + L3 one guarded generate        (cap tokens+time, kill repetition)
          -> bounded response

    L2 and L5 are Ahnaf's modules. L5 needs a detector that was already .fit() on
    labelled data, so it is passed in via `detector` (None disables L5); build
    and fit one once (e.g. in exp_defense_eval) and reuse it, rather than fitting
    per request.

    handle() returns a dict:
        {"blocked": bool, "reason": str|None, "out_tokens": int,
         "latency_s": float, "hit_cap": bool, "killed": bool, "output": str}
    ("killed" and "output" are extra, beyond the minimum contract, so the server
    can return real text and the eval can see repetition kills.)
    """

    def __init__(self, model, tokenizer, detector=None,
                 max_new_tokens_cap=128, time_budget_s=20.0,
                 repeat_ngram=3, repeat_limit=20,
                 max_requests=1000, window_s=60.0, max_output_tokens=None,
                 thresholds=None):
        self.model = model
        self.tokenizer = tokenizer
        self.detector = detector
        self.max_new_tokens_cap = max_new_tokens_cap
        self.time_budget_s = time_budget_s
        self.repeat_ngram = repeat_ngram
        self.repeat_limit = repeat_limit
        self.thresholds = thresholds
        self.rate_limiter = l4.RateLimiter(max_requests, window_s, max_output_tokens)
        self.eos_ids = model_utils.get_eos_ids(tokenizer, model)
        self.enable_thinking = getattr(model, "_enable_thinking", False)

    @staticmethod
    def _blocked(reason, latency_s=0.0):
        return {"blocked": True, "reason": reason, "out_tokens": 0,
                "latency_s": latency_s, "hit_cap": False, "killed": False,
                "output": f"[blocked: {reason}]"}

    @torch.no_grad()
    def _guarded_generate(self, input_ids):
        """One generate call carrying BOTH L1's caps and L3's repetition monitor."""
        device = next(self.model.parameters()).device
        if input_ids.dim() == 1:
            input_ids = input_ids.unsqueeze(0)
        input_ids = input_ids.to(device)
        prompt_len = input_ids.shape[1]
        attn = torch.ones_like(input_ids)

        time_crit = TimeBudgetCriteria(self.time_budget_s)
        monitor = RepeatMonitorCriteria(prompt_len, self.repeat_ngram,
                                        self.repeat_limit)

        t0 = time.time()
        out = self.model.generate(
            input_ids, attention_mask=attn,
            max_new_tokens=self.max_new_tokens_cap, do_sample=False,
            pad_token_id=self.tokenizer.pad_token_id, eos_token_id=self.eos_ids,
            stopping_criteria=[time_crit, monitor],
        )
        latency = time.time() - t0
        n_new = int(out.shape[1] - prompt_len)
        last_token = int(out[0, -1])
        stopped_on_eos = last_token in set(self.eos_ids)
        hit_cap = (time_crit.fired or n_new >= self.max_new_tokens_cap
                   or (not stopped_on_eos and not monitor.killed))
        text = self.tokenizer.decode(out[0, prompt_len:], skip_special_tokens=True)
        return n_new, hit_cap, monitor.killed, latency, text

    def handle(self, client_id, prompt):
        # L6: reserved / control ("glitch") tokens in the raw input.
        if l6.contains_glitch_tokens(prompt, self.tokenizer):
            return self._blocked("L6: glitch/control tokens")

        # L2: tokenizer-abuse fingerprint / over-long input (Ahnaf's).
        vr = l2.validate_input(prompt, self.tokenizer, thresholds=self.thresholds)
        if not vr.ok:
            return self._blocked("L2: " + "; ".join(vr.reasons))

        # L5: latent sponge signature (Ahnaf's; only if a fitted detector given).
        if self.detector is not None:
            pred = int(self.detector.predict([prompt])[0])
            if pred == 1:
                return self._blocked("L5: latent detector")

        # L4: per-client rate / quota. Estimate cost as the cap so a request is
        # rejected up front when it would blow the token budget.
        if not self.rate_limiter.allow(client_id,
                                       est_output_tokens=self.max_new_tokens_cap):
            return self._blocked("L4: rate limit exceeded")

        # L1 + L3: the only path that actually generates, under both caps.
        input_ids = model_utils.build_chat_prompt(
            self.tokenizer, prompt, enable_thinking=self.enable_thinking)
        n_new, hit_cap, killed, latency, text = self._guarded_generate(input_ids)
        self.rate_limiter.record(client_id, n_new)

        return {"blocked": False, "reason": None, "out_tokens": n_new,
                "latency_s": latency, "hit_cap": hit_cap, "killed": killed,
                "output": text}
