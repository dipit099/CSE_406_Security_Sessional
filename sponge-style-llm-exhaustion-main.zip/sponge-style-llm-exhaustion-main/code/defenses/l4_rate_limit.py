"""
Defense L4: rate limiting and quotas.

Owner: DIPIT.  ***STUB — to be implemented.***

From the design report (Defense idea, L4):
    "A supporting layer only: rate limiting alone does not help, because a
     sponge raises cost per request, not request count."

Implement a simple per-client limiter and, importantly, show in the eval that
it does NOT stop a sponge on its own (that is the honest finding). A token-bucket
or fixed-window counter per client id is enough. A cost-aware quota (budget of
output tokens per minute, not requests per minute) is the interesting variant
worth including, since that DOES bite the sponge.

Interface expected by guard.py / exp_defense_eval.py:
    class RateLimiter:
        __init__(self, max_requests: int, window_s: float,
                 max_output_tokens: int | None = None)
        allow(self, client_id: str, est_output_tokens: int = 0) -> bool
        record(self, client_id: str, output_tokens: int) -> None

Grounding: design report Sections 5/8; Sponge_Examples.pdf (per-request cost,
not request rate, is the lever).
"""

from __future__ import annotations

import time
from typing import Dict, List, Optional, Tuple


class RateLimiter:
    """
    Per-client sliding-window limiter.

    Two independent caps, both over a rolling `window_s` window:
      * request count  -- at most `max_requests` requests per window;
      * output-token budget (optional) -- at most `max_output_tokens` generated
        tokens per window, when `max_output_tokens` is set.

    The request-count cap is the "classic" API rate limit, and the honest
    finding the report makes (Section 8) is that it does NOT stop a sponge: a
    sponge sends few requests but each is expensive, so a per-request-count
    limit lets it through. The output-token budget is the cost-aware variant
    that DOES bite the sponge, because it limits work, not request count.

    Usage is allow() -> generate -> record():
        if limiter.allow(cid, est_output_tokens=cap):
            ... generate ...
            limiter.record(cid, actual_out_tokens)

    In-memory and process-local (one worker), which is all the project needs;
    a real deployment would back this with a shared store.
    """

    def __init__(self, max_requests: int, window_s: float,
                 max_output_tokens: Optional[int] = None):
        self.max_requests = max_requests
        self.window_s = window_s
        self.max_output_tokens = max_output_tokens
        # client_id -> list of (timestamp, output_tokens)
        self._events: Dict[str, List[Tuple[float, int]]] = {}

    def _prune(self, client_id: str, now: float) -> List[Tuple[float, int]]:
        """Drop events older than the window and return the survivors."""
        events = [(ts, tok) for ts, tok in self._events.get(client_id, [])
                  if now - ts < self.window_s]
        self._events[client_id] = events
        return events

    def allow(self, client_id: str, est_output_tokens: int = 0) -> bool:
        """
        Whether a new request from `client_id` may proceed right now.

        `est_output_tokens` is the caller's up-front estimate of how many tokens
        this request could produce (e.g. the output cap); it is checked against
        the remaining token budget so an expensive request is rejected before it
        runs, not only after.
        """
        now = time.time()
        events = self._prune(client_id, now)

        if len(events) >= self.max_requests:
            return False

        if self.max_output_tokens is not None:
            used = sum(tok for _, tok in events)
            if used + est_output_tokens > self.max_output_tokens:
                return False

        return True

    def record(self, client_id: str, output_tokens: int) -> None:
        """Record a completed request's actual output-token cost."""
        self._events.setdefault(client_id, []).append((time.time(), output_tokens))
