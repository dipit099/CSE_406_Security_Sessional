"""AutoDoS / Crabs black-box LLM-DoS attack (Zhang et al., 2025).

DoS Attack Tree + Length-Trojan iterative optimization, ported to a local model.
See attack.run_autodos and local_backend.LocalChatModel.
"""

from .local_backend import LocalChatModel, ChatOutput
from .attack import (
    AutoDoSResult,
    run_autodos,
    generate_tree_prompt,
    iterative_optimization,
)

__all__ = [
    "LocalChatModel", "ChatOutput", "AutoDoSResult", "run_autodos",
    "generate_tree_prompt", "iterative_optimization",
]
