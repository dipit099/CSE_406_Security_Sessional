"""
AutoDoS local model backend.

Owner: Ahnaf.  The upstream AutoDoS repo talks to OpenAI-compatible HTTP APIs
(utils/language_models.py) through fastchat conversation templates. For an
offline Kaggle run we replace that whole layer with a single local Hugging Face
model behind one small `chat(system, user)` method. A black-box attack only ever
needs prompt-in / text-out, so this is a faithful substitution: the attacker,
judge and target can all be the SAME local model (self-attack), exactly as the
repo's default config runs Qwen-as-attacker against a Qwen target.

Returned token counts come from the tokenizer, matching the `usage.prompt_tokens`
/ `usage.completion_tokens` the repo read from the API -- these are what the
length / latency measurements use.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional

import torch


@dataclass
class ChatOutput:
    text: str
    prompt_tokens: int
    completion_tokens: int
    seconds: float
    hit_ceiling: bool  # stopped at max_new_tokens (no EOS) -> window filled


class LocalChatModel:
    """Thin wrapper over a loaded (model, tokenizer) providing chat generation.

    One instance can serve every AutoDoS role. `role_defaults` lets the attacker
    and judge sample (temperature > 0, as the paper uses T=0.5 for the attack
    model) while the target decodes greedily for reproducible length numbers.
    """

    def __init__(self, model, tokenizer, eos_ids=None):
        self.model = model
        self.tokenizer = tokenizer
        self.device = next(model.parameters()).device
        if eos_ids is None:
            from common import model_utils
            eos_ids = model_utils.get_eos_ids(tokenizer, model)
        self.eos_ids = eos_ids

    def _build_ids(self, system, user):
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": user})
        try:
            prompt_str = self.tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True)
        except Exception:
            # Some chat templates (e.g. Gemma) reject a 'system' role. Fold the
            # system content into the user turn; the model still gets it, just as
            # one user message.
            merged = f"{system}\n\n{user}" if system else user
            prompt_str = self.tokenizer.apply_chat_template(
                [{"role": "user", "content": merged}],
                tokenize=False, add_generation_prompt=True)
        ids = self.tokenizer.encode(prompt_str, add_special_tokens=False)
        return torch.tensor(ids, dtype=torch.long, device=self.device).unsqueeze(0)

    @torch.no_grad()
    def chat(self, system, user, max_new_tokens=1024, temperature=0.0,
             top_p=1.0) -> ChatOutput:
        ids = self._build_ids(system, user)
        plen = ids.shape[1]
        attn = torch.ones_like(ids)
        do_sample = temperature and temperature > 0
        kwargs = dict(
            attention_mask=attn, max_new_tokens=max_new_tokens,
            do_sample=bool(do_sample), pad_token_id=self.tokenizer.pad_token_id,
            eos_token_id=self.eos_ids,
        )
        if do_sample:
            kwargs.update(temperature=float(temperature), top_p=float(top_p))
        t0 = time.time()
        out = self.model.generate(ids, **kwargs)
        seconds = time.time() - t0
        new_ids = out[0, plen:]
        n_new = int(new_ids.shape[0])
        last = int(new_ids[-1]) if n_new else -1
        eos = last in set(self.eos_ids)
        text = self.tokenizer.decode(new_ids, skip_special_tokens=True)
        return ChatOutput(
            text=text, prompt_tokens=int(plen), completion_tokens=n_new,
            seconds=seconds, hit_ceiling=(n_new >= max_new_tokens and not eos),
        )
