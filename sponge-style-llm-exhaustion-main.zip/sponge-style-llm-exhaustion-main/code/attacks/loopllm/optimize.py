"""
LoopLLM white-box attack: the GCG-style cyclic-suffix optimiser.

Owner: Ahnaf.  Ported from the authors' repository
(https://github.com/neuron-insight-lab/LoopLLM, files main.py + utils/opt_utils.py
+ utils/string_utils.py) and adapted to this project's `common/` infra. The
optimisation math is preserved exactly; the changes are (1) integration with our
model loader / chat-prompt helpers, (2) a control-slice finder that is robust for
any cyclic-segment length c (the upstream one only holds for c == 1), and (3)
clearer structure. Grounded in LoopLLM (Li et al., AAAI 2026), Sec. "Methodology"
and Eq. (4).

Mechanism (paper Sec. Repetition-Inducing Prompt Optimization):
  * We append an adversarial suffix of `adv_len` tokens to the user instruction.
    The suffix is initialised as a *cyclic segment* of `c` tokens repeated
    (c = 1 -> LoopLLM-t token-level "* * * ..."; c = 5 -> LoopLLM-p phrase-level
    "* % & @ #").
  * The cycle loss (Eq. 4) is an untargeted objective that pushes the model's
    softmax probability of the cyclic-segment tokens toward 1 at EVERY output
    position, using the model's own current answer as the self-consistent target.
    Driving those tokens' probability up traps the model in a low-entropy
    repetition loop that runs to the generation ceiling.
  * The discrete suffix is optimised by gradient-based token search (GCG, Zou et
    al. 2023): compute the gradient of the loss w.r.t. a one-hot over the whole
    vocabulary at each suffix position, take the top-k most-promising swaps, build
    a batch of candidate suffixes, score them, and keep the best.

Nothing here caps the *attacker's* eventual generation length; caps that appear
below (fitness ceiling, answer truncation) are only to bound the optimiser's own
compute, exactly as in the paper.
"""

from __future__ import annotations

import gc

import numpy as np
import torch
import torch.nn as nn


# ---------------------------------------------------------------------------
# chat-prompt helper (kept local so the exact tokenisation the optimiser sees
# matches what SuffixManager slices; mirrors common.model_utils.build_chat_prompt
# but returns a plain python list where convenient)
# ---------------------------------------------------------------------------
def _render_chat(tokenizer, user_text, assistant_text=None,
                 add_generation_prompt=False, chat=True):
    """Return token ids (list[int]) for a single-turn prompt.

    Two-step render-then-encode (tokenize=False then encode) for the same
    version-stability reason documented in common.model_utils.
    """
    if not chat:
        text = user_text
        if assistant_text is not None:
            text = f"{text} {assistant_text.strip()}"
        return tokenizer.encode(text, add_special_tokens=True)

    messages = [{"role": "user", "content": user_text}]
    if assistant_text is not None:
        messages.append({"role": "assistant", "content": assistant_text})
    prompt_str = tokenizer.apply_chat_template(
        messages, tokenize=False,
        add_generation_prompt=add_generation_prompt and assistant_text is None,
    )
    return tokenizer.encode(prompt_str, add_special_tokens=False)


# ---------------------------------------------------------------------------
# not-allowed token set: non-ascii, specials, and the space-run variants of the
# cyclic marker tokens (so a candidate cannot drift into an equivalent token that
# breaks the fixed suffix length). Ported from utils/string_utils.get_nonascii_toks.
# ---------------------------------------------------------------------------
def get_nonascii_toks(tokenizer, device="cpu"):
    def is_ascii(s):
        return s.isascii() and s.isprintable()

    nonascii = []
    for i in range(tokenizer.vocab_size):
        if not is_ascii(tokenizer.decode([i])):
            nonascii.append(i)
    if tokenizer.all_special_ids:
        nonascii.extend(tokenizer.all_special_ids)

    # blacklist the growing "* ", "*  ", ... space-run variants so token count
    # per suffix position stays 1.
    token = "* "
    seen = set()
    while True:
        t = tokenizer(token, add_special_tokens=False).input_ids[-1]
        if t in seen:
            break
        seen.add(t)
        nonascii.append(t)
        token += " "
    return torch.tensor(sorted(set(nonascii)), device=device)


# ---------------------------------------------------------------------------
# SuffixManager: owns the prompt layout and the slices GCG needs.
# ---------------------------------------------------------------------------
class SuffixManager:
    """Track where the adversarial suffix and the target answer live in the
    tokenised prompt. The control (suffix) slice is computed ONCE from the
    initial all-cyclic suffix and then held fixed, because during optimisation
    the suffix tokens change to arbitrary values and can no longer be found by
    membership."""

    def __init__(self, tokenizer, instruction, cyclic_segment_ids, adv_len,
                 chat=True, loss_mode="paper"):
        self.tokenizer = tokenizer
        self.instruction = instruction
        self.cyclic_ids = list(cyclic_segment_ids)
        self.adv_len = adv_len
        self.chat = chat
        self.loss_mode = loss_mode
        # the tokens whose probability the cycle loss maximises
        self.special_id = list(cyclic_segment_ids)

        # initial suffix: cyclic segment repeated out to adv_len tokens
        init_ids = (self.cyclic_ids * adv_len)[:adv_len]
        self.adv_suffix = tokenizer.decode(init_ids)
        self.target = None
        self._init_slices()

    def _init_slices(self):
        adv_prompt = f"{self.instruction} {self.adv_suffix.strip()}"
        prompt_ids = _render_chat(self.tokenizer, adv_prompt,
                                  add_generation_prompt=True, chat=self.chat)
        cyclic_set = set(self.cyclic_ids)

        # last position whose token is a cyclic marker == last suffix token.
        cyclic_positions = [i for i, t in enumerate(prompt_ids) if t in cyclic_set]
        if not cyclic_positions:
            raise RuntimeError("LoopLLM: could not locate the cyclic suffix in "
                               "the tokenised prompt; check the marker tokens.")
        last = max(cyclic_positions)
        start = last - self.adv_len + 1
        self._control_slice = slice(start, last + 1)

        run = prompt_ids[self._control_slice]
        if not all(t in cyclic_set for t in run):
            # the instruction itself ended in a marker-like token; fall back to
            # the longest trailing contiguous run of markers.
            end = last + 1
            s = end - 1
            while s - 1 >= 0 and prompt_ids[s - 1] in cyclic_set:
                s -= 1
            self._control_slice = slice(end - self.adv_len, end)
        # target starts right where the generation prompt ends
        self._target_slice = slice(len(prompt_ids), None)
        self._prompt_len_no_target = len(prompt_ids)

    def update(self, adv_suffix=None, answer=None, truncation=1024):
        if adv_suffix is not None:
            self.adv_suffix = adv_suffix
        if answer is not None:
            ids = self.tokenizer.encode(answer, add_special_tokens=False)
            if len(ids) > truncation:
                answer = self.tokenizer.decode(ids[:truncation])
            self.target = answer

    def get_input_ids(self):
        """Full [instruction + suffix + target] ids as a 1-D LongTensor."""
        adv_prompt = f"{self.instruction} {self.adv_suffix.strip()}"
        ids = _render_chat(self.tokenizer, adv_prompt,
                           assistant_text=self.target,
                           add_generation_prompt=True, chat=self.chat)
        return torch.tensor(ids, dtype=torch.long)


# ---------------------------------------------------------------------------
# cycle loss (Eq. 4): softmax-normalised probability of the cyclic tokens,
# averaged over the target positions, driven toward 1 with a BCE objective.
# ---------------------------------------------------------------------------
def get_loss(logits, target_slice, special_id, loss_mode="paper"):
    """Cycle loss over the target positions.

    Two forms, IDENTICAL for a single cyclic token (c == 1, LoopLLM-t) but
    different for a multi-token cyclic segment (c > 1, LoopLLM-p):

    * loss_mode="paper" (default) -- Eq. (4) of Li et al.:
          L = -1/N sum_i sum_j log P_i^{t_j}
      i.e. -mean over positions of the SUM of the c cyclic tokens' LOG-probs.
      This pushes each output position toward a UNIFORM distribution over the c
      cyclic tokens, so the model cycles THROUGH the segment ("* % & @ #"),
      giving a genuine PHRASE-level loop.

    * loss_mode="repo" -- the authors' released code (opt_utils.get_loss):
          L = -mean_i log( sum_j P_i^{t_j} )   (BCE on the summed probability).
      This only asks that SOME cyclic token be likely, so for c > 1 it collapses
      to repeating the single easiest token ("* * *") -- which is why an early
      LoopLLM-p run produced token-level, not phrase-level, loops. Kept for
      exact reproduction of the repo.

    Cast to float32 first: on the bf16 victim, softmax/log over a 128k vocab is
    unstable in half precision. The cast is differentiable.
    """
    logits_t = logits[:, target_slice.start - 1:-1, :].float()
    if loss_mode == "paper":
        logp = torch.log_softmax(logits_t, dim=-1)
        sp = logp[:, :, special_id]                    # [b,pos] or [b,pos,c]
        per_pos = -sp.sum(dim=-1) if isinstance(special_id, list) else -sp
        return per_pos.mean(dim=-1)
    # loss_mode == "repo"
    prob = torch.softmax(logits_t, dim=-1)
    special_p = prob[:, :, special_id]
    if isinstance(special_id, list):
        special_p = special_p.sum(dim=-1)
    loss_s = nn.BCELoss(reduction="none")(
        special_p.clamp(0, 1), torch.ones_like(special_p))
    return loss_s.mean(dim=-1)


def get_gradients(model, input_ids, suffix_manager):
    control_slice = suffix_manager._control_slice
    target_slice = suffix_manager._target_slice
    special_id = suffix_manager.special_id

    embed_weights = model.get_input_embeddings().weight
    one_hot = torch.zeros(
        input_ids[control_slice].shape[0], embed_weights.shape[0],
        device=model.device, dtype=embed_weights.dtype)
    one_hot.scatter_(1, input_ids[control_slice].unsqueeze(1), 1)
    one_hot.requires_grad_()
    input_embeds = one_hot @ embed_weights

    embeds = embed_weights[input_ids].detach()
    full_embeds = torch.cat([
        embeds[:control_slice.start, :],
        input_embeds,
        embeds[control_slice.stop:, :],
    ], dim=0).unsqueeze(0)

    logits = model(inputs_embeds=full_embeds).logits
    loss = get_loss(logits, target_slice, special_id,
                    loss_mode=getattr(suffix_manager, "loss_mode", "paper"))

    model.zero_grad()
    loss.backward()
    grad = one_hot.grad.clone()
    grad = grad / grad.norm(dim=-1, keepdim=True)
    one_hot.grad.zero_()
    return grad


def _model_forward(model, input_ids, target_slice, special_id, batch_size=8,
                   loss_mode="paper"):
    losses = []
    for i in range(0, input_ids.shape[0], batch_size):
        batch = input_ids[i:i + batch_size]
        logits = model(input_ids=batch).logits
        losses.append(get_loss(logits, target_slice, special_id, loss_mode=loss_mode))
    out = torch.cat(losses, dim=0)
    del logits
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return out


def get_all_losses(model, tokenizer, input_ids, new_suffixes, suffix_manager,
                   batch_size=8):
    control_slice = suffix_manager._control_slice
    target_slice = suffix_manager._target_slice
    special_id = suffix_manager.special_id

    max_len = control_slice.stop - control_slice.start
    test_ids = tokenizer(new_suffixes, add_special_tokens=False, max_length=max_len,
                         padding="max_length", truncation=True,
                         return_tensors="pt").input_ids.to(model.device)
    locs = torch.arange(control_slice.start, control_slice.stop,
                        device=model.device).repeat(test_ids.shape[0], 1)
    ids = torch.scatter(
        input_ids.unsqueeze(0).repeat(test_ids.shape[0], 1).to(model.device),
        1, locs, test_ids)
    return _model_forward(model, ids, target_slice, special_id, batch_size,
                          loss_mode=getattr(suffix_manager, "loss_mode", "paper"))


def sample_control(control_toks, grad, batch_size, topk, not_allowed_tokens=None):
    if not_allowed_tokens is not None:
        grad = grad.clone()
        grad[:, not_allowed_tokens] = np.inf
    top_indices = (-grad).topk(topk, dim=1).indices
    control_toks = control_toks.to(grad.device)
    original = control_toks.repeat(batch_size, 1)
    new_pos = torch.arange(0, len(control_toks), len(control_toks) / batch_size,
                           device=grad.device).type(torch.int64)
    new_val = torch.gather(top_indices[new_pos], 1,
                           torch.randint(0, topk, (batch_size, 1), device=grad.device))
    new_toks = original.scatter_(1, new_pos.unsqueeze(-1), new_val)
    return new_toks.unique(dim=0)


def get_filtered_cands(tokenizer, control_cand, cur_suffix_tokens):
    cands, seen = [], set()
    length = len(cur_suffix_tokens)
    curr = tokenizer.decode(cur_suffix_tokens, skip_special_tokens=True)
    for i in range(control_cand.shape[0]):
        decoded = tokenizer.decode(control_cand[i], skip_special_tokens=True)
        if (decoded != curr
                and len(tokenizer(decoded, add_special_tokens=False).input_ids) == length
                and decoded not in seen):
            cands.append(decoded)
            seen.add(decoded)
    if not cands:
        raise RuntimeError("LoopLLM: no valid candidate suffix this step.")
    return cands


@torch.no_grad()
def is_entropy_low(model, input_ids, threshold=0.1):
    logits = model(input_ids).logits
    logits_ans = logits[0, -100:, :].float()   # bf16-safe entropy
    probs = torch.softmax(logits_ans, dim=-1)
    entropy = -torch.sum(probs * torch.log(probs + 1e-8), dim=-1)
    return entropy.mean().item() < threshold
