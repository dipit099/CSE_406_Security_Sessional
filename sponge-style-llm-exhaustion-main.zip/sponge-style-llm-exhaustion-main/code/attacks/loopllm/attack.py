"""
LoopLLM white-box attack: high-level crafting driver.

Owner: Ahnaf.  Wraps the GCG optimiser in optimize.py into a single
`craft_suffix(...)` call that returns the crafted adversarial suffix plus a
record of how the optimisation went. Faithful to the authors' individual_gcg
loop (main.py) but structured as a reusable function and integrated with our
`common/` model helpers.

Two variants, both from the paper:
  * c = 1  -> LoopLLM-t (token-level repetition, "* * * ...").  Highest ASR; a
             single-token consecutive-repeat monitor (paper Table 3) filters it.
  * c = 5  -> LoopLLM-p (phrase-level repetition, "* % & @ #").  Meant to survive
             a single-token monitor.  NOTE: this only holds with the paper's
             Eq. 4 cycle loss (`loss_mode="paper"`, the default). The released
             repo's loss (`loss_mode="repo"`) collapses c>1 to a single-token
             loop, so LoopLLM-p behaves like LoopLLM-t -- observed on our first
             Llama-3.1-8B run. See optimize.get_loss.

The crafted suffix is appended to ANY user instruction; the final, uncapped
measurement of what it does to the victim is done by the experiments layer, not
here. Here we only optimise, using a bounded fitness signal to keep the search's
own compute in check (paper: "Optimization is allowed for up to 20 steps, with
early stopping after success").
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import List, Optional

import torch

from . import optimize as O


# Cyclic-segment marker strings, in the paper's order. The id derivation mirrors
# the upstream repo: encode the marker repeated many times and take a stable
# mid-sequence token id, which is the single-token form of the marker.
MARKERS = ["* ", "% ", "& ", "@ ", "# "]


def _marker_ids(tokenizer, c):
    ids = []
    for m in MARKERS[:c]:
        enc = tokenizer.encode(m * 20)
        ids.append(enc[-5])
    return ids


@dataclass
class LoopLLMResult:
    suffix_text: str
    suffix_ids: List[int]
    cyclic_segment_ids: List[int]
    c: int
    adv_len: int
    instruction: str
    steps_run: int
    succeeded: bool
    final_loss: float
    best_eval_len: int
    loss_curve: List[float] = field(default_factory=list)
    seconds: float = 0.0

    def as_dict(self):
        d = self.__dict__.copy()
        return d


@torch.no_grad()
def _greedy_answer(model, tokenizer, suffix_manager, chat, ceiling, eos_ids):
    """Generate greedily with the current suffix; return (text, n_new, hit_ceiling)."""
    adv_prompt = f"{suffix_manager.instruction} {suffix_manager.adv_suffix.strip()}"
    ids = O._render_chat(tokenizer, adv_prompt, add_generation_prompt=True, chat=chat)
    ids = torch.tensor(ids, dtype=torch.long, device=model.device).unsqueeze(0)
    plen = ids.shape[1]
    attn = torch.ones_like(ids)
    out = model.generate(ids, attention_mask=attn, max_new_tokens=ceiling,
                         do_sample=False, pad_token_id=tokenizer.pad_token_id,
                         eos_token_id=eos_ids)
    new_ids = out[0, plen:]
    n_new = int(new_ids.shape[0])
    last = int(new_ids[-1]) if n_new else -1
    eos = last in set(eos_ids)
    hit_ceiling = (n_new >= ceiling) and not eos
    text = tokenizer.decode(new_ids, skip_special_tokens=True)
    return text, n_new, hit_ceiling


def craft_suffix(model, tokenizer, instruction, *, c=1, adv_len=30, steps=20,
                 topk=64, num_candidate=128, once_forward_batch=8,
                 fitness_ceiling=384, eval_interval=1, chat=True,
                 eos_ids=None, verbose=True, seed=None, loss_mode="paper"):
    """Optimise a LoopLLM suffix for one instruction and return a LoopLLMResult.

    `fitness_ceiling` bounds the optimiser's per-step generation ONLY -- it is
    the search signal (a candidate that reaches this length without EOS is
    "succeeding"), not a cap on the real attack. The paper calls this a
    necessity of the search, not part of the attack.
    """
    if seed is not None:
        torch.manual_seed(seed)
    if eos_ids is None:
        from common import model_utils
        eos_ids = model_utils.get_eos_ids(tokenizer, model)

    device = model.device
    cyclic_ids = _marker_ids(tokenizer, c)
    not_allowed = O.get_nonascii_toks(tokenizer, device=device)

    sm = O.SuffixManager(tokenizer, instruction, cyclic_ids, adv_len, chat=chat,
                         loss_mode=loss_mode)

    # seed the self-consistent target with the model's current answer
    ans, n0, hit0 = _greedy_answer(model, tokenizer, sm, chat, fitness_ceiling, eos_ids)
    sm.update(answer=ans)

    loss_curve = []
    best_eval_len = n0
    succeeded = hit0
    final_loss = float("nan")
    t0 = time.time()
    steps_run = 0

    for step in range(steps):
        steps_run = step + 1
        input_ids = sm.get_input_ids().to(device)

        grad = O.get_gradients(model, input_ids, sm)
        with torch.no_grad():
            cur_suffix_tokens = input_ids[sm._control_slice]
            cand_toks = O.sample_control(cur_suffix_tokens, grad, num_candidate,
                                         topk, not_allowed_tokens=not_allowed)
            cands = O.get_filtered_cands(tokenizer, cand_toks, cur_suffix_tokens)
            losses = O.get_all_losses(model, tokenizer, input_ids, cands, sm,
                                      batch_size=once_forward_batch)
            best = int(losses.argmin())
            sm.update(adv_suffix=cands[best])
            final_loss = float(losses[best])
            loss_curve.append(final_loss)

        if (step + 1) % eval_interval == 0:
            ans, n_new, hit = _greedy_answer(model, tokenizer, sm, chat,
                                             fitness_ceiling, eos_ids)
            sm.update(answer=ans)
            best_eval_len = max(best_eval_len, n_new)
            if verbose:
                print(f"    [loopllm c={c}] step {step + 1:2d}/{steps} "
                      f"loss={final_loss:.4f} eval_len={n_new} hit_ceiling={hit}",
                      flush=True)
            if hit:
                succeeded = True
                # confirm it is a genuine low-entropy loop before stopping early
                full = sm.get_input_ids().to(device).unsqueeze(0)
                if O.is_entropy_low(model, full):
                    break
        del input_ids, grad
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    suffix_ids = tokenizer.encode(sm.adv_suffix, add_special_tokens=False)
    return LoopLLMResult(
        suffix_text=sm.adv_suffix,
        suffix_ids=suffix_ids,
        cyclic_segment_ids=cyclic_ids,
        c=c, adv_len=adv_len, instruction=instruction,
        steps_run=steps_run, succeeded=bool(succeeded),
        final_loss=final_loss, best_eval_len=int(best_eval_len),
        loss_curve=loss_curve, seconds=round(time.time() - t0, 1),
    )


def craft_universal_suffix(model, tokenizer, instructions, *, c=1, adv_len=30,
                           steps=20, topk=64, num_candidate=128,
                           once_forward_batch=8, fitness_ceiling=384,
                           eval_interval=1, chat=True, eos_ids=None, verbose=True,
                           seed=None, loss_mode="paper"):
    """Optimise ONE suffix that works across several instructions (GCG-universal,
    Zou et al. style): each step aggregates the gradient AND the candidate losses
    over all `instructions`, so the single suffix is pushed to induce the loop on
    every one of them. This is NOT the LoopLLM paper's per-input protocol; it is
    an optional stronger-generalisation variant (one reusable string). Returns a
    LoopLLMResult whose `instruction` is the joined training set.
    """
    if seed is not None:
        torch.manual_seed(seed)
    if eos_ids is None:
        from common import model_utils
        eos_ids = model_utils.get_eos_ids(tokenizer, model)
    device = model.device
    cyclic_ids = _marker_ids(tokenizer, c)
    not_allowed = O.get_nonascii_toks(tokenizer, device=device)

    # one SuffixManager per training instruction; they share the suffix string.
    sms = [O.SuffixManager(tokenizer, ins, cyclic_ids, adv_len, chat=chat,
                           loss_mode=loss_mode) for ins in instructions]
    for sm in sms:
        ans, _, _ = _greedy_answer(model, tokenizer, sm, chat, fitness_ceiling, eos_ids)
        sm.update(answer=ans)

    loss_curve, final_loss, succeeded, steps_run = [], float("nan"), False, 0
    t0 = time.time()
    for step in range(steps):
        steps_run = step + 1
        # aggregate gradient over prompts (all aligned by suffix position)
        grad_sum = None
        input_ids_list = []
        for sm in sms:
            iid = sm.get_input_ids().to(device)
            input_ids_list.append(iid)
            g = O.get_gradients(model, iid, sm)
            grad_sum = g if grad_sum is None else grad_sum + g
        with torch.no_grad():
            cur = input_ids_list[0][sms[0]._control_slice]
            cand_toks = O.sample_control(cur, grad_sum, num_candidate, topk,
                                         not_allowed_tokens=not_allowed)
            cands = O.get_filtered_cands(tokenizer, cand_toks, cur)
            # sum candidate losses across all prompts
            loss_sum = None
            for iid, sm in zip(input_ids_list, sms):
                l = O.get_all_losses(model, tokenizer, iid, cands, sm,
                                     batch_size=once_forward_batch)
                loss_sum = l if loss_sum is None else loss_sum + l
            best = int(loss_sum.argmin())
            for sm in sms:
                sm.update(adv_suffix=cands[best])
            final_loss = float(loss_sum[best]) / len(sms)
            loss_curve.append(final_loss)

        if (step + 1) % eval_interval == 0:
            hits = 0
            for sm in sms:
                ans, n_new, hit = _greedy_answer(model, tokenizer, sm, chat,
                                                 fitness_ceiling, eos_ids)
                sm.update(answer=ans)
                hits += int(hit)
            if verbose:
                print(f"    [loopllm-universal c={c}] step {step + 1:2d}/{steps} "
                      f"avg_loss={final_loss:.4f} hit={hits}/{len(sms)}", flush=True)
            if hits == len(sms):
                succeeded = True
                break
        del input_ids_list, grad_sum
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    suffix_text = sms[0].adv_suffix
    return LoopLLMResult(
        suffix_text=suffix_text,
        suffix_ids=tokenizer.encode(suffix_text, add_special_tokens=False),
        cyclic_segment_ids=cyclic_ids, c=c, adv_len=adv_len,
        instruction=" || ".join(instructions), steps_run=steps_run,
        succeeded=bool(succeeded), final_loss=final_loss, best_eval_len=0,
        loss_curve=loss_curve, seconds=round(time.time() - t0, 1))


def build_attack_prompt(instruction, suffix_text):
    """The exact user string the victim receives: instruction + crafted suffix."""
    return f"{instruction} {suffix_text.strip()}"
