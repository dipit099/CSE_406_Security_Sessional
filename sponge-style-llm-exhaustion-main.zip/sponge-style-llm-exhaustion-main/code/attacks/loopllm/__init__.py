"""LoopLLM white-box energy-latency attack (Li et al., AAAI 2026).

Repetition-inducing suffix optimisation via GCG. See attack.craft_suffix.
"""

from .attack import (
    LoopLLMResult,
    craft_suffix,
    craft_universal_suffix,
    build_attack_prompt,
    MARKERS,
)

__all__ = ["LoopLLMResult", "craft_suffix", "craft_universal_suffix",
           "build_attack_prompt", "MARKERS"]
