"""
Tier 1: naive baselines (tokenizer-abuse input + naive output-forcing prompt).

Owner: DIPIT.  ***STUB — to be implemented.***

These are the simple baselines that prove the cost mechanism before the graded
Tier-2 attacks. From the design report (Section 5.1):

  * Tokenizer-abuse input: the same visible characters split into many more
    tokens, inflating prefill cost. Use the Sponge paper's example as the
    template: "Athazagoraphobia" is 4 tokens, the typo "Athazagoraphpbia" is
    7, and "A/h/z/g/r/p/p/i/" (slashed, one char per piece) is 16 tokens for
    the same 16 characters. Build a helper that takes ordinary text and returns
    a same-length-ish string with a much higher tokens-per-character ratio
    (e.g. by inserting separators between characters).

  * Naive output-forcing prompt: a plain instruction that simply asks for a
    very long output, e.g. "count from 1 to 100000, one per line". This is the
    baseline the optimised attacks (Tier 2a/2b) are expected to beat.

Interfaces expected by the rest of the codebase / notebook:
    tokenizer_abuse_prompt(text: str, mode: str = "slash") -> str
    output_forcing_prompt() -> str
    tokens_per_char(text: str, tokenizer) -> float   # handy for verifying abuse

Grounding: Sponge_Examples.pdf Section 4.2.1; design report Section 5.1.
Keep it honest: report the real tokens-per-char before/after, no faked numbers.
"""

from __future__ import annotations


def tokenizer_abuse_prompt(text: str, mode: str = "slash") -> str:
    """
    Return a version of `text` that tokenizes into many more tokens than the
    original while keeping (roughly) the same visible characters.

    The trick, from Sponge_Examples: subword tokenizers merge common character
    runs into single tokens ("Athazagoraphobia" -> a handful of BPE merges), so
    breaking those runs forces one token per fragment and inflates prefill cost
    for the same visible length.

    Modes:
      * "slash" (default): insert '/' between every character
        ("hello" -> "h/e/l/l/o"). Highest tokens/char; each character becomes
        its own token and each separator adds more.
      * "space": insert a space between every character ("hello" -> "h e l l o").
        Same idea, slightly gentler ratio; reads a little more naturally.
      * "typo": leave length unchanged but transpose two adjacent characters
        inside each word of length >= 4, breaking the BPE merges without adding
        any separator characters. This is the paper's "Athazagoraphpbia"
        (misspelling) variant. Deterministic, so results reproduce.

    Empty input returns "" unchanged.
    """
    if not text:
        return text

    if mode == "slash":
        return "/".join(text)
    if mode == "space":
        return " ".join(text)
    if mode == "typo":
        return _transpose_words(text)
    raise ValueError(
        f"unknown mode {mode!r}; expected one of 'slash', 'space', 'typo'")


def _transpose_words(text: str) -> str:
    """Swap characters at indices 1 and 2 in every whitespace-delimited word of
    length >= 4. Same length, same rough appearance, but the altered spelling no
    longer matches the tokenizer's learned merges, so it fragments into more
    tokens. Deterministic."""
    out_words = []
    for word in text.split(" "):
        if len(word) >= 4:
            chars = list(word)
            chars[1], chars[2] = chars[2], chars[1]
            out_words.append("".join(chars))
        else:
            out_words.append(word)
    return " ".join(out_words)


def output_forcing_prompt() -> str:
    """
    A plain, hand-written instruction that asks the model for a very long,
    hard-to-stop output. This is the naive Tier-1 baseline the optimised Tier-2
    attacks (genetic search, Engorgio) are expected to beat.

    Worded independently from Ahnaf's exp_queue_dos.DEFAULT_SPONGE_PROMPT so
    Tier 1 has its own clearly-attributed baseline.
    """
    return (
        "List every integer from 1 to 100000 in order, one number per line. "
        "Do not skip any number, do not summarise, do not stop early, and do "
        "not add any commentary before or after the list."
    )


def tokens_per_char(text: str, tokenizer) -> float:
    """
    Tokens-per-character of `text` under `tokenizer` (special tokens excluded).

    This is the tokenizer-abuse fingerprint: ordinary English sits around
    0.2-0.25 on the Qwen tokenizer, while character-split abuse climbs well
    above that (slash-split approaches 1.0+). Returns 0.0 for empty input.
    """
    if not text:
        return 0.0
    n_tokens = len(tokenizer.encode(text, add_special_tokens=False))
    return n_tokens / len(text)
