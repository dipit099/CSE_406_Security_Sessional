"""
Tier 2b: EOS-suppression sponge attack (white-box), the Engorgio method.

Owner: Ahnaf. This is the hardest attack in the project.

Reimplements Dong et al., "An Engorgio Prompt Makes Large Language Model
Babble on" (ICLR 2025). Grounded in the PAPER (not the reference repo), with a
few deviations that are called out and justified for our project.

Paper mechanics we follow (section / equation references are to the paper):
  * Proxy distribution theta in R^{S x V}, where S is the whole soft-sequence
    length. The paper sets S to the model's maximum allowable length so the
    self-mentor loss has room to shape a long output (Sec 3.2). We expose
    `soft_len` and default it high; the first `trigger_len` positions become
    the crafted prompt read off at the end.
  * Gumbel-Softmax to turn theta into weights w, then a blended embedding
    e~(theta_i) = sum_j w_ij e(j)  (Eq 2-3), temperature tau = 1 (Sec 4.1).
  * <EOS> escape loss = sum over positions of P(<EOS>) (Eq 6), driven down so
    the model is unwilling to stop anywhere, including the trigger region.
  * Self-mentor loss = soft cross-entropy tying position i's prediction to
    w_{i+1} (Eq 7), which keeps the soft sequence self-consistent so the
    discrete read-off actually induces a long output.
  * Objective  min_theta  L_esc + lambda * L_sm   (Eq 5), lambda = 1, Adam
    lr = 0.1, ~300 steps, trigger length t = 32 (Sec 4.1).
  * Testing stage: read off the argmax token per trigger position once theta
    has converged (Sec 3.1). The paper argues self-mentor makes this readout
    reliable without per-candidate evaluation.

Deviations (informed decisions for our setting):
  * Base vs chat models. The paper targets base and SFT models. Base models
    (gpt2, opt, the non-instruct Qwen) have no chat template, so the trigger
    is the whole prompt (prefix = optional BOS, no infix). Instruct models get
    the chat template as the fixed prefix/infix around the trigger.
  * Semantic prefix (Sec 4.4 / Table 4, "Prefix + Engorgio"). SFT/instruct
    models can be confused into SHORT outputs; fusing a fixed semantic prefix
    that asks for a long answer restores effectiveness. Off by default, on for
    the hard instruct case.
  * Optional selection-by-generation. The paper reads off at convergence and
    does not evaluate candidates. As a *diagnostic only* (and because a 0.5B
    instruct model is far smaller than the paper's models), we can optionally
    measure the real greedy length of the discrete trigger every few steps and
    keep the strongest. This uses only the attacker's own white-box forward
    pass (no evaluation-set leakage). Default OFF to match the paper; turn on
    to diagnose the soft->discrete gap on a given model.

No leakage: the attack uses only the model's own weights/gradients (the
white-box threat model) and the real <EOS> ids. It never touches any
evaluation set.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import List, Optional

import torch
import torch.nn.functional as F

from common import model_utils, config


# ----------------------------------------------------------------------------
# Chat-template scaffolding
# ----------------------------------------------------------------------------
_SENTINEL = "ENGORGIO_TRIGGER"


def build_template_parts(tokenizer, enable_thinking=False, chat=None):
    """
    Return (prefix_ids, tail_ids): the real token ids that bracket the trigger.

    Instruct model: render the chat template around a unique sentinel and split
    on it, so we never rely on a placeholder round-tripping through the
    tokenizer. Base model (no template): the trigger is the whole prompt, so the
    prefix is just an optional BOS and there is no tail.
    """
    if chat is None:
        chat = model_utils.has_chat_template(tokenizer)

    if not chat:
        bos = getattr(tokenizer, "bos_token_id", None)
        prefix_ids = [int(bos)] if bos is not None else []
        return prefix_ids, []

    messages = [{"role": "user", "content": _SENTINEL}]
    try:
        templated = tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True,
            enable_thinking=enable_thinking,
        )
    except TypeError:
        templated = tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True,
        )
    if _SENTINEL not in templated:
        raise RuntimeError("sentinel lost in chat template; cannot locate trigger")
    prefix_str, tail_str = templated.split(_SENTINEL, 1)
    prefix_ids = tokenizer.encode(prefix_str, add_special_tokens=False)
    tail_ids = tokenizer.encode(tail_str, add_special_tokens=False)
    return prefix_ids, tail_ids


# ----------------------------------------------------------------------------
# Losses (Eq 6 and Eq 7)
# ----------------------------------------------------------------------------
def soft_cross_entropy(inputs, target):
    """
    Sum_i sum_v -log_softmax(inputs)[i, v] * target[i, v].
    'sum' reduction, exactly SoftCrossEntropy(reduction='sum') in the paper.
    """
    log_likelihood = -F.log_softmax(inputs, dim=-1)
    return torch.sum(log_likelihood * target)


def eos_escape_loss(logits_slice, eos_ids):
    """Sum of P(<EOS>) over positions, summed across all stop-token ids (Eq 6)."""
    probs = F.softmax(logits_slice, dim=-1)
    return probs[:, eos_ids].sum()


# ----------------------------------------------------------------------------
# Attack
# ----------------------------------------------------------------------------
@dataclass
class EngorgioResult:
    trigger_ids: List[int]
    trigger_text: str
    history: List[dict] = field(default_factory=list)
    # real (discrete) greedy length of the trigger we return, when measured.
    best_out_tokens: Optional[int] = None
    eval_history: List[dict] = field(default_factory=list)
    # the final-iteration argmax trigger (paper's plain readout), kept so we
    # can compare it against a selected-by-generation trigger when that is on.
    final_trigger_ids: Optional[List[int]] = None
    final_trigger_text: Optional[str] = None
    # the semantic prefix actually prepended (empty string if none).
    semantic_prefix: str = ""


class EngorgioAttack:
    """
    White-box <EOS>-suppression attack (Engorgio).

    Parameters
    ----------
    trigger_len : tokens in the crafted prompt we read off (paper default 32).
    soft_len    : total soft-sequence length = trigger + imagined continuation.
                  The paper uses the model's max length; larger gives the
                  self-mentor loss more room at higher memory cost.
    iters       : optimisation steps (paper ~300).
    lr          : Adam learning rate (paper 0.1).
    lam         : weight on the self-mentor loss relative to <EOS>-escape
                  (paper lambda = 1).
    warmup_iters: first steps that use ONLY the <EOS>-escape loss.
    tau         : Gumbel-Softmax temperature (paper 1.0).
    trigger_block_eos : force the trigger positions never to select a stop token
                  (an <EOS> inside the prompt would be illegal; paper Sec 3.3).
    initial_coeff: logit boost applied to one random token per position at init,
                  so optimisation "starts with a random prompt" (paper Sec 4.1)
                  rather than a uniform distribution.
    semantic_prefix : optional fixed text prepended to the trigger (Table 4,
                  "Prefix + Engorgio"), which helps on silent SFT models.
    chat        : None auto-detects a chat template; True/False forces it.
    select_by_generation : diagnostic; measure the real greedy length of the
                  discrete trigger every eval_interval steps and return the
                  strongest. Default OFF (paper reads off at convergence).
    """

    def __init__(self, model, tokenizer, trigger_len=32, soft_len=512,
                 iters=300, lr=0.1, lam=1.0, warmup_iters=50, tau=1.0,
                 trigger_block_eos=True, initial_coeff=15.0,
                 semantic_prefix=None, chat=None,
                 converge_patience=50, converge_tol=1e-3,
                 log_interval=50, seed=None,
                 select_by_generation=False, eval_interval=25,
                 eval_max_new_tokens=256):
        self.model = model
        self.tokenizer = tokenizer
        self.trigger_len = trigger_len
        self.soft_len = soft_len
        self.iters = iters
        self.lr = lr
        self.lam = lam
        self.warmup_iters = warmup_iters
        self.tau = tau
        self.trigger_block_eos = trigger_block_eos
        self.initial_coeff = initial_coeff
        self.converge_patience = converge_patience
        self.converge_tol = converge_tol
        self.log_interval = log_interval
        self.select_by_generation = select_by_generation
        self.eval_interval = eval_interval
        self.eval_max_new_tokens = eval_max_new_tokens
        if seed is not None:
            config.set_seed(seed)

        self.device = next(model.parameters()).device
        self.eos_ids = model_utils.get_eos_ids(tokenizer, model)
        self.enable_thinking = getattr(model, "_enable_thinking", False)
        self.chat = model_utils.has_chat_template(tokenizer) if chat is None else chat

        # Detached embedding matrix (vocab, hidden).
        emb = model.get_input_embeddings()
        self.E = emb.weight.detach()
        self.vocab_size = self.E.shape[0]

        prefix_ids, tail_ids = build_template_parts(
            tokenizer, self.enable_thinking, chat=self.chat)

        # Optional semantic prefix, fused as fixed real tokens right before the
        # trigger (so it is part of the crafted prompt at test time too).
        self.semantic_prefix = semantic_prefix or ""
        sem_ids = (tokenizer.encode(self.semantic_prefix, add_special_tokens=False)
                   if self.semantic_prefix else [])
        self.sem_ids = sem_ids

        self.prefix_ids = prefix_ids
        self.tail_ids = tail_ids
        self.prefix_len = len(prefix_ids) + len(sem_ids)
        self.tail_len = len(tail_ids)
        pre_all = prefix_ids + sem_ids
        self.prefix_embeds = (self.E[torch.tensor(pre_all, device=self.device)]
                              if pre_all else
                              torch.empty(0, self.E.shape[1], device=self.device,
                                          dtype=self.E.dtype))
        self.tail_embeds = (self.E[torch.tensor(tail_ids, device=self.device)]
                            if tail_ids else
                            torch.empty(0, self.E.shape[1], device=self.device,
                                        dtype=self.E.dtype))

        if soft_len <= trigger_len:
            raise ValueError("soft_len must be > trigger_len (need a continuation)")

    # -- assemble the full input embedding sequence from the soft prompt -----
    def _wrap(self, soft_embeds):
        # soft_embeds: (soft_len, hidden)
        trigger = soft_embeds[:self.trigger_len]
        cont = soft_embeds[self.trigger_len:]
        parts = [self.prefix_embeds, trigger, self.tail_embeds, cont]
        parts = [p for p in parts if p.numel() > 0]
        return torch.cat(parts, dim=0).unsqueeze(0)  # (1, total, hidden)

    def fit(self, verbose=True) -> EngorgioResult:
        device = self.device
        dtype = self.E.dtype
        eos_idx = torch.tensor(self.eos_ids, device=device)

        # theta / log-coefficients: (soft_len, vocab). Initialise "from a random
        # prompt" (paper Sec 4.1): one random token per position gets a positive
        # logit so the starting distribution is a soft random prompt, not
        # uniform. (initial_coeff = 0 would collapse to uniform.)
        log_coeffs = torch.zeros(self.soft_len, self.vocab_size,
                                 dtype=dtype, device=device)
        init_ids = torch.randint(0, self.vocab_size, (self.soft_len,))
        log_coeffs[torch.arange(self.soft_len), init_ids] = self.initial_coeff
        log_coeffs.requires_grad_(True)

        optimizer = torch.optim.Adam([log_coeffs], lr=self.lr)

        prefix_len = self.prefix_len
        trigger_len = self.trigger_len
        response_offset = prefix_len + trigger_len
        output_length = prefix_len + trigger_len + self.tail_len
        theta_length = self.soft_len

        history = []
        eval_history = []
        best_loss = float("inf")
        plateau = 0
        best_out = -1
        best_ids = None
        t0 = time.time()

        def read_trigger():
            with torch.no_grad():
                return log_coeffs[:trigger_len].argmax(dim=-1).tolist()

        def trigger_to_text(ids):
            body = self.tokenizer.decode(ids, skip_special_tokens=True)
            return (self.semantic_prefix + body) if self.semantic_prefix else body

        def eval_discrete(ids):
            """True greedy output length of a discrete trigger, victim's path."""
            text = trigger_to_text(ids)
            inp = model_utils.build_chat_prompt(
                self.tokenizer, text, enable_thinking=self.enable_thinking,
                chat=self.chat)
            _, n_new = model_utils.generate(
                self.model, self.tokenizer, inp,
                max_new_tokens=self.eval_max_new_tokens, eos_ids=self.eos_ids,
                greedy=True)
            return int(n_new)

        for it in range(self.iters):
            if self.trigger_block_eos:
                with torch.no_grad():
                    log_coeffs[:trigger_len, eos_idx] = torch.finfo(dtype).min

            optimizer.zero_grad()

            coeffs = F.gumbel_softmax(log_coeffs.unsqueeze(0), tau=self.tau,
                                      hard=False)                 # (1,S,V)
            soft_embeds = (coeffs @ self.E).squeeze(0)            # (S,H)
            inputs_embeds = self._wrap(soft_embeds)               # (1,T,H)

            logits = self.model(inputs_embeds=inputs_embeds).logits[0]  # (T,V)
            target = F.softmax(log_coeffs, dim=-1)               # (S,V) mentor tgt

            # self-mentor loss (Eq 7), split around the infix (tail) tokens.
            sm1 = soft_cross_entropy(logits[prefix_len:response_offset - 1],
                                     target[1:trigger_len])
            sm2 = soft_cross_entropy(logits[output_length - 1:-1],
                                     target[trigger_len:])
            loss_sm = (sm1 + sm2) / theta_length

            # <EOS> escape loss (Eq 6) over every position from the trigger on.
            loss_eos = eos_escape_loss(logits[prefix_len:], eos_idx)

            if it < self.warmup_iters:
                loss = loss_eos            # warmup: only drive <EOS> down
            else:
                loss = loss_eos + self.lam * loss_sm

            loss.backward()
            optimizer.step()

            trigger_ids = read_trigger()
            in_main_phase = it >= self.warmup_iters

            history.append({"iter": it, "loss": float(loss.item()),
                            "self_mentor": float(loss_sm.item()),
                            "eos_prob_sum": float(loss_eos.item())})

            # Convergence is measured on the OBJECTIVE, not on the discrete argmax
            # being momentarily stable. The random-prompt init (Sec 4.1) gives
            # each argmax token a head start, so the discrete read-off is slow to
            # move even while the soft objective keeps falling. An argmax-stability
            # test therefore stops the run mid-descent (observed: it halted at
            # it 99 with the self-mentor loss still dropping 13.4 -> 12.5), so the
            # trigger never got past its initial near-random value. Instead we
            # stop only once the main-phase loss fails to improve for
            # `converge_patience` steps. Warmup drives <EOS> down on a different
            # (tiny) scale, so we start tracking at the warmup boundary.
            if in_main_phase:
                cur_loss = float(loss.item())
                if cur_loss < best_loss - self.converge_tol:
                    best_loss = cur_loss
                    plateau = 0
                else:
                    plateau += 1

            do_eval = self.select_by_generation and (
                it % self.eval_interval == 0 or it == self.iters - 1)
            if do_eval:
                out_tok = eval_discrete(trigger_ids)
                eval_history.append({"iter": it, "out_tokens": out_tok})
                if out_tok > best_out:
                    best_out = out_tok
                    best_ids = list(trigger_ids)

            if verbose and (it % self.log_interval == 0 or it == self.iters - 1):
                extra = (f"  discrete_out={eval_history[-1]['out_tokens']}"
                         if (do_eval and eval_history) else "")
                print(f"[Engorgio] it {it:4d}  loss={loss.item():.4f}  "
                      f"sm={loss_sm.item():.4f}  "
                      f"eos={loss_eos.item():.6f}{extra}")

            if in_main_phase and plateau >= self.converge_patience:
                if verbose:
                    print(f"[Engorgio] converged at it {it} "
                          f"(loss plateaued {plateau} iters, best={best_loss:.4f})")
                break

        if verbose:
            print(f"[Engorgio] done in {time.time() - t0:.1f}s")

        final_trigger = read_trigger()
        final_text = trigger_to_text(final_trigger)

        if self.select_by_generation and best_ids is not None:
            chosen_ids, chosen_out = best_ids, best_out
        else:
            chosen_ids, chosen_out = final_trigger, None
        chosen_text = trigger_to_text(chosen_ids)

        if verbose and self.select_by_generation:
            print(f"[Engorgio] best discrete trigger: {chosen_out} tokens")

        return EngorgioResult(
            trigger_ids=chosen_ids, trigger_text=chosen_text,
            history=history, best_out_tokens=chosen_out,
            eval_history=eval_history,
            final_trigger_ids=final_trigger, final_trigger_text=final_text,
            semantic_prefix=self.semantic_prefix)


def run_engorgio(model, tokenizer, **kwargs):
    """One-call convenience wrapper used by the experiments and the notebook."""
    return EngorgioAttack(model, tokenizer, **kwargs).fit()
