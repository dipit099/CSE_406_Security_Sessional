"""
Tier 2a: genetic-algorithm sponge attack (black-box).

Owner: Ahnaf.

Reimplements the evolutionary search of Shumailov et al., "Sponge Examples"
(Section 4.4.1, Algorithm 2). It is black-box: the only feedback is the
measured cost of each candidate, so no gradients or model internals are used.

Pipeline (matches Algorithm 1 in our design report):
    * start from a pool of random token sequences (the user-message content);
    * fitness = number of output tokens the candidate makes the model generate;
    * keep the top 10% as survivors;
    * breed the next pool by crossover (first half of A + second half of B,
      with a probabilistic swap of the two halves) and mutation (change a few
      tokens);
    * repeat for a number of generations, tracking the best candidate seen.

Fitness is measured honestly through the same greedy generate() path a real
request would take. There is no leakage: the search never sees the model's
weights, gradients, or the EOS logit; it only observes output length.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Callable, List, Optional

import torch

from common import model_utils, config


# ----------------------------------------------------------------------------
# Vocabulary sampling
# ----------------------------------------------------------------------------
def _safe_token_pool(tokenizer, model):
    """
    Ids we are allowed to draw random tokens from: the ordinary vocabulary
    minus the special / stop tokens. Excluding stop tokens keeps a candidate
    from trivially containing an <|im_end|> in its own text; the attack should
    win by shaping the *continuation*, not by smuggling control tokens.
    """
    vocab_size = int(getattr(model.config, "vocab_size", tokenizer.vocab_size))
    special = set(tokenizer.all_special_ids or [])
    special.update(model_utils.get_eos_ids(tokenizer, model))
    return [i for i in range(vocab_size) if i not in special]


def _decode(tokenizer, ids: List[int]) -> str:
    return tokenizer.decode(ids, skip_special_tokens=True)


# ----------------------------------------------------------------------------
# Fitness
# ----------------------------------------------------------------------------
def make_output_length_fitness(model, tokenizer, ceiling=256, eos_ids=None,
                               chat=None):
    """
    Return a fitness function candidate_ids -> output_token_count.

    `ceiling` caps each fitness generation so the search stays affordable; it
    is the black-box "how long did this run" signal. Use a moderate ceiling
    during search and re-measure the winner at the full ceiling afterwards.

    `chat` controls how a candidate is fed to the model: None auto-detects a
    chat template, True/False forces it (so a base model can be searched on raw
    text even if its tokenizer ships a template).
    """
    if eos_ids is None:
        eos_ids = model_utils.get_eos_ids(tokenizer, model)
    enable_thinking = getattr(model, "_enable_thinking", False)

    def fitness(candidate_ids: List[int]) -> int:
        text = _decode(tokenizer, candidate_ids)
        input_ids = model_utils.build_chat_prompt(
            tokenizer, text, enable_thinking=enable_thinking, chat=chat
        )
        _, n_new = model_utils.generate(
            model, tokenizer, input_ids,
            max_new_tokens=ceiling, eos_ids=eos_ids, greedy=True,
        )
        return n_new

    return fitness


# ----------------------------------------------------------------------------
# Genetic operators
# ----------------------------------------------------------------------------
def crossover(parent_a: List[int], parent_b: List[int], swap_prob=0.5):
    """
    Concatenate the left part of A with the right part of B (Sponge, NLP
    variant), then probabilistically invert the two halves.
    """
    n = min(len(parent_a), len(parent_b))
    cut = n // 2
    left, right = parent_a[:cut], parent_b[cut:]
    child = left + right
    if random.random() < swap_prob:
        child = parent_b[:cut] + parent_a[cut:]
    return child


def mutate(candidate: List[int], token_pool: List[int], rate=0.1):
    """Randomly replace a proportion `rate` of the tokens with fresh ones."""
    out = list(candidate)
    n_mut = max(1, int(round(rate * len(out))))
    for _ in range(n_mut):
        pos = random.randrange(len(out))
        out[pos] = random.choice(token_pool)
    return out


# ----------------------------------------------------------------------------
# Attack
# ----------------------------------------------------------------------------
@dataclass
class GAResult:
    best_ids: List[int]
    best_text: str
    best_fitness: int
    history: List[dict] = field(default_factory=list)  # per-generation stats


class GeneticSpongeAttack:
    """
    Black-box genetic sponge search.

    Parameters
    ----------
    seq_len       : length (in tokens) of each candidate user message.
    pool_size     : population size.
    generations   : number of evolutionary rounds.
    survivor_frac : fraction kept as parents each round (0.10 in the paper).
    mutation_rate : fraction of tokens perturbed per child.
    """

    def __init__(self, model, tokenizer, fitness_fn: Optional[Callable] = None,
                 seq_len=32, pool_size=20, generations=10,
                 survivor_frac=0.10, mutation_rate=0.1, seed=None, cap=None):
        self.model = model
        self.tokenizer = tokenizer
        self.token_pool = _safe_token_pool(tokenizer, model)
        self.fitness_fn = fitness_fn or make_output_length_fitness(model, tokenizer)
        self.seq_len = seq_len
        self.pool_size = pool_size
        self.generations = generations
        self.survivor_frac = survivor_frac
        self.mutation_rate = mutation_rate
        # The fitness ceiling, if known. When candidates routinely hit it the
        # `best` line pins to the cap and looks flat; the fraction of the pool
        # at the cap is then the meaningful signal of selection pressure.
        self.cap = cap
        if seed is not None:
            random.seed(seed)

    def _random_candidate(self):
        return [random.choice(self.token_pool) for _ in range(self.seq_len)]

    def fit(self, verbose=True) -> GAResult:
        pool = [self._random_candidate() for _ in range(self.pool_size)]
        n_survivors = max(2, int(round(self.survivor_frac * self.pool_size)))

        best_ids, best_fit = None, -1
        history = []

        for gen in range(self.generations):
            scored = [(cand, self.fitness_fn(cand)) for cand in pool]
            scored.sort(key=lambda cf: cf[1], reverse=True)

            if scored[0][1] > best_fit:
                best_fit = scored[0][1]
                best_ids = list(scored[0][0])

            survivors = [c for c, _ in scored[:n_survivors]]
            gen_best = scored[0][1]
            gen_mean = sum(f for _, f in scored) / len(scored)
            cap = self.cap
            frac_at_cap = (sum(1 for _, f in scored if f >= cap) / len(scored)
                           if cap else None)
            history.append({"generation": gen, "best": gen_best,
                            "mean": gen_mean, "overall_best": best_fit,
                            "frac_at_cap": frac_at_cap, "cap": cap})
            if verbose:
                extra = f"  frac_at_cap={frac_at_cap:.2f}" if cap else ""
                print(f"[GA] gen {gen:2d}  best={gen_best:4d}  "
                      f"mean={gen_mean:7.1f}  overall_best={best_fit:4d}{extra}")

            # Breed next pool: keep survivors (elitism) + children.
            next_pool = list(survivors)
            while len(next_pool) < self.pool_size:
                a, b = random.sample(survivors, 2) if len(survivors) >= 2 \
                    else (survivors[0], survivors[0])
                child = crossover(a, b)
                child = mutate(child, self.token_pool, self.mutation_rate)
                next_pool.append(child)
            pool = next_pool

        return GAResult(
            best_ids=best_ids,
            best_text=_decode(self.tokenizer, best_ids),
            best_fitness=best_fit,
            history=history,
        )


def run_genetic_attack(model, tokenizer, ceiling=256, chat=None, **kwargs):
    """One-call convenience wrapper used by the experiments and the notebook.

    `chat` (None auto-detects) forces how candidates are fed to the model, so a
    base model can be searched on raw text even if its tokenizer has a template.
    """
    fit_fn = make_output_length_fitness(model, tokenizer, ceiling=ceiling,
                                        chat=chat)
    attack = GeneticSpongeAttack(model, tokenizer, fitness_fn=fit_fn,
                                 cap=ceiling, **kwargs)
    return attack.fit()
