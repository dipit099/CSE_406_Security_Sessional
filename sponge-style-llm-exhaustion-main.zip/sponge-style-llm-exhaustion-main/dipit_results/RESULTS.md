# Dipit's Kaggle run — results & comparison

Source: executed Kaggle notebook **`dipit099/security-project-part-a`**,
`scriptVersionId=349784257`, run on a **T4 GPU**, pulled with
`pull_executed_kernel.py`. This folder stores the **complete** output set from
that run: **31 CSVs** (`csv/`) and **11 figures** (`figures/`).

The run executed all 16 code cells top-to-bottom (execution counts 1→16),
**zero errors**. It includes Ahnaf's cells (attacks, L2, L5, multi-model,
queue-DoS) **and** the 6 experiment cells I added.

---

## TL;DR on "what changed vs the previous results"

Honest summary after comparing every file against the repo's existing
`csv/`+`figures/`:

- **6 CSVs + 2 figures are brand new** — my experiments, which did not exist
  before. These are the real additions.
- **The shared files are NOT wrong and did not meaningfully change.** They
  *reproduce*: identical token counts, amplifications, and detector scores;
  only latency/energy wobble by a few percent, which is ordinary GPU
  run-to-run measurement noise (NVML energy especially).
- The one genuinely *broken* run was the **older glitched run** described in the
  handover (L5 cell dropped, multi-model cell duplicated). That was already
  fixed before this run; **this run re-confirms the fix** (L5 present and
  identical, multi-model run exactly once).

So there is no "previous wrong number" to correct in the committed repo — this
run adds the missing Dipit experiments and reproduces the rest.

---

## A. Newly generated (did not exist before)

| File | What it is | Headline result (T4) |
|---|---|---|
| `csv/tier1_tokenizer_abuse.csv` | Tier-1 tokenizer abuse token counts | `Athazagoraphobia` 6→**16** tokens (slash); tok/char 0.375→0.516 |
| `csv/per_request_cost.csv` | **Table 2** per-request cost | natural 8 tok / 0.25 s → crafted 512 tok / 15.23 s = **60.9× latency, 74.6× energy** |
| `csv/length_sweep.csv` + `figures/length_sweep.png` | Latency vs output length | cleanly **linear**: 16→0.48 s … 512→15.35 s (~30 ms/token) |
| `csv/defense_eval.csv` + `figures/defense_eval.png` | Layered guard eval | amplification **19.1× → 4.06×** (5/20 blocked by L2, the rest capped by L1); L5 acc 0.957 / AUC 0.998 (leakage-free CV); L2 FP 0.00; honest overhead ≈0 |
| `csv/cross_model.csv` | Cross-model check | Qwen2.5-0.5B **30.2×** latency, Qwen3-0.6B **23.3×** (thinking off) |
| `csv/server_queue_dos.csv` | Queue DoS over real HTTP | honest latency **1.76 s idle → 47.95 s** behind 3 sponges = **27.2×** |

> **Correction (defense_eval).** An earlier version of this row read
> `18.0× → 0.0× (20/20 blocked)`. That defended number came from an in-sample
> leak: L5 was scoring the very sponges it was trained on, so it "blocked"
> everything. The leak is fixed (commit `c5e1cbe`): the defended figure now uses
> the robust layers only (L2 rejects tokenizer abuse, L1 caps the rest), and L5
> is reported separately by its leakage-free cross-validation (0.957 / 0.998).
> The honest numbers above (19.1× → 4.06×, 5/20 blocked) are from Ahnaf's post-fix
> re-run and supersede any earlier figure. It does not reach 1× because a request
> that passes L2 still runs up to the L1 cap (64 tokens ≈ 8× a natural request).

---

## B. Shared files — changed vs repo, but only by run-to-run noise

These files existed in the repo (a prior clean run). My run differs only as any
re-run would. Token counts / amplifications / accuracies are unchanged; latency
and energy differ within normal variance.

| File | What differs | Magnitude | Why (not "wrong") |
|---|---|---|---|
| `l5_summary.csv` | nothing | **byte-identical** | deterministic; seeds pinned. acc 0.957, AUC 0.998, 1/6 hard-negs flagged — same |
| `l2_summary.csv` | nothing | **byte-identical** | deterministic tokenizer rule; detection 0.25, FP 0.00 — same |
| `engorgio_summary.csv` | latency, energy only | latency −0.5% (15.83→15.76 s); energy noisy (natural 17.3→11.7 J) | out_tokens identical (8/512/32); NVML energy varies run-to-run |
| `queue_dos.csv` | latency only | slowdown 12.56× → **12.44×** | same story; per-request timing jitter on the GPU |
| `multimodel.csv` | latency, energy only | ≤ ~5% per row | **every `out_tokens` and `amplification_vs_natural` identical** across all models; only wall-clock/energy jitter |
| `engorgio_loss.csv`, `engorgio_discrete*.csv`, `ga_progress*.csv` | optimisation traces | small | fresh optimisation run; same convergence behaviour |

**Conclusion:** the previous shared results were correct; this run reproduces
them. Nothing here supersedes a "wrong" value.

---

## C. Figures that reproduced exactly (not new, unchanged)

`engorgio_curve.png`, `engorgio_discrete.png`, `ga_progress.png`,
`l2_tokens_per_char.png`, `l5_pca.png`, `l5_roc.png`,
`multimodel_engorgio_discrete.png`, `multimodel_ga_progress.png` came out
**byte-identical** to the repo — deterministic plots reproduced exactly.
`queue_dos.png` differs only by the tiny latency jitter above.

---

## D. One honest caveat on Table 2 (`per_request_cost.csv`)

The **naive** "count" prompt and the **crafted** Engorgio trigger give the *same*
per-request cost here (both 512 tokens, ~60.9× latency). On this small 0.5B
instruct model the naive output-forcing prompt already saturates the 512-token
cap, so the crafted trigger cannot exceed an already-maxed ceiling on the
cost axis. Its advantage is being harder to filter, not producing more tokens.
`engorgio_summary.csv` supports this: the *selected* Engorgio trigger reaches
512, but the un-selected final-iteration read-off reaches only 32 — selection is
what makes Engorgio strong, and selection uses only the attacker's own
white-box forward pass (no leakage).

---

## E. Why "output forcing" is 256 in `cross_model.csv` but 32 in `multimodel.csv`

Same attack name, two different prompts, so the numbers differ on purpose and
both are correct:

- `cross_model.csv` uses the canonical Tier-1 prompt
  `attacks.tier1_baselines.output_forcing_prompt()` ("List every integer from 1
  to 100000 in order, one number per line. Do not skip any number, do not
  summarise, do not stop early, and do not add any commentary before or after
  the list."). On Qwen2.5-0.5B-Instruct this runs to the 256-token cap.
- `multimodel.csv` uses a shorter in-file variant ("List every integer from 1
  to 100000, one number per line, with no summary and no early stop."). The
  aligned instruct model wraps this one up at 32 tokens.

Verified locally on CPU: the first prompt gives 256 tokens, the second gives 32,
on the same model, so the gap is entirely prompt wording, not a measurement bug
(and both reproduce the Kaggle numbers exactly). The takeaway is useful rather
than awkward: even among naive prompts the exact phrasing changes how hard the
model is to stop, which is precisely what motivates the optimised Tier-2 attacks
(GA and Engorgio) that do not depend on hand-tuned wording.

---

## Cross-check against the report / paper (all consistent)

| Claim | Reference | This run |
|---|---|---|
| Per-request ≈ 63× latency / 73× energy | report Table 2 | **60.9× / 74.6×** |
| Engorgio ≈ 64× output, 61× latency | handover | **512/8 = 64×, 60.9×** |
| L5 ≈ 0.957 acc, 0.998 AUC, 1/6 hard-neg flagged | handover | **exact match** |
| Rate limiting alone doesn't stop a sponge | report §8 / paper §7.1 | L4 plain-count lets one expensive request through (unit-tested) |
| Amplification drops with defenses on | report §8 | **19.1× → 4.06×** (L2 blocks + L1 caps, leakage-free) |
