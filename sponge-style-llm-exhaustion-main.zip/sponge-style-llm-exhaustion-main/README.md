# Sponge-Style LLM Resource-Exhaustion DoS

CSE 406 (Cyber Security Sessional) course project — **Project 37: LLM Resource-Exhaustion (Sponge-Style) Denial of Service**.

A sponge attack is an availability attack against an LLM inference service that does not rely on
request volume. Instead, a small number of individually crafted requests are sent that force the
model into its worst-case compute, mainly by suppressing the end-of-sequence token so decoding never
stops early and runs all the way to the `max_tokens` ceiling. We implement several such attacks
against both a small model and an aligned 8B model, and a layered defense that detects and bounds
them.

## Reports

- **[Design report](report/design_report.pdf)** — the attack mechanism, network topology, packet
  structure, and defense design.
- **[Final report](report/final_report/final_report.pdf)** — the measured results for every attack
  and defense: expected outcome, actual outcome, why they differ, whether the defense worked, and the
  assumptions behind each run.

## What we implemented, and the papers behind it

We reproduced and measured five attack techniques from the sponge/energy-latency literature, plus a
layered defense loosely following the OWASP GenAI guidance on unbounded resource consumption. Each
attack is grounded in a specific paper:

| Paper | Used for |
|---|---|
| [Sponge Examples: Energy-Latency Attacks on Neural Networks](https://arxiv.org/abs/2006.03463) (Shumailov et al., 2021) | Tokenizer abuse, output forcing, repeat-loop, the genetic black-box search |
| [LLMEffiChecker: Understanding and Testing Efficiency Degradation of Large Language Models](https://arxiv.org/abs/2210.03696) (Feng et al., 2024) | Tokenizer-level cost inflation; the latent-space idea behind our L5 defense |
| [An Engorgio Prompt Makes Large Language Model Babble On](https://arxiv.org/abs/2412.19394) (Dong et al., ICLR 2025) | The white-box EOS-suppression attack (Engorgio) |
| [LoopLLM: Transferable Energy-Latency Attacks in LLMs via Repetitive Generation](https://arxiv.org/abs/2511.07876) (Li et al., AAAI 2026) | The white-box repetition-loop attack against the aligned 8B model |
| [Crabs: Consuming Resources via Auto-generation for LLM-DoS Attack under Black-box Settings](https://arxiv.org/abs/2412.13879) (Zhang et al., 2025) | The black-box Auto-DoS attack (DoS Attack Tree + Length Trojan) against the aligned 8B model |
| [OWASP Top 10 for LLM Applications — LLM10: Unbounded Consumption](https://genai.owasp.org/llmrisk/llm10-unbounded-consumption/) | Overall defense framing |

**Attacks implemented:**

- Tokenizer abuse (Tier 1a, black-box)
- Output forcing (Tier 1b, black-box)
- Repeat-loop (black-box)
- Glitch / control-token probe (black-box)
- Genetic search (Tier 2a, black-box)
- Engorgio — no-prefix and with-prefix variants (Tier 2b, white-box)
- **LoopLLM** — single-token (`-t`) and phrase (`-p`) variants (white-box)
- **Auto-DoS** — DoS Attack Tree + Length Trojan (black-box)

**Defenses implemented:**

- **L1** — output / compute cap (`max_new_tokens` + a per-request time budget)
- **L2** — input validation (token-to-character ratio and length fingerprinting)
- **L3** — output repeat monitor (single-token and n-gram variants)
- **L4** — rate limiting and quotas
- **L5** — latent anomaly detector (a classifier on the model's hidden state)
- **L6** — configuration hygiene (hides `logprobs`/`logit_bias`, filters reserved/glitch tokens)

## Repository layout

```
report/
  design_report.pdf              Design report
  final_report/final_report.pdf  Final report (results, observations, contribution)

code/
  attacks/                       Attack implementations (tier1_baselines, tier2a_genetic,
                                  tier2b_engorgio, loopllm/, autodos/)
  defenses/                      Defense implementations (l1..l6, guard.py)
  common/                        Shared model/config utilities
  experiments/                   Experiment drivers used to produce the results below
  live_demo/                     Harness behind the Kaggle live demo (demo_harness.py)
  kaggle_download_assets.ipynb   Stages model weights as Kaggle datasets (offline use)

notebooks/
  live-demo.ipynb                Live attack/defense demo notebook for Kaggle (see below)
  security-project-part-a.ipynb  Classic Tier-1/Tier-2 attacks + full defense suite (Qwen2.5-0.5B)
  security-finale-loopllm*.ipynb LoopLLM experiment notebooks (Llama-3.1-8B-Instruct)
  security-finale-auto-dos*.ipynb Auto-DoS experiment notebooks (Llama-3.1-8B-Instruct)

results/, csv/, figures/,
attack_outputs_*/                Full experiment outputs: crafted inputs, real model outputs,
                                  measured stats, and figures for every attack and run

exploration/                     Assignment spec and reading notes (source papers are not
                                  redistributed here; see the links above)
```

## Live demo (Kaggle)

`notebooks/live-demo.ipynb` is a self-contained notebook for demonstrating any single attack, with any subset
of the six defenses toggled, against a real model running on a Kaggle GPU. It streams the live model
output and reports every relevant statistic (tokens, latency, energy, amplification, perplexity,
loop type, etc.) plus a plain ATTACK/DEFENSE verdict.

To run it yourself:

1. Attach the `code/` folder as a Kaggle dataset.
2. Stage the model(s) you want to test as Kaggle datasets. `code/kaggle_download_assets.ipynb`
   downloads the public models directly; Llama-3.1-8B-Instruct and Gemma-2-2B-it are gated on
   Hugging Face and need a token plus accepting the model license.
3. Import `notebooks/live-demo.ipynb` as a Kaggle notebook, attach the datasets, and run the Setup cell, then
   edit the control-panel cell (attack, model, defenses) and run.

**Models you can test on:**

| Model | Size | Access | Notes |
|---|---|---|---|
| `meta-llama/Llama-3.1-8B-Instruct` | 8B | gated | Home of LoopLLM and Auto-DoS |
| `Qwen/Qwen2.5-0.5B-Instruct` | 0.5B | public | Home of the classic Tier-1/2 attacks |
| `Qwen/Qwen2.5-0.5B` (base) | 0.5B | public | Raw twin — shows the classic attacks succeeding pre-alignment |
| `mistralai/Mistral-7B-Instruct-v0.3` | 7B | public | Extra target for the black-box Auto-DoS attack |
| `google/gemma-2-2b-it` | 2B | gated | Extra target for the black-box Auto-DoS attack |

LoopLLM and Engorgio are white-box, gradient-crafted attacks and only reproduce on the model they
were crafted for; the notebook can also craft them live on any other model. Auto-DoS and the other
classic attacks are black-box and run against any of the models above out of the box.

## Authors

Ahnaf Tahmid (2105041) and Dipit Saha (2105050). The contribution split is in the
[final report](report/final_report/final_report.pdf).
