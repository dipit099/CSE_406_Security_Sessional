# Project 37: LLM Resource-Exhaustion (Sponge-Style) DoS

### A complete plan for what to do and how to do it

This document is your full study and planning guide. It does not contain code. Its job is to make you understand the attack completely, so that when you sit down to build it you already know exactly what you are doing and why. Read it once end to end, then use it as a reference while you write the two lab reports and build the demo.

I have written it based only on the two sources your course gave you (the OWASP page and the Shumailov 2021 sponge paper) plus a small set of recent, top-venue papers that I read and verified. Wherever I give a number, it comes from one of those papers, and I say which one.

---

## Scope note (read this first)

Your project title is **"LLM Resource-Exhaustion (sponge-style) DoS."** The words "sponge-style" narrow the scope, so this guide stays inside it on purpose. A **sponge attack** is not any DoS on a model. It has a specific meaning from the Shumailov 2021 paper: it is a **single crafted input that individually soaks up as much compute (time and energy) as possible**, by forcing the model into its worst-case behavior. The attack unit is one deliberately expensive request, and the input is shaped or optimized to maximize the cost of that one query.

That rules a few things out. Sending a *flood* of many requests, overflowing the context window with sheer volume, abusing rate limits, or poisoning the training data are all resource-exhaustion attacks too, but they are **not sponge-style**, so this guide does not treat them as build targets. It mentions them only briefly, and clearly labels them as out of scope, so your project does not sprawl. Everything you are asked to *implement* here is a crafted-input, per-query worst-case attack, which is exactly what "sponge-style" means.

---

## 0. The one-paragraph summary

Your job is to show that a language model can be attacked not by stealing data or fooling it, but by making it *waste resources*. You send the model specially made inputs that force it to do far more work than a normal request would, so the server slows down, burns extra energy or GPU time, and starts serving everyone else badly. This is a Denial of Service (DoS) attack aimed at the *availability* of the model. You then build a defense that caps this wasted work and show it stops the attack. The core idea from the original paper is that two inputs of the same visible size can cost wildly different amounts of compute, and an attacker deliberately picks the expensive ones. For modern text models, the single most important lever is **output length**: if you can trick the model into generating a very long output, you win, because generation cost grows with the number of tokens produced.

---

## 1. Background you actually need

### 1.1 What a DoS attack is (quick recap from your course)

In your networking labs, DoS attacks (SYN flood, ping flood, Smurf) work by *volume*: you send so many packets or half-open connections that the victim runs out of some resource (connection table, bandwidth, CPU) and cannot serve real users. The victim is not tricked into computing something wrong, it is just overwhelmed.

The sponge attack is a DoS attack too, but it is smarter. Instead of sending a huge *number* of requests, you send a *small number of very expensive requests*. Each request is legitimate and well formed, but each one costs the server a lot. This is called an **application-layer** or **algorithmic-complexity** DoS, because you are abusing how the application computes, not flooding the network. The sponge paper makes this comparison directly: it says sponge examples strongly resemble classic DoS, except that instead of overwhelming the victim's bandwidth, they target the most expensive part of the application to get a huge amplification factor.

Keep this contrast in your report. It shows you understand where this attack sits relative to the classic ones you already studied.

### 1.2 How an LLM actually handles a request (this is the crux, learn it well)

You cannot explain this attack without understanding LLM inference. Here is the whole thing in plain terms.

**Tokens.** A model does not read characters or words. Text is first split into **tokens** (chunks of characters) by a **tokenizer**. Common words often become one token. Rare or misspelled words get chopped into many small tokens. This matters a lot, as you will see.

**Two phases of inference.** When you send a prompt, the server does two things:

1. **Prefill.** It reads all your input tokens at once and builds up its internal state. Cost here grows with the number of *input* tokens. If your input is longer, prefill costs more.
2. **Decode (generation).** The model then produces the answer **one token at a time**. To make token number *n*, it uses the prompt plus every token it has generated so far. This is called being **autoregressive**. After each token it asks itself: should I stop now? It stops when it produces a special **end-of-sequence token** (written **EOS** or `<EOS>`), or when it hits a preset ceiling called **max tokens** (also called the max-length threshold or `max_new_tokens`).

So the total cost of a request is roughly: prefill cost (depends on input length) plus decode cost (depends on how many output tokens get generated). For most modern chat models the decode phase dominates, because generating each new token means running the whole network again.

**The KV cache.** During decode the model stores the intermediate results for every token so far in GPU memory (the "key-value cache"). The longer the output, the more of this memory is used. This is why long generations also eat GPU memory, not just time.

**Put simply:** a normal request generates maybe 20 to 200 tokens and finishes fast because the model naturally produces an EOS. If you can stop the model from producing EOS, it keeps going until it slams into the max-token ceiling, which is often set very high. That single fact is the heart of every modern LLM sponge attack.

### 1.3 Why LLMs are vulnerable: the "energy-latency gap"

The sponge paper's central observation is that **different inputs of the same size can make a neural network use very different amounts of time and energy.** They call the difference between the cheap (average) case and the expensive (worst) case the **energy gap**, and the whole attack is about deliberately steering the model into that worst case. The paper gives two reasons this gap exists.

**Hypothesis 1: computation dimensions (mostly about tokenization and output length).** The model's internal amount of work depends on how many tokens it has to process and produce, not just on how many characters you typed. The paper's own example is beautiful and you should reuse it:

- The word `Athazagoraphobia` (16 characters) normally becomes **4 tokens**.
- Mistype it as `Athazagoraphpbia` (still 16 characters) and it becomes **7 tokens**.
- Write it as `A/h/z/g/r/p/p/i/` (still 16 characters) and it becomes **16 tokens**.

So with the *same character count*, an attacker can multiply the token count, and token count is what the model actually pays for. On the output side, if the model can be nudged into producing a longer answer, the cost goes up further, and because output tokens depend on all previous tokens, the cost grows in a way that is worse than linear (the paper describes it as quadratic in the relevant regime).

**Hypothesis 2: data sparsity (mostly relevant to specialized hardware).** Many activations inside a network are zero (because of the ReLU function, which turns negatives into zeros). Some hardware skips those zeros to save energy. An attacker can craft inputs that produce *fewer* zeros, so the hardware cannot skip work, and energy goes up. In the paper this effect is real but small (a 1 to 3 percent energy increase on vision models, and it only shows up on hardware that exploits sparsity). For your project this is the less important of the two, and it mainly matters if you talk about ASIC or specialized accelerators. Focus your energy on Hypothesis 1.

### 1.4 What the Shumailov 2021 paper actually did (your primary reference)

This is the paper your course attached, so your reports should show you read it carefully. Here is what to take from it.

**Two ways to generate sponge examples:**

- A **genetic algorithm (GA).** Start with a pool of random inputs. Measure each one's "fitness" (how much energy or time it causes). Keep the worst offenders, mix and mutate them, repeat. This needs no access to the model's internals if you can just measure time or energy, so it works in a **black-box** setting. This is the method I most recommend you reimplement, because it is conceptually simple and matches the spirit of "craft your own attack."
- **L-BFGS gradient optimization.** If you have full access to the model (white-box), you can directly optimize the input to maximize the sum of activation values across all layers. They only used this for vision models.

**Three threat models** (you must state which one you are using):

1. **White-box:** attacker knows the model architecture and weights.
2. **Interactive black-box:** attacker cannot see internals but can query the model as often as they like and measure latency or energy.
3. **Blind black-box:** attacker cannot even measure, and just reuses sponge examples found elsewhere, relying on the fact that they **transfer** to new models and hardware.

**Headline results you can quote:**

- Language models are far more vulnerable than vision models. Sponge examples increased latency and energy on language models by up to about **30 times**.
- On the WSC language task (white-box), energy on the GPU went up to **26.6 times** and time up to **20.6 times** for a 50-token input.
- Vision models barely moved: only about a **1 to 3 percent** energy increase, and only on sparsity-exploiting hardware.
- The most dramatic result: against the real, deployed **Microsoft Azure Translator**, a 50-character input increased response time **from 1 millisecond to 6 seconds, a 6000 times slowdown**, purely by sending well-formed API calls in a black-box way.
- Even **random noise** inputs were more expensive than natural inputs, which they call "barrage jamming." This is worth noting: a lazy attacker who just sends garbage already causes some damage.

**Their defense (very important for your bonus).** Before deploying, profile normal inputs to learn the typical energy or time cost per request. Then set a **cut-off threshold**. Any request that tries to exceed that budget is stopped and returns an error. This bounds the worst-case cost so a sponge cannot run wild. They also note that plain API rate limiting is *not enough*, because the attacker raises the cost *per request* without raising the *number* of requests. Remember that point, it is a strong thing to say in your report.

### 1.5 Where this sits in OWASP

The OWASP page your course linked is the 2023/2024 entry **LLM04: Model Denial of Service**. Read it as the "industry checklist" version of the same idea. Its listed vulnerability patterns map neatly onto what you will build:

- queries that cause unusually high resource use (unusual orthography or sequences), which is exactly the tokenizer-abuse and sponge idea,
- continuous input overflow and repetitive long inputs that exceed the context window,
- recursive context expansion,
- variable-length input floods crafted to sit right at the context-window limit.

Its prevention list is basically your defense menu: input validation and sanitization, cap resource use per request, API rate limits, limit queued actions, monitor resource utilization, and set strict input limits based on the context window.

One thing to know so you sound current: in the **2025** OWASP list, this category was renamed and broadened to **LLM10: Unbounded Consumption**. The scope now also covers runaway API cost and model theft, not just downtime, and the prevention advice adds user quotas and hiding fields like `logprobs` and `logit_bias` that help attackers optimize. Mention this rename in a sentence so the graders see you checked the latest version, but your actual project lives squarely in the DoS part of it.

---

## 2. The modern picture: recent papers you should cite

The sponge paper is from 2021 and predates the ChatGPT era. Text generation models have changed a lot since then, so you should ground your project in a couple of newer, top-venue papers. The two that matter most for you are the direct modern descendants of the sponge idea, where a single crafted input maximizes its own generation cost. Understand each one's core trick, because your design borrows from them. After those two, there is a short list of related attacks that are cited for context but are deliberately outside your sponge-style scope.

### Paper A. LLMEffiChecker (ACM TOSEM 2024)

*Simin Chen et al., "LLMEffiChecker: Understanding and Testing Efficiency Degradation of Large Language Models."*

This is the paper that states the key modern insight most clearly: **the output length, not the input, determines an LLM's compute cost, and output length is decided by whether the model produces EOS before hitting its max-token ceiling.** They show that by making a tiny, almost invisible change to the input (as little as one character or one token), you can delay the EOS token and force the model to keep generating until it hits that high ceiling. Their reported effect is large: on average they increased latency by **325 to 3244 percent** and energy by **344 to 3616 percent** by perturbing a single character or token. They give three levels of perturbation (character-level like typos, token-level like swapping a word, and structure-level) and they work in both white-box (gradient-guided) and black-box (causal-inference) settings. **Why it matters for you:** this is the simplest attack to reimplement and demo, and it directly connects the old sponge idea to modern text generation. It also proves your defense must watch output length, not just input length.

### Paper B. Engorgio (ICLR 2025)

*Jianshuo Dong et al., "An Engorgio Prompt Makes Large Language Model Babble on."* (Named after the Harry Potter enlarging spell.)

This is the direct modern successor to the sponge paper for chat-style LLMs, and it is the "gold standard" method to implement if you want a strong project. Instead of perturbing an existing sentence, they *optimize a whole prompt from scratch* whose only purpose is to make the model generate as long an output as possible. Their two tricks: (1) they track the model's prediction trajectory with a parameterized distribution, and (2) they design **loss functions that specifically suppress the EOS token** so it almost never appears during generation. Tested on 13 open-source models from 125M to 30B parameters, their prompts made outputs **2 to 13 times longer, reaching over 90 percent of the model's maximum output length**, in the white-box setting, and the prompts also transferred to models they did not optimize against. **Why it matters for you:** this is the "craft your own optimized attack" version. If your group is comfortable with PyTorch and gradients, implementing a simplified Engorgio-style EOS-suppression loss is the most impressive thing you can demo, and it is clearly your own code.

### Related attacks, cited for context only (out of your scope)

These are real and recent, and naming them in your related-work section shows you know the current landscape. But none of them is a "craft one input to maximize its own compute" sponge, so you should **cite them, not build them**. Keep this to a paragraph in your report.

- **Crabs / AutoDoS** (Zhang et al., ACL 2025 Findings): a black-box attack that uses prompt engineering to build a deeply nested "DoS Attack Tree" prompt, amplifying latency by over 250 times. It is closer to clever prompt design than to worst-case input optimization, so it sits just outside sponge-style.
- **OverThink** (Kumar et al., 2025): forces reasoning models (o1, DeepSeek-R1) to burn reasoning tokens by injecting decoy puzzles into content they read, up to a 46 times slowdown. This is really an indirect prompt-injection twist and needs reasoning models, so it is out of scope, but it makes a good "where this is heading" sentence.
- **P-DoS** (Gao et al., 2024): a *training-time poisoning* attack that makes a model ignore its stop conditions later. Different attack surface entirely (data poisoning, not crafted inputs), so cite it only to note the threat can also live at training time.

**How the two in-scope papers connect to your project:** the 2021 sponge paper gives you the concept and the genetic-algorithm method. LLMEffiChecker and Engorgio tell you the modern sponge lever is EOS suppression, that is, making one crafted input push output length toward the max ceiling. Those two, plus the original, are the papers you actually build from.

---

## 3. What you are going to build (scope and choices)

### 3.1 The setup ("topology")

You will run a small experiment that mimics a real deployed LLM service, on three roles (which can be three machines, or three terminals on one machine, but three machines looks best in a demo and satisfies the "attacker PC, victim PC, other PC" requirement):

- **Victim server:** a machine running a small open LLM behind a simple HTTP API (you write a tiny server with FastAPI or Flask, or use Ollama's built-in server). This is the thing you are attacking.
- **Attacker PC:** a machine running your attack scripts that send the crafted prompts.
- **Legitimate client PC:** a machine that sends normal, honest requests. Its whole purpose is to *prove the DoS effect*: you measure how much slower the honest user gets while the attack is running. This is the single most convincing thing in your demo.

### 3.2 Which model to use

Pick a **small open model** so you can run it locally, have white-box access, and make everything reproducible with no API bills. Good options, smallest first: **Qwen2.5-0.5B**, **Llama-3.2-1B**, **TinyLlama-1.1B**, **Pythia-410M or 1.4B**, or classic **GPT-2**. For a translation-style demo closer to the original paper you can use a small **MarianMT** or **T5** model. Run it with Hugging Face `transformers` and PyTorch. If you have any GPU (even a laptop or Colab), use it, because GPU time and memory make the strongest measurements. If you only have CPU, you can still measure latency and token counts, which is enough to prove the point.

**Reproducibility (the project explicitly requires this).** Pin everything: the exact model name and revision hash, the dataset you draw seed prompts from, and all random seeds (Python `random`, NumPy, and PyTorch, including CUDA). Fix the decoding settings (use greedy decoding, or temperature 0, so results do not wander). Record your library versions. Write these into your report so a grader could rerun and get the same numbers.

### 3.3 The attack menu (build in tiers, from easy to impressive)

Every attack below is a true sponge: a single crafted input designed to maximize the cost of its own query. Build Tier 1 as your warm-up, then Tier 2 as your main graded attack. The project says you must implement the *core attack* yourself and must not use a ready-made attack library (no foolbox, ART, or TextAttack), but you may use PyTorch, Hugging Face, and Ollama as the environment. Everything below is your own code.

**Tier 1: naive baseline sponges (simple, prove the mechanism, motivate the optimized versions).**

- *Input-side tokenizer abuse (sponge Hypothesis 1).* Take a normal sentence and rewrite it to explode the token count (insert slashes or odd unicode between letters, strip spaces, use rare characters), exactly like the `A/h/z/g/r/p/p/i/` example. Show that a same-length input can produce many more tokens, raising prefill cost. This is a direct, honest reimplementation of the paper's own tokenization idea, and it is unmistakably a crafted worst-case input.
- *Naive output-forcing prompt.* A plain instruction that makes the model generate a very long output ("count from 1 to 100000 with each number on its own line," "repeat the following word 5000 times"). This is the crude, hand-written version of an output-length sponge, with zero optimization. Use it only as a baseline that your Tier 2 attack then beats. Keep it labeled as naive so it is clear the real work is the optimized attack.

**Tier 2: your real graded sponge attack (pick ONE of these two, or do both).**

- *Option 2a, genetic-algorithm sponge (recommended, matches the 2021 paper, no gradients needed).* Reimplement Algorithm 2 from the paper yourself. Keep a pool of candidate inputs. Fitness of an input = number of output tokens it causes (or its latency or energy). Each round: measure fitness, keep the top performers, create children by crossover (splice the front of one input with the back of another) and mutation (randomly change some tokens or characters), repeat for some generations. Over time the pool evolves toward inputs that force long outputs. This is the genuine sponge method from the paper, it works even in a black-box setting where you only measure cost, and it is unmistakably your own implementation.
- *Option 2b, Engorgio-style EOS-suppression sponge (more advanced, white-box, most impressive).* Optimize the input tokens directly with gradients so the model's probability of emitting EOS stays low across the generated sequence. In plain terms, your loss function *rewards* the model for not stopping. You run a loop: forward pass, compute a loss that goes down when EOS probability goes down, backpropagate to the input embeddings, nudge the input, repeat. Because input tokens are discrete, you optimize over a soft distribution or use a search over token swaps (this is the tricky part, and it is where you show real skill). The result is a single crafted input that makes the model babble to near its max length. This is the modern sponge, straight from the Engorgio and LLMEffiChecker line of work.

Notice that both Tier 2 options are still "one crafted input, maximum self-cost." That is the boundary of your scope. You are not adding a black-box prompt-engineering tier or a flooding tier, because those drift away from sponge-style.

### 3.4 What to measure (so you can answer "was it successful?")

For every request, log:

- **Output token count** (the primary driver, and the cleanest metric).
- **Wall-clock latency** (seconds from request sent to response complete).
- **Throughput** (tokens per second), to show the server is not just doing more, it is doing it slower per token when memory is stressed.
- **GPU memory used** (via `torch.cuda.max_memory_allocated`) and **GPU utilization / power draw** (via `nvidia-smi` or the `pynvml` library, which is the NVML the paper used). Power draw over time, integrated, gives you **energy**, matching the paper's energy story.
- **On CPU-only setups**, you can read energy from Intel **RAPL** on Linux (`/sys/class/powercap/intel-rapl/...`), which is exactly the mechanism the paper used for CPU energy. If that is unavailable, latency plus token count is a perfectly acceptable proxy for an undergraduate project.
- **The victim-experience metric (do not skip this):** while your attack requests are being processed, have the legitimate client send a normal request and record how much its latency grows compared to when the server is idle. This number *is* the denial of service, expressed from the real user's point of view.

Report each metric as an **amplification factor**: attack value divided by natural-input value (for example "3.2x latency, 8x output tokens, 2.5x GPU memory"). The paper reports everything this way, and it makes your results instantly comparable to theirs.

---

## 4. How to build it, step by step

This section is the recipe. It is written so you can hand each part to a teammate.

### Step 1: Stand up the victim server

Load your chosen small model with Hugging Face. Wrap it in a minimal HTTP endpoint that accepts a JSON body with a `prompt` and a `max_tokens` field, runs generation, and returns the text plus timing and token-count metadata. Set a deliberately high `max_tokens` ceiling (say 2048 or 4096) so there is room for a sponge to run long, and log every request's metrics. Keep decoding greedy for reproducibility.

### Step 2: Build the measurement harness

Write one function that sends a prompt to the server and records latency, output token count, GPU memory, and (if available) energy. Every experiment reuses this. Nail this early, because clean measurement is what separates a convincing demo from a hand-wavy one. Warm up the model with a few throwaway requests before timing, because the first call is always slow. Repeat each measurement several times and report the average and spread, because GPU timing is noisy (the paper itself warns that the same input can vary by up to a factor of 10 across runs due to hardware state and even ambient temperature).

### Step 3: Establish the baseline

Draw a set of natural prompts from a real dataset (for example a slice of ShareGPT-style prompts, or simple questions). Measure their average cost. This is your "1.00x" reference. Everything else is compared to this.

### Step 4: Tier 1 attacks

Implement the tokenizer-abuse rewriter and the output-forcing prompts. Measure. You should already see clear amplification, especially from the output-forcing prompts. This gives you an early win and confirms the harness works.

### Step 5: Your Tier 2 core attack

If GA: implement the pool, fitness = output tokens, crossover, mutation, and the generation loop. Watch the average fitness of the pool climb over generations and plot it (this plot is almost identical in spirit to the paper's Figure 2 and Figure 6, and it looks great in a report). If Engorgio-style: implement the EOS-suppression loss and the optimization loop, then show the resulting prompt drives output length toward the max ceiling. Save the best prompts you find (the project wants reproducibility, so store them).

### Step 6: The concurrency / victim-impact test

Run your best sponge prompts against the server in a loop from the attacker PC. At the same time, from the legitimate client PC, fire normal requests and record their latency. Compare to the idle baseline. Show, with numbers, that the honest user's requests slow down or time out while the attack runs. This is your money shot for the demo.

### Step 7: The defense (Section 5 below)

Implement it, then rerun Steps 4 to 6 with the defense on, and show the amplification collapses back toward 1x.

---

## 5. The defense (this is your 10 percent bonus, take it)

The project gives a 10 percent bonus for designing and implementing a defense. The sponge paper hands you the main idea, and OWASP gives you the rest. Build a layered defense and, crucially, **measure it**: run the same attacks with the defense on and show the numbers drop.

**Layer 1: output-length cap (the single most effective defense, straight from the paper).**
The paper's core defense is to profile normal requests, learn a reasonable cost, and set a hard cut-off. In LLM terms this is a strict, sensible `max_new_tokens` limit plus a per-request wall-clock or compute budget. If a request tries to exceed it, cut generation and return a short error or a truncated answer. Because output length is the cost driver, capping it directly bounds the worst case. Show that with the cap on, even your best EOS-suppression prompt cannot exceed the budget.

**Layer 2: input validation and sanitization (OWASP, and it kills the tokenizer-abuse attack).**
Reject or normalize inputs whose token count is wildly out of line with their character count (that is the fingerprint of the `A/h/z/g/r/p/p/i/` trick). Enforce a strict maximum input length tied to the context window. Optionally, run a cheap **perplexity or repetition check**: sponge and optimized-garbage prompts often look statistically weird (high perplexity) or highly repetitive, so you can flag them. Perplexity filtering is a known, published defense idea against optimized adversarial prompts, so you can cite it as principled, not ad hoc.

**Layer 3: output monitoring with early termination.**
Watch the generation as it happens. If the model starts producing degenerate repetition (the same token or phrase over and over) or blows past a length threshold without any sign of stopping, kill that generation. This catches the "babble" behavior that Engorgio-style attacks rely on.

**Layer 4: rate limiting and per-user quotas (OWASP), with the honest caveat.**
Add per-IP or per-user request-rate limits and a token budget per user per time window. Then say the important thing the paper says: rate limiting alone is **not sufficient**, because the sponge raises cost *per request* without raising the request *count*. This is exactly why Layer 1 is the real fix and rate limiting is only a supporting layer. Making this point shows real understanding.

**How to present the defense in the report.** For each layer, give a before/after table: attack amplification with defense off vs on. The strongest single result you can show is "our EOS-suppression prompt caused an 8x latency increase; with the output cap enabled it was limited to 1.1x, and the honest user's latency returned to baseline." That table is worth the whole bonus.

---

## 6. Mapping everything to the two required reports

Your course asks for a Design Report (week 11) and a Final Report plus demo (weeks 13 to 14) with very specific sections. Here is exactly how to fill each one, including the diagrams. One honesty note first: this is an **application-layer** attack, so the "packet/frame crafting" language from the networking attacks does not translate literally. You are not building custom Ethernet frames. Say this plainly in your report and then map the requirement to the API request, which is the real "packet" here. Graders respect that you understood the difference rather than faking a frame diagram.

### 6.1 Design Report

**(a) Definition of the attack with topology diagram.**
Define it as: an availability attack that sends well-formed but deliberately expensive requests to an LLM inference service, forcing worst-case compute (mainly by inflating output length via EOS suppression), degrading service for all users. Then include a topology like this (this is Mermaid, which renders in most Markdown viewers, GitHub, and VS Code):

```mermaid
graph LR
    A[Attacker PC<br/>sends crafted<br/>sponge prompts] -->|HTTP POST<br/>expensive requests| R((Network / Router))
    L[Legitimate Client PC<br/>sends normal prompts] -->|HTTP POST<br/>honest requests| R
    R --> S[Victim Inference Server<br/>FastAPI + small LLM<br/>GPU with KV cache]
    S -->|slow / delayed<br/>responses| R
    R --> A
    R --> L
    S -.->|GPU busy, memory full,<br/>queue backed up| S
```

Explain in words: the attacker's few expensive requests keep the server's GPU busy and its memory full, so the legitimate client's requests wait in the queue and come back late or time out.

**(b) Timing diagram of the original protocol and your attack.**
Show the normal request lifecycle first, then the attack version. Two sequence diagrams:

Normal request (short output, EOS arrives early):

```mermaid
sequenceDiagram
    participant C as Client
    participant S as LLM Server
    C->>S: prompt (short)
    Note over S: Prefill (read input tokens)
    loop Decode: a few tokens
        Note over S: generate 1 token
    end
    Note over S: model emits EOS, stops early
    S-->>C: short answer (fast, e.g. 40 tokens)
```

Attack request (EOS suppressed, runs to the max-token ceiling):

```mermaid
sequenceDiagram
    participant A as Attacker
    participant S as LLM Server
    A->>S: crafted sponge prompt
    Note over S: Prefill (maybe inflated by tokenizer abuse)
    loop Decode: runs and runs (EOS never appears)
        Note over S: generate 1 token
        Note over S: KV cache keeps growing
    end
    Note over S: only stops at max_tokens ceiling (e.g. 2048)
    S-->>A: huge output (slow, GPU saturated)
```

In the text under these, spell out the "attack strategy": suppress EOS so the decode loop never exits early, optionally inflate prefill with tokenizer abuse, and repeat concurrently so the server queue backs up for everyone.

**(c) Packet / frame details and header modifications.**
State clearly that the transport is HTTP, and the "packet" whose contents you control is the JSON request body. Show a concrete example of a normal vs attack request, and point out which fields are the weapon:

Normal request:

```
POST /generate HTTP/1.1
Host: victim-server:8000
Content-Type: application/json

{ "prompt": "Translate 'good morning' to French.", "max_tokens": 2048 }
```

Attack request (the fields in the body are your "modified header/payload"):

```
POST /generate HTTP/1.1
Host: victim-server:8000
Content-Type: application/json

{ "prompt": "<optimized EOS-suppressing sponge prompt here>", "max_tokens": 2048 }
```

The "modification" you are making is entirely in the prompt content (crafted to suppress EOS or to explode token count) and in requesting a high `max_tokens`. If you want to tie it to lower layers for your networking course, you can add one line noting that these requests ride over normal TCP, and that unlike a SYN flood you are not manipulating TCP headers at all, the maliciousness is 100 percent in the application payload. That contrast is a good thing to state.

**(d) Justification: why your design should work.**
Argue from the mechanics: LLM cost is dominated by the number of output tokens; output stops only at EOS or the max ceiling; therefore any input that reliably delays EOS forces the model to the expensive ceiling. Back this with the evidence you have read: LLMEffiChecker showed a single perturbed token can raise latency by hundreds to thousands of percent; Engorgio showed optimized prompts reach 90 percent-plus of the max length and 2 to 13 times normal; the original sponge paper showed up to 30 times on language models and 6000 times on a real translator. Conclude that your smaller-scale version on a small model should reproduce the same *direction* of effect, even if the exact factor is smaller.

### 6.2 Final Report and demo

**(a) Steps of the attack, snapshots, victim screen.**
Walk through Steps 1 to 6 from Section 4 with screenshots: the server logs, the attacker script running, and especially the **victim/legitimate client screen** showing its request hanging or timing out while the attack runs. Include your GA fitness-over-generations plot or your Engorgio length-over-iterations plot.

**(b) Is the attack successful, and why or why not.**
Answer with your amplification table. Explain success in terms of the mechanism (you delayed EOS, output length grew, latency and GPU memory grew, honest users were delayed). Be honest about limits: on a tiny model the absolute slowdown may be modest, GPU timing is noisy, and a well-set max-token cap defeats you (which is exactly the point that motivates your defense). Explaining *why* it partly fails is worth as much as showing it succeeds.

**(c) Observed output on attacker, victim, and other PCs.**
Give the three-way view: on the attacker PC, the crafted prompts and the long responses coming back slowly; on the victim server, high GPU utilization, growing memory, and a backed-up queue; on the legitimate client PC, the concrete increase in its own response time. This directly satisfies the "attacker PC, victim PC, and other related PC" requirement.

**(d) Countermeasure.**
Present the layered defense from Section 5 with the before/after numbers, and end on the paper's insight that capping worst-case cost (not just rate limiting) is the real fix.

---

## 7. Suggested division of work between the two members

The project requires you to say who did what. A clean split:

- **Member 1 (attack side):** the victim server, the measurement harness, the Tier 1 baseline attacks, and one of the Tier 2 attacks (say the genetic algorithm). Owns the topology and timing diagrams and the "packet details" section.
- **Member 2 (analysis and defense side):** the other Tier 2 sponge attack (say the Engorgio-style EOS-suppression optimization, to complement Member 1's genetic-algorithm sponge), the concurrency/victim-impact experiment, all the plots and amplification tables, and the full defense with its before/after evaluation. Owns the justification and countermeasure sections.

Both members co-own the literature review and the final write-up. Put a small table in the report listing each subtask against a name, which is exactly what the spec asks for.

---

## 8. A ready-made experiment table to aim for

Plan to fill in a table like this in your final report. Having the empty shape now tells you exactly what to collect.

| Input type                  | Output tokens (x) | Latency (x) | GPU mem (x) | Honest-user latency (x) |
| --------------------------- | ----------------- | ----------- | ----------- | ----------------------- |
| Natural prompts (baseline)  | 1.00              | 1.00        | 1.00        | 1.00                    |
| Random-noise input          | ?                 | ?           | ?           | ?                       |
| Tokenizer-abuse input       | ?                 | ?           | ?           | ?                       |
| Naive output-forcing prompt | ?                 | ?           | ?           | ?                       |
| GA sponge (yours)           | ?                 | ?           | ?           | ?                       |
| Engorgio-style (yours)      | ?                 | ?           | ?           | ?                       |
| Best attack + defense ON    | ~1 (capped)       | ~1          | ~1          | ~1                      |

The last row is what earns the bonus: it shows the defense pulls every number back to roughly 1.

---

## 9. Common pitfalls and honesty notes

- **Do not fake network-layer artifacts.** This is an application-layer attack. Say so, and map "packet" to the API request. Graders prefer honesty over a fabricated frame diagram.
- **GPU timing is noisy.** Warm up, repeat, average, and report spread. The paper itself says timing can vary by up to 10x from hardware state.
- **A tiny model gives smaller factors than the papers.** That is fine and expected. You are demonstrating the mechanism, not competing with a datacenter study. Report factors relative to your own baseline.
- **Keep it local and legal.** Only attack your own server and your own local models. Do not point any of this at a real hosted service you do not own. The papers that tested real services (Azure) did so under paid, responsible-disclosure conditions, which is not something an undergraduate project should replicate.
- **Reproducibility is graded.** Pin the model revision, dataset, and seeds, fix decoding to greedy, and save your best attack prompts. Write the versions into the report.
- **Tie every claim to a source.** When you say "output length drives cost," cite LLMEffiChecker. When you say "optimized prompts reach the max length," cite Engorgio. When you say "rate limiting is not enough," cite the sponge paper. This makes your report bulletproof.

---

## 10. References (all verified)

1. I. Shumailov, Y. Zhao, D. Bates, N. Papernot, R. Mullins, R. Anderson. "Sponge Examples: Energy-Latency Attacks on Neural Networks." 2021. arXiv:2006.03463. (Your primary attached paper.)
2. S. Chen et al. "LLMEffiChecker: Understanding and Testing Efficiency Degradation of Large Language Models." ACM Transactions on Software Engineering and Methodology, 2024. arXiv:2210.03696.
3. J. Dong et al. "An Engorgio Prompt Makes Large Language Model Babble on." International Conference on Learning Representations (ICLR), 2025. arXiv:2412.19394.
4. Y. Zhang et al. "Crabs: Consuming Resource via Auto-generation for LLM-DoS Attack under Black-box Settings (AutoDoS)." Findings of ACL, 2025. arXiv:2412.13879. (Related work, cited not implemented, out of sponge scope.)
5. A. Kumar et al. "OverThink: Slowdown Attacks on Reasoning LLMs." 2025. arXiv:2502.02542. (Related work, cited not implemented, out of sponge scope.)
6. K. Gao et al. "Denial-of-Service Poisoning Attacks against Large Language Models (P-DoS)." 2024. arXiv:2410.10760. (Related work, cited not implemented, out of sponge scope.)
7. OWASP GenAI Security Project. "LLM04: Model Denial of Service" (2023/2024) and its 2025 successor "LLM10: Unbounded Consumption." genai.owasp.org.

---

### Final word

If you build Tier 1 plus one solid Tier 2 attack, run the concurrency test so the honest user's slowdown is visible, and implement the output-cap defense with a before/after table, you will have covered every required section of both reports and earned the bonus. The single sentence to keep in your head the whole time is: **an LLM's cost is its output length, and this attack is the art of making the model refuse to stop talking.**
