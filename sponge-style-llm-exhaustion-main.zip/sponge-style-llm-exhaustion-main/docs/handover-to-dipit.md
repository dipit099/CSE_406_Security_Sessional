# Handover to Dipit

Dipit, this is the handover note for Project 37. My half (the harder attacks, the
latent detector, the measurement foundation, and all my figures) is finished and
verified on a Kaggle T4 run. Your half is still stubs. This note tells you where
everything sits, what already works, what is left for you, and what you now own
that I am not touching anymore, which is the live demo our teacher asked for.

There is already a detailed, file by file implementation spec for your half in
`docs/dipit-implementation-guide.md`. I am not repeating that here. This note is
the map and the status; that other file is the how to. Read this one first, then
that one.

## The short version

1. Everything in "my half" below is done, tested, and produced real numbers on a
   GPU run. You do not need to touch any of those files, only import them.
2. Everything in "your half" below still raises `NotImplementedError`. That is
   what you build. The spec for each is in `docs/dipit-implementation-guide.md`.
3. The live demo (attacks working live, then defenses switched on and the attacks
   mitigated) is built and working in `demo/`. It is now yours to run on
   evaluation day. See the live demo section near the end.
4. One caveat about the results folders, read the "state of the results" section
   below before you trust `csv/` and `figures/`.

## State of the code and results

The code side is in good shape. Every module of mine compiles, has tests, and ran
end to end on Kaggle. Here is roughly what the numbers looked like on the last
good T4 run so you know what "working" means, but treat these as illustrative,
not gospel; a fresh run reproduces them within a bit because of random draws in
the crafted prompts:

- Engorgio (white box, on Qwen2.5-0.5B-Instruct): a natural question makes the
  model emit about 8 tokens, the crafted trigger makes it run to 512, so roughly
  64x more output and 61x more latency for one request.
- Genetic search (black box): random token sequences already push this small
  model to the 256 cap, so the meaningful signal is the fraction of the pool that
  reaches the cap climbing over generations, not the best line, which pins at the
  cap from the start.
- Queue starvation: one honest request behind three sponges goes from about a
  quarter of a second when idle to about three seconds, roughly 12.5x slower,
  with a single worker.
- L2 input validation: catches the tokenizer abuse prompts with zero false
  positives. Its detection rate looks low (about 0.25) on purpose, because L2 by
  design only targets the tokenizer abuse fingerprint; fluent "never stop" sponges
  slip past it, and catching those is L5's job.
- L5 latent detector: on the last complete run it scored about 0.957 accuracy and
  0.998 AUC with leakage free cross validation, and wrongly flagged only 1 of 6
  hard negatives (long but legitimate "explain in detail" prompts I added on
  purpose to stop the detector from cheating by just measuring length).
- Multi-model sweep: base models (gpt2, opt-125m, SmolLM2-360M base) babble to
  the cap on almost anything, so amplification there is about 1x. Instruct models
  (Qwen2.5-0.5B-Instruct, SmolLM2-360M-Instruct, TinyLlama-1.1B-Chat) answer
  normal prompts briefly and then blow up under sponges, which is where the 4x to
  32x amplification shows. The 1.5B instruct model is noticeably more robust to
  tokenizer abuse (about 1.6x) but still runs to the cap under output forcing.

## State of the results folders (read this)

The `csv/` and `figures/` folders in the repo are the outputs of my Kaggle runs.
The most recent run had a glitch that I caused while editing the notebook: the L5
cell got dropped and the multi-model cell got duplicated, so that run is missing
all the L5 outputs (`l5_scores.csv`, `l5_summary.csv`, `l5_roc.png`,
`l5_pca.png`) and it ran the model sweep twice. I have fixed `code/main.ipynb`, so
the notebook now has exactly one L5 cell and one multi-model cell in the right
order. If you or I want a clean, complete set of result files in one consistent
run, the notebook needs to be run once more on Kaggle. Nothing in the code is
wrong; it is only those output files from that one run that are incomplete.

If you re-run it: re-upload the `code/` folder as a new version of the Kaggle
dataset first (the notebook loads code from the attached dataset, not from the
notebook itself), attach it, and run all cells. The gated Llama models are
optional and are skipped automatically unless you set an `HF_TOKEN` Kaggle secret
and accept the two Llama licenses on Hugging Face.

## Project structure

```
report/            the design report (LaTeX source and compiled PDF)
docs/              this note, the implementation guide, findings, engorgio-explained
code/              all the implementation
  common/          config, model loading, energy meter, measurement harness, CSV helper
  attacks/         tier1_baselines (yours), tier2a_genetic (mine), tier2b_engorgio (mine)
  defenses/        l1,l3,l4,l6 + guard (yours); l2, l5 (mine)
  server/          FastAPI victim server + clients (yours)
  experiments/     per-request cost, length sweep, cross-model, defense eval (yours);
                   queue DoS, multi-model sweep, plots (mine)
  tests/           test_ahnaf_parts.py (mine); add test_dipit_parts.py for yours
  main.ipynb       the Kaggle orchestration notebook
demo/              the live attack/defense demo system (built, now yours to run)
csv/, figures/     result outputs from Kaggle runs
notebooks/         optional small-scale mechanism validation notebook
exploration/       the source papers and the assignment spec (papers are git ignored)
```

## My half (done, do not modify, just import)

These are finished and verified. You import them; you do not edit them.

- `code/common/config.py`, `model_utils.py`, `energy.py`, `metrics.py`,
  `csvout.py`: the foundation. Model loading, the greedy generate wrapper, the
  cost measurement harness, seeds, the model registry, and the CSV writer.
  Everything else goes through these so numbers stay comparable.
- `code/attacks/tier2a_genetic.py`: the black box genetic search.
- `code/attacks/tier2b_engorgio.py`: the white box Engorgio attack.
- `code/defenses/l2_input_validation.py`: the tokenizer abuse gate.
- `code/defenses/l5_latent_detector.py`: the hidden state SVM detector.
- `code/experiments/exp_queue_dos.py`: the single worker queue starvation experiment.
- `code/experiments/exp_multimodel.py`: the multi-model attack sweep.
- `code/experiments/plots.py`: all the figures.
- `code/tests/test_ahnaf_parts.py`: CPU smoke tests for my half.

## Your half (the stubs to build)

These twelve files still raise `NotImplementedError`. Each one carries a full
spec in its own docstring, and `docs/dipit-implementation-guide.md` walks through
all of them in the order to build them, with the report and paper references for
each. I am not going to re-explain the implementations here; that guide already
does it well. The files are:

- `code/attacks/tier1_baselines.py`
- `code/defenses/l1_output_cap.py`
- `code/defenses/l3_output_monitor.py`
- `code/defenses/l4_rate_limit.py`
- `code/defenses/l6_config_hygiene.py`
- `code/defenses/guard.py` (this one needs all four defenses above plus my l2 and l5)
- `code/server/app.py`
- `code/server/client.py`
- `code/experiments/exp_per_request_cost.py` (Table 2)
- `code/experiments/exp_length_sweep.py`
- `code/experiments/exp_cross_model.py`
- `code/experiments/exp_defense_eval.py` (the capstone, needs guard.py)

The build order, and which steps a grader most directly checks for, is spelled
out in section 1 of `docs/dipit-implementation-guide.md`. Short version: do
`tier1_baselines.py` first, then `exp_per_request_cost.py`, then the server, then
the four defenses, then `guard.py`, then `exp_defense_eval.py`. The placeholder
cells at the very end of `code/main.ipynb` are where these get wired into the
notebook once they exist.

## The live demo (teacher's requirement, now yours)

Our teacher asked for a live demonstration on evaluation day: show the attacks
working against a running LLM service, then switch the defenses on live and show
the same attacks getting mitigated. I built a complete, self contained system for
this and it works, but I am handing the running of it to you. Everything for it is
in `demo/`, and `demo/README.md` is the full guide. In short:

- `demo/victim_server.py` is a small LLM served behind a single worker with a
  browser dashboard. `demo/dashboard.html` is that dashboard: it has a model
  picker, independent on/off switches for each defense (L2, the output cap, and
  L5), buttons to fire each attack one at a time, a custom prompt box, and a queue
  attack button that shows the honest user's latency before and after defenses as
  two bars. It polls the server and updates live, which is what makes it a good
  thing to put on the projector.
- It reuses my real L2 and L5 code, so what you demo is the same code as the
  report, not a mock up.
- You can run it three ways, described in `demo/README.md`: locally with Docker,
  on a Google Cloud VM (so your laptop does nothing and the teacher just opens a
  URL), or you can drive it from the scripted runner `demo/run_demo.py`.

About the cloud VM: I set one up during testing on a Google Cloud project of mine
and then stopped it to avoid charges, so it is not running now. For your own demo I
would not rely on my project. Either redeploy fresh with `demo/deploy_gcp.sh` on
your own Google Cloud account (the script and the Windows PowerShell commands for
starting, stopping, getting the URL, and deleting the VM are all documented in
`demo/README.md`), or just run it locally with Docker, which is simpler and has no
billing to worry about. The one thing to remember from my testing is that on
Windows the gcloud commands work from PowerShell but not from Git Bash, so run
them from PowerShell.

What I would actually do for the demo, if it helps: pick the instruct model in the
dashboard (Qwen2.5-0.5B-Instruct or TinyLlama) because that is where the "normal
request is short, sponge runs forever" contrast is dramatic. Warm the model up
before the teacher is watching (the first load downloads it). Fire a normal
request, then a tokenizer abuse sponge, then an output forcing sponge, all with
defenses off, and point at the token counts and latency. Then flip L2 and the
output cap on and fire the same attacks again and show them blocked or capped.
Finish with the queue attack button to show the honest user's wait collapsing once
defenses are on. All of that is point and click on the dashboard.

## What to read before you start

In this order:

1. `docs/dipit-implementation-guide.md`, the whole thing. It is the spec for your
   half and it is the single most important document for you.
2. `report/design_report.pdf`, especially section 3 (topology) and section 4
   (packet and frame structure) for the server, section 5.1 (Tier 1 baselines)
   for your attack module, section 7 Table 2 for the per request cost experiment,
   and section 8 with Figure 9 for the layered defense and the guard.
3. `Sponge_Examples.pdf` section 4.2.1 in `exploration/`, for the exact tokenizer
   abuse example your baseline should reproduce.
4. My three foundation modules, so you know what you are importing and do not
   reinvent them: `code/common/model_utils.py`, `code/common/metrics.py`,
   `code/common/config.py`. Read them, do not edit them.
5. Skim `code/attacks/tier2a_genetic.py` for coding style (dataclass results,
   docstrings, type hints, everything routed through `metrics` and `model_utils`).
   Match that style so the codebase stays consistent.

You do not need to read the Engorgio or LLMEffiChecker papers in depth. Those
ground my Tier 2b and L5, which are done. You do need the Sponge Examples section
above for your tokenizer abuse baseline.

## Gotchas I learned the hard way

- After you change anything under `code/`, you have to re-upload the `code/`
  folder as a new version of the Kaggle dataset and re-attach it, or the notebook
  silently runs the old code. This bit me more than once.
- The notebook itself is separate from the `code/` dataset. If you edit
  `code/main.ipynb` locally, you also have to sync those cells into the Kaggle
  notebook you actually run.
- L2's tokens per character threshold (0.35) was calibrated on the Qwen tokenizer.
  Other model families tokenize differently, so if you ever run L2 against a
  different tokenizer, that number may need re-checking. For your defense eval on
  the primary Qwen model it is fine as is.
- Base models babble to the cap on any input, instruct models do not. That is why
  amplification is only visible on instruct models. Do not read a base model's 1x
  amplification as "the attack failed"; it means the baseline was already at the
  cap.
- Report whatever you actually measure. My numbers came from my specific runs and
  yours will differ a little. That is expected and fine. Do not copy my numbers
  into your tables; run it and use yours.

## When are you done

Your half is done when the twelve stub files are implemented and pass a smoke
test, the server serves `/generate` and the queue starvation shows up over real
HTTP, the layered guard blocks or caps sponges while letting benign prompts
through, and `exp_defense_eval.py` shows the amplification dropping toward 1x with
defenses on. The definition of done for each piece, and how to test it, is in
section 3 of `docs/dipit-implementation-guide.md`. For the live demo, done means
you can run it in front of the teacher and switch defenses on and off on the
dashboard.

If anything in my half is unclear, read the module docstring first; I tried to
make each one explain itself. Good luck.
