# The EOS-suppression attack (Engorgio), explained simply

This note explains Tier 2b of our project, the white-box EOS-suppression attack from the Engorgio
paper (Dong et al., ICLR 2025). It is written to remove the confusion, not for the report.

## 1. What are we trying to do?

An LLM generates its answer one token at a time and **stops when it outputs the special EOS
(end-of-sequence) token**. So a long answer costs a lot, a short answer costs little, and the length
is decided by *when EOS shows up*.

Our goal: **find one prompt that makes the model keep generating for as long as possible**, ideally
until it hits the server's `max_tokens` ceiling. In other words, find a prompt whose continuation
almost never produces EOS.

## 2. Why is this hard? (the one obstacle)

The natural idea is: "use the model's gradients to tune the prompt so EOS becomes unlikely." Gradient
descent is how we optimize anything with a neural network.

But there is a catch. **A prompt is made of discrete tokens (word pieces).** Gradients are about
smooth, continuous changes ("nudge this number up a little"). You cannot "nudge" the word `cat` a
little; there is no token halfway between `cat` and `dog`. So you cannot directly run gradient descent
on the actual tokens of a prompt.

Everything clever in this attack is about getting around that one obstacle.

## 3. The trick: a "soft prompt"

Instead of committing to one token at each position, we keep a **probability distribution over the
whole vocabulary at each position**. Think of each position as a dial that is spread across all
possible tokens: 12% `the`, 3% `cat`, 0.5% `///`, and so on. Call this soft prompt `θ` (theta). It is
just a big table of numbers (one row of probabilities per position), and numbers *can* be nudged by
gradients.

To feed this soft prompt into the model, we turn each position's distribution into a **blended
embedding**: a weighted average of every token's vector, weighted by that position's probabilities.
Every token in the model already has an embedding vector; we just mix them. This blended vector is
continuous, the model can process it, and gradients can flow back through it to `θ`. That is the whole
point: the soft prompt is a differentiable stand-in for a real prompt.

(One detail: the paper uses "Gumbel-softmax" to turn `θ` into those weights. That is just a standard,
differentiable way to sample from a distribution. Not important for understanding.)

## 4. The loss: push EOS down everywhere

Now we run the model forward on the soft prompt and measure how likely EOS is. We want EOS to be
unlikely, so we minimize the **EOS-escape loss**:

> add up the model's probability of EOS at *every* position, and make that sum small.

Why every position instead of a specific one? Because we cannot predict in advance *where* the model
would want to stop. So we suppress EOS everywhere at once. Push this loss down with gradient descent
and EOS becomes unlikely across the whole sequence, meaning the model has no natural place to stop.

## 5. The second loss: keep the soft prompt realistic

There is a subtlety. `θ` covers not just the prompt but also the *imagined continuation* the model
would generate. If we only minimized the EOS loss, we might get a soft table that avoids EOS but does
not correspond to any real prompt the model would actually continue for a long time.

So we add a **self-mentor loss**: it forces the soft sequence to be *self-consistent*, meaning the
token the table puts at position `i+1` matches what the model itself predicts after seeing positions
`1..i`. In plain terms, it makes the imagined continuation look like a genuine model generation. This
is what ties the prompt to a real, long output instead of a meaningless blob.

Total objective: `minimize (EOS-escape loss) + λ · (self-mentor loss)`.

## 6. Getting the actual prompt out

After optimizing `θ` (the paper uses Adam, ~300 steps), we throw away the "continuation" part and keep
only the first `t` positions (the prompt, default `t = 32`). At each of those positions we read off
the **most likely token**. Stringing those tokens together gives the final, discrete **Engorgio
prompt**. That is what we send to the victim model.

Because `θ` was optimized so that (a) EOS stays unlikely and (b) the sequence is self-consistent, this
prompt's natural continuation is very long.

## 7. One-paragraph summary

We want a prompt that makes the model never stop. We cannot gradient-optimize discrete tokens, so we
optimize a "soft prompt" (a probability distribution over tokens at each position), blend it into an
embedding the model can read, and push down the model's EOS probability at every step while keeping
the sequence realistic. Then we read off the most likely token at each prompt position to get the real
crafted prompt. On the paper's models this makes outputs 2 to 13 times longer, reaching over 90% of
the ceiling.

## 8. Why it beats the model's "stop when done" training

The model was trained to emit EOS when the answer is complete. But EOS is not a hard rule, it is a
*prediction*: at each step the model outputs whatever token is most likely, and it stops only if EOS
is that token. This attack shapes the input so that at every step some other token stays more likely
than EOS. The model's stop signal never wins, so it keeps generating even though it was trained to be
concise. The attack does not argue with the model; it quietly rigs the probabilities.
