# Dipit's Implementation Phases — Project 37

A compact, trackable plan for my half of the sponge-style LLM exhaustion project.
Derived from `docs/handover-to-dipit.md`, `docs/dipit-implementation-guide.md`,
`code/README.md`, Ahnaf's foundation modules, and the Sponge Examples paper
(`2006.03463v2.pdf`).

---

## Scope at a glance

**I own 12 stub files** (all currently `raise NotImplementedError`), plus tests,
notebook wiring, one Kaggle run, and the live demo. **I never edit Ahnaf's files** —
I only import them.

| # | File | What it is |
|---|------|-----------|
| 1 | `attacks/tier1_baselines.py` | Tier-1 naive attacks |
| 2 | `defenses/l1_output_cap.py` | Output/compute cap |
| 3 | `defenses/l3_output_monitor.py` | Repetition monitor |
| 4 | `defenses/l4_rate_limit.py` | Rate limit / quota |
| 5 | `defenses/l6_config_hygiene.py` | Config hygiene |
| 6 | `defenses/guard.py` | Layered guard (needs 2–5 + Ahnaf's L2/L5) |
| 7 | `server/app.py` | FastAPI victim server |
| 8 | `server/client.py` | Attacker / honest clients |
| 9 | `experiments/exp_per_request_cost.py` | Table 2 |
| 10 | `experiments/exp_length_sweep.py` | Latency vs length |
| 11 | `experiments/exp_cross_model.py` | Cross-model check |
| 12 | `experiments/exp_defense_eval.py` | Capstone (needs guard) |

**I import (never edit):** `common.{model_utils, metrics, config, csvout}`,
`defenses.{l2_input_validation, l5_latent_detector}`,
`attacks.{tier2a_genetic, tier2b_engorgio}`.

**Key imported signatures:**
- `metrics.measure_prompt(...)` / `metrics.measure_generation(...)` → `Measurement`
- `metrics.amplification(value, baseline)`
- `l2.validate_input(text, tokenizer, model).ok` / `l2.evaluate_validator(...)`
- `l5.LatentDetector(model, tokenizer).fit(benign, sponge)` → `.accuracy`, `.auc`; `.predict(texts)`
- `exp_queue_dos._make_worker(...)` — the single-worker `queue.Queue()` pattern for the server

---

## Build order (dependencies)

```
1 tier1 ──> 9 per_request_cost (Table 2)
        └─> 10 length_sweep
7,8 server/client ── (independent)
2,3,4,5 defenses ──> 6 guard ──> 12 defense_eval (capstone)
11 cross_model ── (independent)
```

Do 1 → 9 → 10 → server → defenses → guard → defense_eval → cross_model.
Steps 1–8 map most directly to what a grader checks (topology + Table 2).

---

## Paper grounding (`2006.03463v2.pdf`)

- **Tokenizer abuse:** `Athazagoraphobia` (16 chars) = 4 tokens; slashed
  `A/h/z/g/r/p/p/i/` = 16 tokens for the same length → 4× the tokens. Grounds Phase 1.
  *Citation note:* the handover cites `Sponge_Examples.pdf §4.2.1`; in the copy I read
  (`2006.03463v2.pdf`) the tokenizer-abuse mechanism is discussed in **§5.2** and I did
  not find the literal example in the main body — confirm the section number against
  `exploration/Sponge_Examples.pdf`. The numbers hold regardless of section number.
- **Defense = cut-off threshold** (§7.2): profile natural cost, then bound
  per-inference consumption. This *is* my L1 output cap.
- **"Rate limiting is not enough"** (§7.1): a sponge raises cost *per request*, not
  request *count*. My L4 must reproduce this honest finding.

---

## Phases

Each phase: **Input → Goal → Output → Verify (what to look at).**

### Phase 0 — Setup & baseline verification
- **Input:** repo as-is; `tests/test_ahnaf_parts.py`; env from `code/requirements.txt`.
- **Goal:** confirm Ahnaf's half runs here (so later failures are mine). Decide GPU
  route (Kaggle T4). Decide the crafted prompt for Table 2 (Ahnaf's real
  `EngorgioResult.trigger_text` / `GAResult.best_text`, or a strong hand-written
  sponge until I get it).
- **Output:** `test_ahnaf_parts.py` passes on CPU; foundation imports work.
- **Verify:** test script prints all-pass; a tiny model generation runs without error.

### Phase 1 — Tier 1 baselines  (`attacks/tier1_baselines.py`)
- **Input:** stub spec; paper §5.2; the real Qwen tokenizer.
- **Goal:** `tokenizer_abuse_prompt(text, mode="slash")` (separators between chars),
  `output_forcing_prompt()` (my own "count to 100000, no early stop" string),
  `tokens_per_char(text, tokenizer)` (empty string → `0.0`).
- **Output:** three working functions; a printed before/after token count.
- **Verify:** encode `"Athazagoraphobia"` vs slashed version → **token count jumps
  several-fold for ~same char count** (exact ratio differs from paper; fine).

### Phase 2 — Per-request cost, Table 2  (`experiments/exp_per_request_cost.py`)
- **Input:** Phase 1; `metrics.measure_prompt`; crafted prompt from Phase 0.
- **Goal:** `run_per_request_cost(model, tokenizer, ceiling=512)` measuring
  natural vs naive vs crafted via `measure_prompt` + `amplification`; `main()` prints.
  **Every number from a real call — never typed in.**
- **Output:** table `Input | Out tokens | Latency (s) | Latency× | Energy×`, 3 rows.
- **Verify:** CPU dry-run at `ceiling=16` (no crash); table shows **crafted/naive
  out_tokens near ceiling and latency× ≫ 1×, natural ≈ 1×**. Real magnitudes on GPU.

### Phase 3 — Latency vs output length  (`experiments/exp_length_sweep.py`)
- **Input:** Phase 1's `output_forcing_prompt()`; `metrics.measure_generation`.
- **Goal:** `run_length_sweep(model, tokenizer, lengths=(16,32,64,128,256,512))` —
  cap `max_new_tokens=L`, collect `(L, latency_s, energy_j, gpu_mem_mb)`.
- **Output:** one row per L + a one-line note on linearity. (Plot optional.)
- **Verify:** latency **rises monotonically and ~proportionally with L**.

### Phase 4 — Client/server topology  (`server/app.py`, `server/client.py`)
- **Input:** report §3 (topology) / §4 (packet fields); `exp_queue_dos._make_worker`.
- **Goal:** `create_app(model_name=None, defense=False)` — load model once, one
  background worker on a `queue.Queue()`, `POST /generate` body `{"prompt","max_tokens"}`
  → `{"output","out_tokens","latency_s"}` (exact names = report Listing 1/2).
  `client.py`: `send_request`, `attacker_blast(n)`, `honest_latency`. `defense=True`
  may warn/raise until Phase 6.
- **Output:** uvicorn on `127.0.0.1:8000`; client helpers returning timed dicts.
- **Verify:** normal `send_request` → **JSON keys exactly `output`/`out_tokens`/`latency_s`**;
  `attacker_blast` + `honest_latency` → **honest request visibly slower** (real-HTTP Table 3).

### Phase 5 — Supporting defenses  (`l1`, `l3`, `l4`, `l6`)
- **Input:** stub docstrings; `transformers.StoppingCriteria`; paper §7.1/§7.2.
- **Goal:**
  - **L1** `capped_generate(...)` → token cap **+** wall-clock `StoppingCriteria`;
    returns `(output_ids, n_new, hit_cap)`.
  - **L3** `monitored_generate(...)` → kill when an n-gram repeats `> repeat_limit`.
  - **L4** `RateLimiter(max_requests, window_s, max_output_tokens=None)` with
    `allow`/`record`; sliding window + optional cost-aware token budget.
  - **L6** `sanitise_request(payload)` (strip `logprobs`/`logit_bias`, clamp
    `max_tokens`) + `contains_glitch_tokens(text, tokenizer)` (short denylist).
- **Output:** four independent, unit-testable modules.
- **Verify (unit tests):** L4 `allow` **False after `max_requests` in `window_s`**;
  L3 **kills a repetitive generation but NOT an honest one**; L1 `hit_cap=True` on a
  long forced generation, `False` on a short one; L6 clamps oversize `max_tokens` and
  flags a denylisted id.

### Phase 6 — Layered guard  (`defenses/guard.py`)
- **Input:** Phase 5; Ahnaf's `l2.validate_input(...).ok`, `l5.LatentDetector.predict`;
  report Figure 9.
- **Goal:** `LayeredGuard(model, tokenizer, detector=None)`, `handle(client_id, prompt)`
  → `{blocked, reason, out_tokens, latency_s, hit_cap}`. Order (Figure 9):
  **L6 → L2 → L5 → L4 → (L1+L3 wrapped generate)**. Pass a pre-fitted `detector` in.
- **Output:** one class routing all six layers, recording which layer blocked.
- **Verify:** on CPU with a few benign + sponge prompts → **sponges `blocked=True` with
  expected `reason`; benign pass with real `out_tokens`/`latency_s`**; no crash.

### Phase 7 — Defense evaluation (capstone)  (`experiments/exp_defense_eval.py`)
- **Input:** Phase 6 guard; `l5.LatentDetector.fit`, `l2.evaluate_validator`;
  benign + sponge prompt sets.
- **Goal:** `run_defense_eval(model, tokenizer, sponge_prompts, benign_prompts)`
  printing four things: (1) baseline amplification (defense off), (2) defended
  amplification (through guard), (3) detector scores — L5 `.accuracy`/`.auc` + L2
  detection / false-positive rate, (4) honest-request latency overhead on vs off.
- **Output:** short 4-part summary table (optional figure via `plots.py`).
- **Verify:** **defended amplification collapses toward 1× while baseline stays high**
  (§8 claim); L5 AUC high; L2 FP rate ≈ 0; honest overhead small.

### Phase 8 — Cross-model check  (`experiments/exp_cross_model.py`)
- **Input:** `config.MODEL_NAME` (Qwen2.5-0.5B-Instruct), `ALT_MODEL_NAME` (Qwen3-0.6B);
  a sponge + natural prompt.
- **Goal:** `run_cross_model(sponge_prompt, natural_prompt, ceiling=256)` — load each
  with `enable_thinking=False`, report out-token + latency amplification side by side.
- **Output:** two-model comparison table.
- **Verify:** **sponge amplification > 1× on both models** (magnitudes may differ —
  that's the point; the lever still works on a newer model).

### Phase 9 — Tests, notebook wiring, one clean Kaggle run
- **Input:** Phases 1–8; T4 Kaggle setup. Note: current `csv/`/`figures/` are missing
  the `l5_*` outputs from Ahnaf's glitched run.
- **Goal:** write `tests/test_dipit_parts.py` (pure-logic first, then tiny-model);
  wire my experiments into the tail cells of `main.ipynb`; re-upload `code/` as a new
  Kaggle dataset version; run all cells once.
- **Output:** complete, consistent `csv/` + `figures/` (L5 regenerated) + my new tables.
- **Verify:** **`test_dipit_parts.py` all-pass**; `/kaggle/working/figures/` and `csv/`
  fully populated (L5 present, sweep run once); Table 2 / defense-eval numbers real.

### Phase 10 — Live demo dry-run  (`demo/`, already built, now mine)
- **Input:** `demo/README.md`, `victim_server.py`, `dashboard.html`, `run_demo.py`.
- **Goal:** run end-to-end (local Docker simplest — no billing); rehearse the eval-day
  script: normal → tokenizer-abuse → output-forcing (defenses off), then flip L2 +
  output cap on and re-fire, finish with the queue-attack button.
- **Output:** a working dashboard drivable on a projector.
- **Verify:** on the dashboard, **tokens/latency spike under attack with defenses off,
  then get blocked/capped when toggled on, and the honest-user latency bar collapses**.

---

## Open questions / dependencies

1. **Crafted prompt for Table 2 (Phase 2):** do I have Ahnaf's real
   `EngorgioResult.trigger_text` / `GAResult.best_text`, or use a hand-written sponge
   until then? (Only cross-person dependency.)
2. **GPU access:** own Kaggle account with GPU quota? Real numbers in Phases 2, 7, 8, 9
   need a T4 run; CPU only proves "doesn't crash."
3. **Demo hosting (Phase 10):** local Docker vs fresh GCP VM (Ahnaf's is stopped).
   Is Docker installed?
4. **Report cross-check:** confirm exact field names for Listing 1/2 and Table 2's
   column layout against `report/design_report.pdf` before implementing Phases 2 & 4.

---

## Time estimate & critical path

| Phase | Est. | Parallelizable |
|-------|------|----------------|
| 0 Setup | 0.5h | — |
| 1 Tier-1 | 1–2h | yes |
| 2 Table 2 | 1–2h | needs 1 |
| 3 Length sweep | 1–2h | yes (with 4) |
| 4 Server/client | 3–4h | yes |
| 5 Defenses L1/L3/L4/L6 | 6–8h | yes (each independent) |
| 6 Guard | 2–3h | needs 5 |
| 7 Defense eval | 2–3h | needs 6 |
| 8 Cross-model | 1h | yes |
| 9 Tests + notebook + Kaggle | 2–3h | needs 1–8 |
| 10 Demo | 0.5h | already built |

**Total ≈ 25–35h**, heavily parallelizable.
**Minimum critical path to a passing submission:** 1 → 2 → 5 → 6 → 7.

---

## Gotchas (verified — do not skip)

1. **Kaggle dataset sync:** after editing anything under `code/`, re-upload the folder
   as a **new dataset version** and re-attach it, or the notebook silently runs old code.
   The notebook itself is separate from the dataset — sync `main.ipynb` cells too.
2. **L2 needs the tokenizer:** `validate_input(text, tokenizer, model=None)` — the
   tokenizer arg is **required**. Result is `ValidationResult(ok, reasons, stats)`;
   use `.ok` and `.reasons` (a **list**), there is no `.reason`.
3. **L2 exempts short inputs:** `min_chars_for_ratio = 40`, so a short slashed prompt
   (e.g. a 9-char "hello") is **not** flagged by the tokens/char rule — only long
   abuse (≥40 chars) trips it. Test L2 with a genuinely long abuse string.
4. **L2 threshold is Qwen-calibrated** (`0.35` tokens/char). A different tokenizer may
   need re-checking; fine as-is for the primary Qwen model.
5. **L5 `fit()` returns a report — it does not set attributes.** Do
   `report = det.fit(benign, sponge); report.accuracy; report.auc`. `det.accuracy`
   does not exist. `predict()`/`predict_proba()` take a **list** of texts.
6. **Fit L5 in the eval, not in the guard.** The detector needs labelled benign-vs-sponge
   data; construct+fit it once in `exp_defense_eval.py` and pass it into `LayeredGuard`.
7. **`evaluate_validator(texts, labels, tokenizer)` returns a dict** — read
   `ev["detection_rate"]`, `ev["false_positive_rate"]`, `ev["accuracy"]` (not attributes).
8. **Base vs instruct amplification:** base models (gpt2, opt) babble to the cap on any
   input → ~1× amplification. Only instruct models (Qwen-Instruct, TinyLlama) show real
   amplification. 1× on a base model means "baseline already at cap," not "attack failed."
9. **Single worker only.** The server must have exactly ONE background worker thread on
   the queue — two workers defeats the queue-starvation demo.
10. **`generate` returns a 2-D `[batch, seq]` tensor.** Compute new tokens from shapes
    (`out.shape[1] - prompt_len`), not `len(output_ids)`.
11. **Report measured numbers, never the report's placeholders.** Different runs,
    tokenizers, and hardware give slightly different numbers — that is expected.

---

## Demo walkthrough (eval day, from `demo/dashboard.html`)

1. **Warm up** — send one normal request first (first load downloads the model).
2. Defenses OFF → normal request: short output (~10 tokens), fast.
3. Defenses OFF → output-forcing sponge: long output (~cap), slow.
4. Toggle **output cap (L1)** ON → same sponge: output **capped**, fast.
5. Defenses OFF → tokenizer-abuse sponge: long/slow.
6. Toggle **L2** ON → same sponge: **blocked before generation**.
7. Toggle **L5** ON → a fluent "never stop" prompt: **caught by the latent detector**.
8. **Queue attack** button → 3 sponges then 1 honest request: honest latency high with
   defenses off, **collapses** with defenses on.

Pick an instruct model (Qwen2.5-0.5B-Instruct or TinyLlama) — that's where the
short-normal / long-sponge contrast is dramatic. Local Docker is the simplest host.

---

## Implementation status (local, CPU, 0.5B — as of this session)

All 12 modules implemented and verified locally against the real
Qwen2.5-0.5B-Instruct (venv: Python 3.14 + torch 2.14 + transformers 5.17).
`tests/test_dipit_parts.py` = **37/37 pass**. Illustrative local numbers (tiny
CPU sizes; real magnitudes come from the Kaggle GPU run):

- Tier-1: `Athazagoraphobia` 6→16 tokens (slash), 6→7 (typo).
- Guard: benign passes; tokenizer-abuse→L2 block; `<|im_start|>`→L6 block;
  counting sponge→L1 cap; fluent never-stop→L5 block (AUC ~0.90).
- Defense eval (ceiling 96): baseline **5.0× → defended 0.0×** (6/6 blocked),
  L2 FP 0.00, honest overhead +6.4%.
- Server: honest latency **1.16s idle → 7.4s behind 3 sponges** over real HTTP.
- Cross-model (real 2 models): Qwen2.5 **8.0×**, Qwen3-0.6B **6.4×** (thinking off).

**Kaggle GPU run DONE** (notebook `dipit099/security-project-part-a`,
scriptVersionId 349784257, T4, 16 cells, 0 errors). Real headline numbers:

| Experiment | Result (T4 GPU) |
|---|---|
| Table 2 per-request cost | natural 8 tok → crafted 512 tok = **60.9× latency, 74.6× energy** |
| Length sweep | linear: 16→0.48 s … 512→15.35 s (~30 ms/token) |
| Defense eval | amplification **18.0× → 0.0×** (20/20 blocked); L5 acc 0.957 / AUC 0.998; L2 FP 0.00 |
| Cross-model | Qwen2.5 **30.2×**, Qwen3-0.6B **23.3×** |
| Server queue-DoS (HTTP) | honest **1.76 s idle → 47.95 s** behind 3 sponges = **27.2×** |

All results + a full old-vs-new comparison are in `dipit_results/` (31 CSVs, 11
figures, `RESULTS.md`). The previously-missing `l5_*` outputs are regenerated
and byte-identical to the restored set (so nothing in the repo was "wrong" —
this run adds the 6 Dipit experiments and reproduces the shared results).

Remaining: **only the live demo (Phase 10)** — Docker is available.

## Done checklist

- [x] **0** Ahnaf's tests pass on CPU (27/27); foundation imports work.
- [x] **1** Three Tier-1 functions work; token count jumps on slashed input.
- [x] **2** Table 2 prints with **real** measurements (crafted = `eng_res.trigger_text`).
- [x] **3** Length sweep shows latency ~linear in output tokens.
- [x] **4** Server handles real HTTP; queue starvation visible; JSON keys exact.
- [x] **5** Each of L1/L3/L4/L6 passes its unit test in isolation.
- [x] **6** Guard runs all six layers in Figure-9 order; blocks/caps as expected.
- [x] **7** Defense eval: amplification collapses with defenses; L5/L2 scores reported.
- [x] **8** Cross-model shows amplification > 1× on both models (real run).
- [x] **9a** `test_dipit_parts.py` all-pass; `main.ipynb` wired with 6 Dipit cells.
- [x] **9b** Clean Kaggle GPU run done (T4, 0 errors); `l5_*` regenerated; results in `dipit_results/`.
- [ ] **10** Demo runs; attacks visible, defenses block/cap live. *(Docker on — next)*
