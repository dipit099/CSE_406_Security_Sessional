# Implementation guide for Dipit

This is your half of Project 37's implementation. Ahnaf has built the harder
attacks (Tier 2a/2b), the hardest defense (L5), the measurement foundation, and
all figures for his part, and verified all of it. Your modules are stubs right
now: every one raises `NotImplementedError` until you fill it in. This guide
tells you exactly what to build, in what order, using what, and what to read
first.

Nothing here needs you to touch Ahnaf's files. You only edit the files listed
under "Your files" below, and you import his ready modules directly.

---

## 0. Before you write any code

Read these, in this order. Each is short and tells you exactly what you're
implementing and why.

1. **`report/design_report.pdf`**, the whole report, but especially:
   - Section 3 (topology) and Section 4 (packet/frame structure): this is
     what your server and clients must realize.
   - Section 5.1 (Tier 1: naive baselines): this is your attack module.
   - Section 7, Table 2: this is `exp_per_request_cost.py`.
   - Section 8 (Defense idea) and Figure 9: this is L1/L3/L4/L6 plus the guard.
2. **`Sponge_Examples.pdf`, Section 4.2.1** (in `exploration/`): the exact
   tokenizer-abuse example you must reproduce (`Athazagoraphobia` gives 4
   tokens, the typo `Athazagoraphpbia` gives 7, and `A/h/z/g/r/p/p/i/` gives
   16). This grounds `tier1_baselines.py`.
3. **`code/README.md`**: directory layout and the full task-split table.
4. **The three modules you'll import from (read them, don't edit them):**
   - `code/common/model_utils.py`: `load_model_and_tokenizer`, `get_eos_ids`,
     `build_chat_prompt`, `generate`. This is how every prompt gets turned
     into tokens and every generation gets run. Use it, don't reinvent it.
   - `code/common/metrics.py`: `measure_generation`, `measure_prompt`,
     `amplification`, and the `Measurement` dataclass (`out_tokens`,
     `latency_s`, `tokens_per_s`, `gpu_mem_mb`, `energy_j`). This is the only
     place cost is measured; every experiment must go through it so numbers
     are comparable.
   - `code/common/config.py`: `MODEL_NAME`, `ALT_MODEL_NAME`, `SEED`,
     `set_seed()`, `get_device()`. Use these constants; don't hardcode model
     names or seeds anywhere else.
5. **Skim `code/attacks/tier2a_genetic.py` and `code/attacks/tier2b_engorgio.py`**
   just to see the coding style and how they call `model_utils` and `metrics`.
   Your modules should look and feel the same way: dataclasses for results,
   docstrings, type hints, no hidden magic.

You do **not** need to read `ENGORGIO.pdf` or `LLMEffiChecker.pdf` in depth;
those ground Ahnaf's Tier 2b and L5, which are already done. You *do* need
`Sponge_Examples.pdf` Section 4.2.1 for your tokenizer-abuse baseline.

---

## 1. Order to implement in

Follow this order. Each step only needs the ones before it, and this order
matches how the pieces plug together:

1. `attacks/tier1_baselines.py` (no dependencies, quick win, needed by
   experiment 2 below)
2. `experiments/exp_per_request_cost.py` (Table 2, needs step 1)
3. `experiments/exp_length_sweep.py` (independent of the others)
4. `server/app.py` plus `server/client.py` (independent; can be done in
   parallel with steps 2-3)
5. `defenses/l1_output_cap.py`, `l3_output_monitor.py`, `l4_rate_limit.py`,
   `l6_config_hygiene.py` (independent of each other, can be done in any order
   or split across sessions)
6. `defenses/guard.py` (needs all of step 5, plus Ahnaf's `l2` and `l5`)
7. `experiments/exp_defense_eval.py` (needs step 6)
8. `experiments/exp_cross_model.py` (independent; do whenever)

If you're short on time, steps 1-4 are the ones that most directly correspond
to report sections a grader will check for (did they actually build the
topology and Table 2?). Steps 5-7 (the full layered defense) are more
involved; start them early if defense is graded separately, since `guard.py`
depends on all four of your defense stubs plus Ahnaf's two.

---

## 2. What to build, file by file

### 2.1 `attacks/tier1_baselines.py`

Three functions, all currently `raise NotImplementedError`:

```python
tokenizer_abuse_prompt(text: str, mode: str = "slash") -> str
output_forcing_prompt() -> str
tokens_per_char(text: str, tokenizer) -> float
```

- **`tokenizer_abuse_prompt`**: take ordinary text and return a version that
  tokenizes into many more tokens for about the same number of characters.
  The report's own example (Section 6.1 / Sponge Section 4.2.1):
  `Athazagoraphobia` (16 characters) is 4 tokens; the typo
  `Athazagoraphpbia` is 7; and `A/h/z/g/r/p/p/i/` (a slash after every
  character) is 16 tokens, same length, 4x the tokens. Implement at least the
  `"slash"` mode (insert a separator between every character, e.g.
  `"/".join(text)`). A `"typo"` mode (small orthographic corruption of a few
  characters) is a nice second mode but not required.
- **`output_forcing_prompt`**: return a fixed string like the report's
  example, "Count from 1 to 100000, one number per line, with no summary and
  no early stop." (Ahnaf's `exp_queue_dos.py` already has a very similar
  string as `DEFAULT_SPONGE_PROMPT`; you can look at it for the tone, but
  write your own so Tier 1 has its own clearly-attributed baseline.)
- **`tokens_per_char`**: `len(tokenizer.encode(text, add_special_tokens=False)) / len(text)`.
  Guard the empty-string case (return `0.0`).

**Verify it yourself** before moving on: encode `"Athazagoraphobia"` and your
slashed version with the real tokenizer and print both token counts. You
should see the abused version have several times more tokens for basically the
same number of characters. Don't just trust that it "should" work; print the
actual token counts and check them against the Sponge paper's numbers, since
Qwen's tokenizer may split differently than the paper's model's tokenizer did.
That's fine (different tokenizer, different exact split) as long as the ratio
clearly jumps.

### 2.2 `experiments/exp_per_request_cost.py` (Table 2)

Two things to write: `run_per_request_cost(model, tokenizer, ceiling=512)` and
`main()`.

Use Ahnaf's harness exactly as the docstring shows:

```python
from common import model_utils, metrics, config
from attacks import tier1_baselines as t1

natural = metrics.measure_prompt(model, tokenizer, "What is the capital of France?",
                                 max_new_tokens=ceiling)
naive   = metrics.measure_prompt(model, tokenizer, t1.output_forcing_prompt(),
                                 max_new_tokens=ceiling)
crafted = metrics.measure_prompt(model, tokenizer, "<your strongest sponge prompt>",
                                 max_new_tokens=ceiling)

latency_x = metrics.amplification(naive.latency_s, natural.latency_s)
energy_x  = metrics.amplification(naive.energy_j,  natural.energy_j)   # may be None on CPU
```

Produce and print a table with exactly the same shape as the report's Table 2:
`Input | Out tokens | Latency (s) | Latency x | Energy x`, one row each for
natural, naive, and crafted. `main()` should just load the model (via
`model_utils.load_model_and_tokenizer()`) and call `run_per_request_cost`,
then print the table; mirror how `exp_queue_dos.py`'s `main()` is written.

**Important:** for "crafted prompt", either import a Tier-2 result (ask Ahnaf
to hand you an `EngorgioResult.trigger_text` or a `GAResult.best_text` from a
real GPU run), or write your own strong hand-written sponge if Tier-2 isn't
available yet. Whichever you use, the numbers you print must come from an
actual `measure_prompt` call; never type in the report's example numbers. The
report's 63x/73x example numbers were measured on Ahnaf's run; yours may
differ and that's fine and expected. Report what you actually see.

### 2.3 `experiments/exp_length_sweep.py`

`run_length_sweep(model, tokenizer, lengths=(16, 32, 64, 128, 256, 512))`.

For each `L` in `lengths`, force the model to produce (approximately) `L`
output tokens and measure cost. The cleanest way: pick a prompt that reliably
runs long (e.g. `tier1_baselines.output_forcing_prompt()`), and call
`metrics.measure_generation(model, tokenizer, input_ids, max_new_tokens=L)`
with `L` as the ceiling, so the model is cut off at exactly `L` tokens. Do
this for every `L` in the list and collect `(L, latency_s, energy_j, gpu_mem_mb)`.
Print a small table; a one-line comment noting whether latency scales roughly
linearly with `L` is enough (no need for a fitted line or a plot for this one,
though a plot is welcome if you want one; follow `experiments/plots.py`'s
style, e.g. `matplotlib` with `Agg` backend, if you add one).

### 2.4 `server/app.py` and `server/client.py`

This is the one part of the implementation that isn't "run a Python function
in a notebook cell." It is the actual client/server topology from Section 3
of the report, over real HTTP.

**`server/app.py`**: `create_app(model_name=None, defense=False) -> FastAPI`.

- Load the model once at import/startup time via
  `model_utils.load_model_and_tokenizer(model_name)`.
- Start **one** background worker thread that pulls jobs from a
  `queue.Queue()` and runs them one at a time. This single-worker design is
  the whole point: it's what makes an expensive request block everyone
  behind it, and it's the same design `experiments/exp_queue_dos.py` uses
  in-process. Look at that file's `_make_worker` for the exact pattern (a
  `Queue`, a `Thread` pulling `job = q.get()`, `None` as the stop sentinel).
  Your FastAPI handler just needs to enqueue a job and wait for its result;
  since FastAPI's handler runs in an async context but your worker thread is
  sync, the simplest approach is a per-request `queue.Queue()` of size 1
  that the worker puts the result into, and the handler blocks on `.get()` in
  a thread pool executor so it doesn't block the whole event loop.
- Route: `POST /generate`, body `{"prompt": str, "max_tokens": int}`,
  response `{"output": str, "out_tokens": int, "latency_s": float}`. This
  must match the report's Listing 1/2 exactly (same field names).
- `defense=True` should route the request through
  `defenses.guard.LayeredGuard` instead of calling `model_utils.generate`
  directly, once that exists (step 6). This flag is what lets
  `exp_defense_eval.py` compare "defense off" vs "defense on" over real HTTP,
  not just in-process. Until `guard.py` exists, `defense=True` can just raise
  `NotImplementedError` or fall back to the undefended path with a printed
  warning; don't block the rest of the server on it.

**`server/client.py`**: `send_request`, `attacker_blast`, `honest_latency`:
thin wrappers over `requests.post(url, json={...})` that time the round trip
client-side (`time.time()` before and after the call) and return a dict.
`attacker_blast` fires `n` sponge requests (sequential is fine to start;
threads or `concurrent.futures` if you want them genuinely concurrent; note
which one you did in your writeup, since it changes what the experiment
shows). `honest_latency` sends one honest request and returns the client-side
wall-clock latency. This is the number that matters for reproducing Table 3
over real HTTP, as opposed to Ahnaf's in-process version in `exp_queue_dos.py`.

**Running it on Kaggle:** start `uvicorn` in a background thread (or use
`nest_asyncio` plus `uvicorn.Server().serve()` in a notebook cell) bound to
`127.0.0.1:8000`, then use `server/client.py` from a later cell to hit it.
Don't try to run uvicorn as a blocking foreground call in a notebook cell; it
will never return control to the next cell.

**Test it yourself**: start the server, send one normal request with
`send_request`, and check the JSON keys match `output`/`out_tokens`/`latency_s`
exactly. Then send a couple of sponge requests followed by one honest request
via `attacker_blast` plus `honest_latency` and confirm the honest one is
visibly slower. That's your real-HTTP version of Ahnaf's Table 3.

### 2.5 `defenses/l1_output_cap.py`

`capped_generate(model, tokenizer, input_ids, max_new_tokens_cap, time_budget_s, eos_ids=None) -> (output_ids, n_new, hit_cap)`.

This wraps `model.generate(...)` (same call shape as
`common/model_utils.generate`) but adds a wall-clock cutoff on top of the
token cap. `transformers` lets you pass `stopping_criteria`; write a small
`StoppingCriteria` subclass that records `time.time()` at construction and
returns `True` once `time.time() - start > time_budget_s`. Pass
`max_new_tokens=max_new_tokens_cap` as well (belt and suspenders; the token
cap should trigger first in practice since it's deterministic, but the time
budget is the real safety net against a slow token). Return whether the cap
(either one) was hit as `hit_cap`, so callers can tell "reached the cap" apart
from "stopped naturally on EOS".

### 2.6 `defenses/l3_output_monitor.py`

`monitored_generate(model, tokenizer, input_ids, eos_ids=None, repeat_ngram=3, repeat_limit=20, max_new_tokens=None) -> (output_ids, n_new, killed)`.

Another `StoppingCriteria`-based wrapper: keep the last `repeat_ngram` tokens
generated in a small buffer and count how many times the exact same n-gram has
repeated; if it exceeds `repeat_limit`, stop and set `killed=True`. This is
what catches a sponge that loops on the same phrase (Tier 1's output-forcing
prompt tends to do this, which makes it a good test input). It should NOT
trigger on ordinary text, which rarely repeats a 3-gram 20 times; verify this
on both an honest prompt and one of your Tier-1 sponge outputs before
considering it done.

### 2.7 `defenses/l4_rate_limit.py`

`class RateLimiter`: `__init__(max_requests, window_s, max_output_tokens=None)`,
`allow(client_id, est_output_tokens=0) -> bool`, `record(client_id, output_tokens)`.

A plain per-client sliding-window or fixed-window counter (a
`dict[client_id -> list[timestamps]]`, pruning entries older than `window_s`,
is enough; no need for anything fancier). If `max_output_tokens` is set, also
track a rolling sum of output tokens per client per window and reject once
that budget is exceeded, regardless of request count. This is the
"cost-aware" variant the docstring mentions, and it's the one that actually
does something against a sponge. The plain request-count limiter should
*not* stop a single expensive request, and your `exp_defense_eval.py` writeup
should show that explicitly. That's the honest finding the report already
states in Section 8: rate limiting alone does not help, because a sponge
raises cost per request, not request count.

### 2.8 `defenses/l6_config_hygiene.py`

`sanitise_request(payload: dict) -> dict`: strip fields like `logprobs`,
`logit_bias`, and clamp an over-large `max_tokens` down to some sane ceiling
(e.g. the server's configured max) before the request reaches the model.

`contains_glitch_tokens(text, tokenizer) -> bool`: check whether encoding
`text` produces any token id from a small denylist of "glitch"/reserved
tokens, e.g. unused special tokens near the top of the vocabulary, or any id
you decide to treat as reserved for this project. You can keep the denylist
short and explicit (a handful of ids) rather than trying to discover real
glitch tokens experimentally; the point for this project is to show the
mechanism (an attacker who could see logprobs/logit_bias could use them to
speed up an Engorgio-style search, so hiding them raises the bar), not to ship
a production-grade glitch-token database.

### 2.9 `defenses/guard.py`

`class LayeredGuard`: `__init__(model, tokenizer, detector=None, **kwargs)`,
`handle(client_id, prompt) -> dict` with keys
`blocked, reason, out_tokens, latency_s, hit_cap`.

Wire the layers in this order (matches Figure 9 in the report):

```
prompt
  -> l6_config_hygiene.contains_glitch_tokens   -> blocked if True
  -> l2_input_validation.validate_input          -> blocked if not .ok   [Ahnaf's, ready]
  -> l5_latent_detector.LatentDetector.predict   -> blocked if predicted sponge   [Ahnaf's, ready; pass a fitted detector in via the `detector` argument]
  -> l4_rate_limit.RateLimiter.allow             -> blocked if False
  -> l1_output_cap.capped_generate plus l3_output_monitor.monitored_generate
       (run one wrapped generate call that respects both the token/time cap
        and the repetition kill; you can call l1's capped_generate and pass
        its stopping_criteria alongside l3's, or call them as two stacked
        StoppingCriteria in one generate call; either is fine, just be clear
        which you did)
  -> bounded response
```

`detector` is optional precisely because L5 needs to be `.fit()` on a labelled
set before it can `.predict()`. Construct and fit a `LatentDetector` once
(e.g. in `exp_defense_eval.py`) and pass it in, rather than fitting one fresh
per request.

`handle()` should record which layer blocked the request (if any) in
`reason`, and otherwise generate normally through L1+L3 and return the real
`out_tokens`/`latency_s`/`hit_cap` from that call.

### 2.10 `experiments/exp_cross_model.py`

`run_cross_model(sponge_prompt, natural_prompt, ceiling=256)`.

For each of `config.MODEL_NAME` (Qwen2.5-0.5B-Instruct) and
`config.ALT_MODEL_NAME` (Qwen3-0.6B), call
`model_utils.load_model_and_tokenizer(name, enable_thinking=False)` and
measure `natural_prompt` vs `sponge_prompt` with `metrics.measure_prompt`,
reporting the output-token and latency amplification for each model side by
side. `enable_thinking=False` matters for Qwen3 specifically: it has a
thinking mode that would otherwise inflate its own output length for reasons
unrelated to the sponge, muddying the comparison. Report both models' real
numbers; don't editorialize about which "should" be bigger. The report's
point is only that the lever still works on a newer model, not that it works
identically.

### 2.11 `experiments/exp_defense_eval.py`

`run_defense_eval(model, tokenizer, sponge_prompts, benign_prompts)`. This is
the capstone; it needs `guard.py` (step 2.9) and Ahnaf's `l2`/`l5` modules, so
do it last. Four things to measure and print, matching the report's framing in
Section 8:

1. **Baseline amplification** (defense off): reuse
   `exp_per_request_cost`-style measurement on `sponge_prompts` vs a natural
   baseline from `benign_prompts`.
2. **Defended amplification** (defense on): route the same `sponge_prompts`
   through a `LayeredGuard` and measure the same amplification. It should
   collapse toward 1x because L1's cap stops the crafted prompt from reaching
   the ceiling.
3. **Detector scores**: fit `l5_latent_detector.LatentDetector` on
   `benign_prompts` vs `sponge_prompts` (same call shape as
   `l5.LatentDetector(model, tokenizer).fit(benign, sponge)` in Ahnaf's test
   file) and report `.accuracy`/`.auc`; separately run
   `l2_input_validation.evaluate_validator` on the same sets and report its
   detection rate and false-positive rate.
4. **Honest-request cost**: confirm the guard adds only a small latency
   overhead to `benign_prompts` (the false-positive cost of having a defense
   at all). Measure a benign prompt's latency with the guard on vs off and
   report the difference.

Print all four as a short table/summary; a plot is optional (welcome if you
want one; you can add a new figure in `experiments/plots.py`, following the
existing colour scheme: `ATTACK = "#C0392B"`, `HONEST = "#1E8449"`).

---

## 3. Testing what you build

Ahnaf's `code/tests/test_ahnaf_parts.py` is a good template. Copy its style
(pure-logic checks first with no model, then model-dependent checks with the
real 0.5B model but tiny sizes) into a new `code/tests/test_dipit_parts.py`.
At minimum, before you consider a module done:

- `tier1_baselines`: print token counts for a plain string vs your abused
  version and check the ratio actually jumps (don't just eyeball the string).
- `exp_per_request_cost` / `exp_length_sweep`: run them once end-to-end on
  CPU with tiny ceilings (e.g. `ceiling=16`) just to confirm no crash and
  sane-looking numbers, before running the real thing on GPU.
- `server/app.py` plus `client.py`: start the server locally, hit `/generate`
  with a normal prompt, check the response JSON shape, then run a small
  sponge-then-honest sequence and confirm the honest latency visibly rises.
- `l1`/`l3`/`l4`/`l6`: unit-test each in isolation (e.g. does `l4`'s
  `RateLimiter.allow` return `False` after `max_requests` within `window_s`;
  does `l3`'s monitor actually kill a deliberately repetitive generation but
  NOT an ordinary one).
- `guard.py` / `exp_defense_eval`: run on a handful of benign plus sponge
  prompts on CPU first (small numbers, just to see the pipeline doesn't crash
  and the blocked/allowed decisions look sane) before trusting a full GPU run.

Run `python -m py_compile` (or just `python -c "import <module>"`) on
everything after each change. A broken import will silently break every other
module that imports yours.

---

## 4. Where your numbers go

Once you have real measured numbers from a GPU run (Kaggle T4 recommended;
see `code/README.md` for why), they replace/extend:

- Table 2 (per-request cost), from `exp_per_request_cost.py`
- Table 3 / the queue-DoS story: Ahnaf's in-process version already has real
  numbers; your `server` plus `client` version is the same story over real
  HTTP and is good evidence for the topology and packet sections specifically
- The cross-model note in Section 7, from `exp_cross_model.py`
- Section 8's "amplification drops toward 1x" claim, from
  `exp_defense_eval.py`

Report whatever you actually measure, even if it doesn't match the report's
placeholder numbers. Those were measured on Ahnaf's specific run and are
expected to differ a bit from yours (different random seed draws for Tier-2
prompts, different exact hardware). The point of the project is honest,
reproducible measurement, not hitting a specific number.
