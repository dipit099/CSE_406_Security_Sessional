# Findings: Project 37 — LLM Resource-Exhaustion (Sponge-Style) DoS

Short notes from reading the sources. Written to fix the scope and check the partner's guide before we design anything.

## 1. Is the partner's guide correct?

Mostly yes. The one claim I wanted to verify was: *does "sponge-style" mean exhausting resources with one crafted prompt, not a flood of prompts?* The Shumailov 2021 paper confirms this.

- A sponge example is "a single crafted input" designed to "cause inference to take as long as possible and consume as much energy as possible." The paper explicitly says "the attacks presented in this paper assume that a single sample is processed at a time." So the attack unit is one expensive request, not volume. The guide is right.
- Flooding, context-window overflow by volume, rate-limit abuse, and data poisoning are resource-exhaustion attacks but are **not** sponge-style. Out of scope for us. The guide draws this line correctly.

So we keep the guide's scope: one crafted input, per-query worst case.

## 2. What actually drives the cost (the crux)

An LLM serves a request in two phases: **prefill** (reads all input tokens, cost grows with input length) and **decode** (generates one token at a time, autoregressively). Decode dominates for chat models. Generation stops only when the model emits an **EOS** token or hits the **`max_new_tokens`** ceiling.

- Cost is driven by **output length**, not input length (LLMEffiChecker states this directly).
- Two inputs of the same character length can cost wildly different amounts. Same-length tokenizer abuse: `Athazagoraphobia` = 4 tokens, `Athazagoraphpbia` = 7 tokens, `A/h/z/g/r/p/p/i/` = 16 tokens (Sponge paper).
- The single strongest lever is therefore **making the model not stop**, i.e. suppressing EOS so decode runs to the high ceiling.

## 3. The three core papers (verified, read in full)

| Paper | Venue | Method | Headline numbers (from the papers) |
|---|---|---|---|
| **Sponge Examples**, Shumailov et al. | 2021 (arXiv 2006.03463) | Genetic algorithm (black-box) + L-BFGS (white-box, vision). Fitness = energy/latency. | Up to **~30×** energy/latency on language models. WSC 50-token white-box: **26.6× GPU energy, 20.6× GPU time**. Real Azure Translator: 1 ms → 6 s = **6000×**. Vision only 1–3%. Rate limiting is *not enough*; defense = profile + hard cut-off. |
| **LLMEffiChecker**, Feng et al. | ACM TOSEM 2024 | Perturb 1–3 tokens (char / token / structure level). White-box gradient + black-box causal. Objective decreases EOS prob. | Latency **+325% to +3244%**, energy **+344% to +3616%** from perturbing a single char/token. 63% of 20,543 real LLMs set `max_length` > 300. Defense = lightweight SVM on hidden-state latents. |
| **Engorgio**, Dong et al. | ICLR 2025 (arXiv 2412.19394) | Optimize a whole prompt from scratch via a proxy distribution; **EOS-escape loss** + self-mentor loss suppress EOS. | Outputs **2–13×** longer, reaching **>90%** of max length on 6 base models. Transfers black-box. A few attackers (e.g. 1/10, 5/100) throttle a real HF endpoint. |

Line of descent: Sponge (concept + GA) → LLMEffiChecker (output length is the lever, EOS is the switch) → Engorgio (optimize a prompt to hold EOS down). We build from these three.

## 4. OWASP mapping (both versions checked)

- **2023/24 — LLM04 Model Denial of Service**: lists "unusually resource-consuming" queries with "unusual orthography or sequences" (= tokenizer abuse), variable-length input flood, recursive context expansion. Prevention: input validation, cap resource use per request, rate limits, monitor utilization, strict input limits.
- **2025 — renamed LLM10 Unbounded Consumption**: broadened to also cover runaway cost ("Denial of Wallet") and model theft. Adds prevention items useful to us: **limit exposure of logits/logprobs**, **glitch-token filtering**, anomaly detection, graceful degradation. Our project sits in the DoS part of this.

## 5. Light literature check (2023–2026)

Did a short search as agreed. The space is active in 2025 (e.g. *LoopLLM: Transferable Energy-Latency Attacks via Repetitive Generation*, arXiv 2511.07876; over-generation DoS benchmarks). None of it displaces the three core papers or changes our design, so we cite the newest one only as evidence the threat is current and keep our build on Sponge + LLMEffiChecker + Engorgio.

## 6. Decisions this locks in

- **Scope**: single crafted input, per-query worst case. EOS suppression / output-length inflation is the main lever; tokenizer abuse is a secondary prefill lever.
- **Threat model**: interactive black-box (GA) as the honest reimplementation, plus a white-box EOS-suppression optimizer (Engorgio-style) as the advanced attack.
- **Honesty note for the report**: this is an *application-layer* attack. There is no custom Ethernet frame. The "packet we craft" is the HTTP JSON request body; the weapon is entirely in the prompt content and the `max_tokens` field.
- **Defense (for the 10% bonus)**: layered — output/compute cap (the real fix), input validation (token-to-char ratio + perplexity), output monitoring with early termination, rate limit + quotas (supporting only), plus a latent-space anomaly detector. Every layer measured before/after.
