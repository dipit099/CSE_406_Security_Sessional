"""
Live demonstration runner.

Drives the victim server through the story you present to your supervisor:

  1. PER-REQUEST COST: send a natural request, a tokenizer-abuse sponge, and a
     fluent output-forcing sponge. With defenses OFF the sponges balloon the
     output length / latency. Flip defenses ON and show they are blocked
     (tokenizer-abuse by L2) or capped (output-forcing by the compute cap).

  2. QUEUE STARVATION: fire k sponge requests plus one honest request at the
     single-worker server. With defenses OFF the honest user waits behind the
     sponges (large total latency). With defenses ON the sponges are blocked or
     capped, so the honest user is served promptly again.

Everything is measured live from the server's own responses (real numbers, no
leakage), printed as before/after tables, and written to CSV for the report.

Usage (server must already be running, e.g. via docker compose):
    python run_demo.py --url http://localhost:8000 --scenario both --k 3
"""

from __future__ import annotations

import argparse
import csv
import os
import threading
import time

from client import VictimClient
from demo_prompts import (DEFAULT_HONEST, DEFAULT_SPONGE, TOKENIZER_ABUSE)


def _write_csv(path, rows):
    if not rows:
        return path
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    fields = []
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print(f"[demo] wrote {path}")
    return path


def _hr():
    print("-" * 78)


# --------------------------------------------------------------------------
# Scenario 1: per-request cost
# --------------------------------------------------------------------------
def scenario_per_request(client, out_dir):
    cases = [
        ("natural", DEFAULT_HONEST),
        ("tokenizer_abuse", TOKENIZER_ABUSE[0]),
        ("output_forcing", DEFAULT_SPONGE),
    ]
    rows = []
    print("\n=== SCENARIO 1: per-request cost (natural vs sponges) ===")
    for defense in (False, True):
        client.set_defense(enabled=defense)
        state = "ON " if defense else "OFF"
        _hr()
        print(f"defenses {state} "
              f"{'|  kind            out_tokens   latency(s)   result'}")
        _hr()
        for kind, prompt in cases:
            r = client.generate(prompt)
            result = (f"BLOCKED by {r['stage']}" if r.get("blocked")
                      else f"generated (cap={r.get('cap_applied')})")
            print(f"defenses {state} |  {kind:<16} "
                  f"{r['out_tokens']:>8}   {r['total_latency_s']:>9}   {result}")
            rows.append({
                "scenario": "per_request", "defense": "on" if defense else "off",
                "kind": kind, "out_tokens": r["out_tokens"],
                "gen_latency_s": r.get("gen_latency_s"),
                "total_latency_s": r["total_latency_s"],
                "blocked": r.get("blocked"), "stage": r.get("stage") or "",
                "cap_applied": r.get("cap_applied") or "",
            })
    _write_csv(os.path.join(out_dir, "demo_per_request.csv"), rows)
    return rows


# --------------------------------------------------------------------------
# Scenario 2: queue starvation
# --------------------------------------------------------------------------
def _fire(client, prompt, holder, key):
    holder[key] = client.generate(prompt)


def scenario_queue(client, out_dir, k=3):
    rows = []
    print(f"\n=== SCENARIO 2: queue starvation (k={k} sponges ahead of 1 honest) ===")
    baseline = None
    for defense in (False, True):
        client.set_defense(enabled=defense)
        state = "ON " if defense else "OFF"
        holder = {}
        threads = []
        # Launch k sponges first, then the honest request a beat later, so the
        # honest request is genuinely queued behind them at the single worker.
        for i in range(k):
            t = threading.Thread(target=_fire,
                                 args=(client, DEFAULT_SPONGE, holder, f"sponge_{i}"))
            threads.append(t)
        honest_t = threading.Thread(target=_fire,
                                    args=(client, DEFAULT_HONEST, holder, "honest"))
        for t in threads:
            t.start()
        time.sleep(0.25)
        honest_t.start()
        for t in threads:
            t.join()
        honest_t.join()

        honest = holder["honest"]
        honest_lat = honest["total_latency_s"]
        if not defense:
            baseline = honest_lat
        slowdown = (honest_lat / baseline) if baseline else 1.0
        _hr()
        print(f"defenses {state} |  honest-user total latency = {honest_lat:>8}s "
              f"(slowdown vs idle-ish baseline: {slowdown:.1f}x)")
        rows.append({
            "scenario": "queue", "defense": "on" if defense else "off",
            "k_sponges": k, "honest_total_latency_s": honest_lat,
            "honest_blocked": honest.get("blocked"),
            "slowdown_vs_off_baseline": round(slowdown, 2),
        })
    _write_csv(os.path.join(out_dir, "demo_queue.csv"), rows)
    return rows


def main():
    ap = argparse.ArgumentParser(description="Live attack/defense demonstration")
    ap.add_argument("--url", default="http://localhost:8000")
    ap.add_argument("--scenario", choices=["per_request", "queue", "both"],
                    default="both")
    ap.add_argument("--k", type=int, default=3, help="sponges ahead in queue scenario")
    ap.add_argument("--out-dir", default="demo_results")
    args = ap.parse_args()

    client = VictimClient(args.url)
    h = client.health()
    print(f"[demo] server up: model={h.get('model')} chat={h.get('chat')}")

    if args.scenario in ("per_request", "both"):
        scenario_per_request(client, args.out_dir)
    if args.scenario in ("queue", "both"):
        scenario_queue(client, args.out_dir, k=args.k)

    # leave defenses ON at the end (tidy final state for the audience)
    client.set_defense(enabled=True)
    print("\n[demo] done. Final server defense state:",
          client.stats().get("defense"))


if __name__ == "__main__":
    main()
