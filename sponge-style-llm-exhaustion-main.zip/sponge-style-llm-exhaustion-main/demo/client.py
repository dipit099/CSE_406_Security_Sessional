"""
Client for the victim server. Standard-library only (urllib), so it runs
anywhere without extra installs. Usable as a library (imported by run_demo.py)
or as a small CLI for ad-hoc pokes during the demo.

CLI examples:
    python client.py --url http://localhost:8000 health
    python client.py generate --prompt "What is the capital of France?"
    python client.py defense --on --output-cap 32
    python client.py defense --off
"""

from __future__ import annotations

import argparse
import json
import urllib.request


class VictimClient:
    def __init__(self, url="http://localhost:8000", timeout=600):
        self.url = url.rstrip("/")
        self.timeout = timeout

    def _post(self, path, obj):
        data = json.dumps(obj).encode("utf-8")
        req = urllib.request.Request(
            self.url + path, data=data,
            headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            return json.loads(r.read().decode("utf-8"))

    def _get(self, path):
        with urllib.request.urlopen(self.url + path, timeout=self.timeout) as r:
            return json.loads(r.read().decode("utf-8"))

    def health(self):
        return self._get("/health")

    def stats(self):
        return self._get("/stats")

    def generate(self, prompt, max_new_tokens=None):
        body = {"prompt": prompt}
        if max_new_tokens is not None:
            body["max_new_tokens"] = max_new_tokens
        return self._post("/generate", body)

    def set_defense(self, **kwargs):
        return self._post("/admin/defense", kwargs)


def _main():
    ap = argparse.ArgumentParser(description="Victim server client")
    ap.add_argument("--url", default="http://localhost:8000")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("health")
    sub.add_parser("stats")

    g = sub.add_parser("generate")
    g.add_argument("--prompt", required=True)
    g.add_argument("--max-new-tokens", type=int, default=None)

    d = sub.add_parser("defense")
    d.add_argument("--on", action="store_true")
    d.add_argument("--off", action="store_true")
    d.add_argument("--output-cap", type=int, default=None)
    d.add_argument("--ceiling", type=int, default=None)
    d.add_argument("--l5", action="store_true", help="also enable the L5 detector")

    args = ap.parse_args()
    c = VictimClient(args.url)

    if args.cmd == "health":
        print(json.dumps(c.health(), indent=2))
    elif args.cmd == "stats":
        print(json.dumps(c.stats(), indent=2))
    elif args.cmd == "generate":
        print(json.dumps(c.generate(args.prompt, args.max_new_tokens), indent=2))
    elif args.cmd == "defense":
        kw = {}
        if args.on:
            kw["enabled"] = True
        if args.off:
            kw["enabled"] = False
        if args.output_cap is not None:
            kw["output_cap"] = args.output_cap
        if args.ceiling is not None:
            kw["ceiling"] = args.ceiling
        if args.l5:
            kw["use_l5"] = True
        print(json.dumps(c.set_defense(**kw), indent=2))


if __name__ == "__main__":
    _main()
