#!/usr/bin/env bash
# Deploy the victim-server demo to a Google Cloud VM, so the live demo runs in
# the cloud (zero load on your laptop) and your supervisor opens a URL to watch
# the dashboard update in real time.
#
# It uses the SAME Docker image as the local demo, built on the VM. Default is a
# CPU VM (simple and reliable). A GPU option is documented in demo/README.md.
#
# Prereqs (once):
#   gcloud auth login
#   gcloud config set project YOUR_PROJECT_ID
#
# Usage:
#   bash demo/deploy_gcp.sh up      # create VM, deploy, print the dashboard URL
#   bash demo/deploy_gcp.sh stop    # STOP the VM (pause compute billing; keeps data)
#   bash demo/deploy_gcp.sh start   # start it again; the server auto-restarts
#   bash demo/deploy_gcp.sh ip      # print the dashboard URL again
#   bash demo/deploy_gcp.sh logs    # tail the server logs on the VM
#   bash demo/deploy_gcp.sh down    # DELETE the VM and firewall rule (stop billing)
#
# Cheapest pattern: `up` once, then `stop` when you are done for the day and
# `start` before the next test/demo (you only pay compute while it is running;
# a stopped VM costs only its ~30GB disk, a few cents per day). `down` deletes
# everything and costs nothing after.
#
# Override defaults with env vars, e.g.:
#   ZONE=asia-south1-c DEMO_MODEL=Qwen/Qwen2.5-0.5B-Instruct bash demo/deploy_gcp.sh up
set -euo pipefail

# GPU=1 provisions a T4 GPU VM (needs GPU quota + a PAID account; see README).
# Default (GPU=0) is a reliable CPU VM.
GPU="${GPU:-0}"
VM="${VM:-sponge-demo}"
ZONE="${ZONE:-us-central1-a}"
PORT=8000
TAG="sponge-demo"

if [ "$GPU" = "1" ]; then
  MACHINE="${MACHINE:-n1-standard-4}"
  DEMO_MODEL="${DEMO_MODEL:-Qwen/Qwen2.5-0.5B-Instruct}"   # GPU is fast -> instruct
  COMPOSE="demo/docker-compose.gpu.yml"
else
  MACHINE="${MACHINE:-e2-standard-4}"        # 4 vCPU / 16 GB RAM, CPU-only
  DEMO_MODEL="${DEMO_MODEL:-distilgpt2}"      # fast on CPU
  COMPOSE="demo/docker-compose.yml"
fi
# Restrict who can reach the demo port. Default is your current public IP only.
SRC_RANGE="${SRC_RANGE:-$(curl -s https://api.ipify.org 2>/dev/null)/32}"

here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"   # project root

cmd="${1:-up}"

case "$cmd" in
up)
  echo "[gcp] creating VM $VM in $ZONE ($MACHINE) GPU=$GPU ..."
  if [ "$GPU" = "1" ]; then
    # Deep Learning VM image ships NVIDIA drivers + Docker + nvidia container
    # runtime; the metadata flag auto-installs the driver on first boot.
    gcloud compute instances create "$VM" \
      --zone="$ZONE" --machine-type="$MACHINE" \
      --accelerator="type=nvidia-tesla-t4,count=1" --maintenance-policy=TERMINATE \
      --image-family=common-cu123-debian-11 --image-project=deeplearning-platform-release \
      --metadata="install-nvidia-driver=True" \
      --boot-disk-size=60GB --tags="$TAG"
  else
    gcloud compute instances create "$VM" \
      --zone="$ZONE" --machine-type="$MACHINE" \
      --image-family=ubuntu-2204-lts --image-project=ubuntu-os-cloud \
      --boot-disk-size=30GB --tags="$TAG"
  fi

  echo "[gcp] opening firewall for tcp:$PORT from $SRC_RANGE ..."
  gcloud compute firewall-rules create "allow-$TAG-$PORT" \
    --allow "tcp:$PORT" --target-tags="$TAG" \
    --source-ranges="$SRC_RANGE" 2>/dev/null || \
    echo "[gcp] firewall rule already exists; leaving it."

  echo "[gcp] waiting for SSH (GPU images take longer on first boot)..."
  until gcloud compute ssh "$VM" --zone="$ZONE" --command "true" 2>/dev/null; do
    sleep 5
  done

  if [ "$GPU" = "1" ]; then
    echo "[gcp] waiting for the NVIDIA driver to finish installing..."
    until gcloud compute ssh "$VM" --zone="$ZONE" --command "nvidia-smi" 2>/dev/null; do
      sleep 10
    done
  else
    echo "[gcp] installing Docker on the VM..."
    gcloud compute ssh "$VM" --zone="$ZONE" --command \
      "sudo apt-get update -qq && sudo apt-get install -y -qq docker.io docker-compose-v2 && sudo usermod -aG docker \$USER"
  fi

  echo "[gcp] packaging + copying code/ and demo/ to the VM..."
  # Use a single tarball rather than scp --recurse: on Windows the bundled
  # pscp cannot handle multiple sources or a '~' destination directory.
  tar czf "$here/.sponge_deploy.tgz" -C "$here" code demo
  gcloud compute scp --zone="$ZONE" \
    "$here/.sponge_deploy.tgz" "$VM:/tmp/sponge.tgz"
  gcloud compute ssh "$VM" --zone="$ZONE" --command \
    "rm -rf ~/sponge && mkdir -p ~/sponge && tar xzf /tmp/sponge.tgz -C ~/sponge"
  rm -f "$here/.sponge_deploy.tgz"

  echo "[gcp] building + starting the victim server (model: $DEMO_MODEL)..."
  gcloud compute ssh "$VM" --zone="$ZONE" --command \
    "cd ~/sponge && DEMO_MODEL='$DEMO_MODEL' sudo -E docker compose -f $COMPOSE up -d --build"

  ip="$(gcloud compute instances describe "$VM" --zone="$ZONE" \
        --format='get(networkInterfaces[0].accessConfigs[0].natIP)')"
  echo ""
  echo "==================================================================="
  echo " Dashboard:  http://$ip:$PORT/"
  echo " Health:     http://$ip:$PORT/health"
  echo " Run the scripted scenario from your laptop:"
  echo "   python demo/run_demo.py --url http://$ip:$PORT --scenario both --k 3"
  echo " When finished:  bash demo/deploy_gcp.sh down   (deletes the VM)"
  echo "==================================================================="
  ;;

ip)
  ip="$(gcloud compute instances describe "$VM" --zone="$ZONE" \
        --format='get(networkInterfaces[0].accessConfigs[0].natIP)')"
  echo "http://$ip:$PORT/"
  ;;

stop)
  echo "[gcp] stopping VM $VM (compute billing pauses; data is kept)..."
  gcloud compute instances stop "$VM" --zone="$ZONE"
  echo "[gcp] stopped. Run 'start' before the next demo."
  ;;

start)
  echo "[gcp] starting VM $VM ..."
  gcloud compute instances start "$VM" --zone="$ZONE"
  # the container has restart:unless-stopped, so it comes back on boot; give it
  # a moment to reload the model.
  ip="$(gcloud compute instances describe "$VM" --zone="$ZONE" \
        --format='get(networkInterfaces[0].accessConfigs[0].natIP)')"
  echo "[gcp] started. NOTE: the external IP may have changed."
  echo " Dashboard (wait ~30-60s for the model to reload): http://$ip:$PORT/"
  echo " NOTE: if the firewall rule was pinned to your old IP, update it:"
  echo "   gcloud compute firewall-rules update allow-$TAG-$PORT --source-ranges=\$(curl -s https://api.ipify.org)/32"
  ;;

logs)
  gcloud compute ssh "$VM" --zone="$ZONE" --command \
    "cd ~/sponge && sudo docker compose -f $COMPOSE logs --tail=40 victim"
  ;;

down)
  echo "[gcp] deleting VM $VM and firewall rule (this stops billing)..."
  gcloud compute instances delete "$VM" --zone="$ZONE" --quiet || true
  gcloud compute firewall-rules delete "allow-$TAG-$PORT" --quiet || true
  echo "[gcp] done."
  ;;

*)
  echo "usage: bash demo/deploy_gcp.sh {up|stop|start|ip|logs|down}"; exit 1;;
esac
