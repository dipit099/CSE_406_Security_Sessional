"""
Victim LLM server for the live demonstration.

This is the "system" you show your supervisor: a small LLM served behind a
SINGLE worker with a FIFO queue, exactly like the minimal single-worker
deployment in the report's topology. An attacker hits it with sponge prompts;
you observe the per-request cost and the queue starvation of honest users; then
you flip the defenses ON, layer by layer, and show the same attacks mitigated.

Design choices (deliberate, for a robust live demo):
  * Pure standard-library HTTP server (http.server.ThreadingHTTPServer) so there
    are NO extra web dependencies to fail on stage; only torch + transformers,
    which the project already needs.
  * ThreadingHTTPServer accepts many concurrent client connections, but a
    single worker thread drains one FIFO queue and runs generation one request
    at a time. That is what makes queue starvation real and demonstrable.
  * ALL SIX defense layers from the report (Figure 9) are wired in and each is
    TOGGLEABLE AT RUNTIME via POST /admin/defense, so you can flip any one live
    and watch its specific effect. They reuse the project's real modules:
        L1  output/compute cap  (defenses/l1_output_cap.TimeBudgetCriteria)
            -- clamp max_new_tokens AND a wall-clock time budget.
        L2  input validation    (defenses/l2_input_validation.py)
            -- reject the tokenizer-abuse fingerprint before any generation.
        L3  output monitor      (defenses/l3_output_monitor.RepeatMonitorCriteria)
            -- kill a generation stuck in a repeated n-gram loop.
        L4  rate limit + quota  (defenses/l4_rate_limit.RateLimiter)
            -- per-client request-count and output-token budget.
        L5  latent detector     (defenses/l5_latent_detector.py)
            -- flag fluent/crafted sponges from the hidden state.
        L6  config hygiene      (defenses/l6_config_hygiene.py)
            -- filter reserved/glitch control tokens in the raw input.

Endpoints:
  GET  /               -> the live dashboard (dashboard.html)
  GET  /health         -> {"ok": true, ...}
  GET  /stats,/events  -> counters + current per-layer defense config + log
  POST /generate  {prompt, kind, max_new_tokens?} -> one request through the queue
  POST /admin/defense {use_l1..use_l6, output_cap, ...} -> flip layers at runtime
  POST /admin/model {key}  -> swap the served model (single-model demo ignores it)
"""

from __future__ import annotations

import json
import os
import queue
import sys
import threading
import time
import uuid
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# ---- local-only torchvision workaround (harmless; we never use torchvision) --
# Some local transformers installs fail to import a model class because of a
# torchvision import bug. Disabling torchvision (which this project never uses)
# before transformers loads avoids it. This is a no-op where torchvision is fine
# (e.g. Kaggle, the Docker image), so it is safe to keep in.
try:
    import transformers.utils.import_utils as _iu
    _iu._torchvision_available = False
    for _m in list(sys.modules):
        if "torchvision" in _m:
            del sys.modules[_m]
except Exception:
    pass

import torch  # noqa: E402
from transformers import StoppingCriteria, StoppingCriteriaList  # noqa: E402


# --------------------------------------------------------------------------
# Make the code/ package importable (works both locally and in the container).
# --------------------------------------------------------------------------
def _add_code_to_path():
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(here, "..", "code"),   # repo layout: demo/ next to code/
        os.path.join(here, "code"),         # container: code/ copied under app
        "/app/code",
        here,
    ]
    for c in candidates:
        c = os.path.abspath(c)
        if os.path.isfile(os.path.join(c, "common", "config.py")):
            sys.path.insert(0, c)
            return c
    raise RuntimeError("could not locate the code/ package for imports")


CODE_DIR = _add_code_to_path()

from common import model_utils, config                    # noqa: E402
from defenses import l2_input_validation as l2             # noqa: E402  (L2)
from defenses import l6_config_hygiene as l6               # noqa: E402  (L6)
from defenses import l4_rate_limit as l4mod                # noqa: E402  (L4)
from defenses.l1_output_cap import TimeBudgetCriteria      # noqa: E402  (L1)
from defenses.l3_output_monitor import RepeatMonitorCriteria  # noqa: E402 (L3)


# --------------------------------------------------------------------------
# Configuration (env-driven, with live-overridable defense state)
# --------------------------------------------------------------------------
def _int_env(name, default):
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _float_env(name, default):
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _bool_env(name, default):
    return os.environ.get(name, default).lower() in ("1", "on", "true")


def _pick_device():
    """
    Choose the torch device for the demo. Default is None (let the model loader
    pick, which is CPU on a Mac and CUDA on a GPU box), so the reliable CPU path
    is untouched. Set DEMO_DEVICE=mps to run on Apple Silicon's GPU (Metal), or
    DEMO_DEVICE=cpu/cuda to force one. MPS falls back to CPU with a warning if it
    is not actually available, and enables PyTorch's op-level CPU fallback so an
    op Metal does not implement cannot crash the demo.
    """
    want = os.environ.get("DEMO_DEVICE", "").strip().lower()
    if want == "mps":
        try:
            if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
                print("[server] DEMO_DEVICE=mps: using Apple Silicon GPU (Metal)",
                      flush=True)
                return "mps"
            print("[server] DEMO_DEVICE=mps requested but MPS is unavailable; "
                  "falling back to CPU.", flush=True)
        except Exception as e:
            print(f"[server] MPS check failed ({e}); using CPU.", flush=True)
        return None
    if want in ("cpu", "cuda"):
        return want
    return None


class DefenseState:
    """
    Mutable defense configuration with an independent switch for EACH of the six
    report layers, so the demo can toggle any one and watch its individual
    effect. When a layer is off it simply does not apply; the cap falls back to
    the (large) ceiling so an undefended sponge can show its full cost.
    `enabled` is derived (any switch on) for the badge.
    """

    def __init__(self, default_ceiling=32768):
        master = _bool_env("DEMO_DEFENSE", "off")
        # L1 output/compute cap (token cap + time budget)
        self.use_l1 = _bool_env("DEMO_USE_L1", "on" if master else "off")
        self.output_cap = _int_env("DEMO_OUTPUT_CAP", 256)
        self.time_budget_s = _float_env("DEMO_TIME_BUDGET_S", 60.0)
        # The UNDEFENDED ceiling is the model's real context window (passed in as
        # default_ceiling and read from the model config), NOT an arbitrary small
        # number. So an undefended sponge runs the model all the way to its
        # architectural limit, which is what genuinely overloads it. Override
        # with DEMO_CEILING only to bound a live session's wall-clock time.
        self.ceiling = _int_env("DEMO_CEILING", default_ceiling)
        # L2 input validation
        self.use_l2 = _bool_env("DEMO_USE_L2", "on" if master else "off")
        # L3 output monitor (repeated n-gram kill)
        self.use_l3 = _bool_env("DEMO_USE_L3", "off")
        self.repeat_ngram = _int_env("DEMO_REPEAT_NGRAM", 3)
        self.repeat_limit = _int_env("DEMO_REPEAT_LIMIT", 20)
        # L4 rate limit + quota
        self.use_l4 = _bool_env("DEMO_USE_L4", "off")
        self.l4_max_requests = _int_env("DEMO_L4_MAX_REQUESTS", 5)
        self.l4_window_s = _float_env("DEMO_L4_WINDOW_S", 60.0)
        # None = no token budget (request-count only); set to enable cost quota
        _q = os.environ.get("DEMO_L4_MAX_OUTPUT_TOKENS", "")
        self.l4_max_output_tokens = int(_q) if _q.isdigit() else None
        # L5 latent detector. Operating threshold 0.6 (not the bare 0.5): the
        # fitted scores separate cleanly into a benign cluster (<=0.52) and a
        # sponge cluster (>=0.70), so 0.6 sits in that gap and removes a lone
        # borderline false positive on detailed-but-benign requests without
        # letting any sponge through. Configurable via DEMO_L5_THRESHOLD.
        self.use_l5 = _bool_env("DEMO_USE_L5", "off")
        self.l5_threshold = _float_env("DEMO_L5_THRESHOLD", 0.6)
        # L6 config hygiene / glitch-token filter
        self.use_l6 = _bool_env("DEMO_USE_L6", "off")

    @property
    def enabled(self):
        return (self.use_l1 or self.use_l2 or self.use_l3 or self.use_l4
                or self.use_l5 or self.use_l6)

    def as_dict(self):
        return {
            "enabled": self.enabled,
            "use_l1": self.use_l1, "use_l2": self.use_l2, "use_l3": self.use_l3,
            "use_l4": self.use_l4, "use_l5": self.use_l5, "use_l6": self.use_l6,
            "output_cap": self.output_cap, "time_budget_s": self.time_budget_s,
            "ceiling": self.ceiling,
            "repeat_ngram": self.repeat_ngram, "repeat_limit": self.repeat_limit,
            "l4_max_requests": self.l4_max_requests,
            "l4_window_s": self.l4_window_s,
            "l4_max_output_tokens": self.l4_max_output_tokens,
            "l5_threshold": self.l5_threshold,
        }


class _ProgressStop(StoppingCriteria):
    """
    Runs on every generated token: publishes live progress (token count, KV-cache
    size, context percentage, a rolling text preview) into the service's `live`
    map so the dashboard can WATCH an undefended sponge climb toward the context
    window in real time, and stops generation when the client presses STOP.
    """

    def __init__(self, service, jid, prompt_len, stop_event, decode_every=40):
        self.s = service
        self.jid = jid
        self.pl = int(prompt_len)
        self.stop = stop_event
        self.de = decode_every

    def __call__(self, input_ids, scores=None, **kwargs):
        seq = int(input_ids.shape[1])
        n = seq - self.pl
        upd = {
            "out_tokens": n,
            "kv_cache_mb": self.s._kv_cache_mb(seq),
            "pct": round(100.0 * seq / self.s.context_window, 1)
                   if self.s.context_window else 0.0,
        }
        gm = self.s._gpu_mem_mb()
        if gm is not None:
            upd["gpu_mem_mb"] = gm
        if n > 0 and (n % self.de == 0):
            try:
                upd["text"] = self.s.tokenizer.decode(
                    input_ids[0, self.pl:].tolist(), skip_special_tokens=True)[-800:]
            except Exception:
                pass
        with self.s.lock:
            live = self.s.live.get(self.jid)
            if live is not None and not live.get("done"):
                live.update(upd)
        done = bool(self.stop.is_set())
        return torch.full((input_ids.shape[0],), done, dtype=torch.bool,
                          device=input_ids.device)


# --------------------------------------------------------------------------
# The single-worker model service
# --------------------------------------------------------------------------
class ModelService:
    def __init__(self):
        self.model_name = os.environ.get("DEMO_MODEL", "Qwen/Qwen2.5-0.5B-Instruct")
        self.device_pref = _pick_device()
        print(f"[server] loading model: {self.model_name} (this may download)...",
              flush=True)
        config.set_seed()
        self.model, self.tokenizer = model_utils.load_model_and_tokenizer(
            model_name=self.model_name, device=self.device_pref)
        self.device_str = str(next(self.model.parameters()).device)
        print(f"[server] model is on device: {self.device_str}", flush=True)
        self.eos_ids = model_utils.get_eos_ids(self.tokenizer, self.model)
        self.model_key = self._key_for_name(self.model_name)
        # Chat vs raw-completion mode. Prefer the registry's explicit `chat` flag
        # over has_chat_template, because some BASE models (e.g. Qwen2.5-0.5B)
        # ship a chat template yet were never instruction-tuned: feeding them the
        # template makes them degenerate into repetition loops, whereas raw text
        # completion (chat=False) is the paper-faithful way to attack a base
        # model and produces the clean "no EOS discipline" babble. Custom models
        # not in the registry fall back to has_chat_template.
        self.is_chat = self._chat_flag(self.model_key, self.model)
        # The model's REAL context window (input + output token budget). This is
        # the genuine architectural ceiling the attack drives the model toward,
        # read from the model config, not a hand-picked number.
        self.context_window = int(getattr(self.model.config,
                                          "max_position_embeddings", 32768))
        print(f"[server] model context window (max_position_embeddings): "
              f"{self.context_window} tokens", flush=True)
        self.model_options = self._build_model_options()
        self.defense = DefenseState(default_ceiling=self.context_window)
        self.detector = None
        self.rate_limiter = None
        self._rebuild_rate_limiter()
        if self.defense.use_l5:
            self._fit_detector()

        self.q: "queue.Queue" = queue.Queue()
        self.results = {}
        self.job_events = {}            # jid -> threading.Event (worker signalling)
        self.live = {}                  # jid -> live progress dict (for streaming)
        self.stop_events = {}           # jid -> threading.Event (STOP button)
        self.log = deque(maxlen=60)     # rolling request log for the dashboard
        self.lock = threading.Lock()
        self.stats = {"requests": 0, "blocked": 0, "generated": 0, "killed": 0}
        self.worker = threading.Thread(target=self._worker_loop, daemon=True)
        self.worker.start()
        print(f"[server] ready. chat={self.is_chat} eos={self.eos_ids} "
              f"defense={self.defense.as_dict()}", flush=True)

    @staticmethod
    def _key_for_name(name):
        for k, v in config.MODELS.items():
            if v["name"] == name:
                return k
        return "(custom)"

    @staticmethod
    def _chat_flag(key, model):
        """Chat-mode for a served model: the registry's explicit `chat` flag when
        the model is known (so base models with a stray chat template are still
        driven as raw-text completers), else fall back to has_chat_template."""
        spec = config.MODELS.get(key)
        if spec is not None and "chat" in spec:
            return bool(spec["chat"])
        return getattr(model, "_is_chat", False)

    def _build_model_options(self):
        opts = []
        for k in config.DASHBOARD_MODEL_KEYS:
            spec = config.MODELS.get(k)
            if spec:
                opts.append({"key": k, "name": spec["name"], "chat": spec["chat"]})
        if all(o["key"] != self.model_key for o in opts):
            opts.insert(0, {"key": self.model_key, "name": self.model_name,
                            "chat": self.is_chat})
        return opts

    def _rebuild_rate_limiter(self):
        """(Re)build L4's limiter from the current params; resets its window."""
        d = self.defense
        self.rate_limiter = l4mod.RateLimiter(
            d.l4_max_requests, d.l4_window_s, d.l4_max_output_tokens)

    def _do_switch(self, key):
        spec = config.MODELS.get(key)
        if spec is None:
            return {"ok": False, "error": f"unknown model key: {key}"}
        try:
            print(f"[server] switching model -> {spec['name']} ...", flush=True)
            config.set_seed()
            new_model, new_tok = model_utils.load_model_and_tokenizer(
                model_name=spec["name"], device=self.device_pref)
            old = self.model
            self.model = new_model
            self.tokenizer = new_tok
            self.device_str = str(next(new_model.parameters()).device)
            self.eos_ids = model_utils.get_eos_ids(new_tok, new_model)
            self.model_name = spec["name"]
            self.model_key = key
            self.is_chat = self._chat_flag(key, new_model)
            # adopt the new model's real context window; if the ceiling was left
            # at the previous model's full window, follow it to the new one.
            old_ctx = self.context_window
            self.context_window = int(getattr(new_model.config,
                                              "max_position_embeddings", 32768))
            if self.defense.ceiling == old_ctx:
                self.defense.ceiling = self.context_window
            self.detector = None            # L5 is model-specific; drop it
            del old
            import gc
            gc.collect()
            try:
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            except Exception:
                pass
            if self.defense.use_l5:
                self._fit_detector()
            print(f"[server] now serving {self.model_name} (chat={self.is_chat})",
                  flush=True)
            return {"ok": True, "model": self.model_name, "model_key": key,
                    "chat": self.is_chat}
        except Exception as e:
            print(f"[server] model switch FAILED ({e}); keeping {self.model_name}",
                  flush=True)
            return {"ok": False, "error": str(e), "model": self.model_name}

    def handle_switch(self, key):
        ev = threading.Event()
        holder = {}
        self.q.put(("__SWITCH__", key, ev, holder))
        ev.wait()
        return holder

    def _fit_detector(self):
        """Fit the L5 latent detector at startup on the demo benign/sponge sets."""
        try:
            from defenses import l5_latent_detector as l5
            from demo_prompts import BENIGN, SPONGE   # local module
            print("[server] fitting L5 latent detector...", flush=True)
            det = l5.LatentDetector(self.model, self.tokenizer)
            det.fit(BENIGN, SPONGE, n_splits=3)
            self.detector = det
            print("[server] L5 detector ready.", flush=True)
        except Exception as e:
            print(f"[server] L5 detector unavailable ({e}); continuing without it.",
                  flush=True)
            self.detector = None

    # -- defense checks (pre-generation): L6 -> L2 -> L5 -> L4 ---------------
    def _defense_reject(self, prompt, client_id):
        """Return (rejected, stage, reason) applying each ENABLED pre-gen layer."""
        d = self.defense
        # L6: reserved / control ("glitch") tokens in the raw input.
        if d.use_l6 and l6.contains_glitch_tokens(prompt, self.tokenizer):
            return True, "L6", "reserved/control (glitch) tokens in input"
        # L2: tokenizer-abuse fingerprint / over-long input.
        if d.use_l2:
            res = l2.validate_input(prompt, self.tokenizer)
            if not res.ok:
                return True, "L2", "; ".join(res.reasons)
        # L5: latent sponge signature (only if a fitted detector exists).
        if d.use_l5 and self.detector is not None:
            try:
                p = float(self.detector.predict_proba([prompt])[0])
                if p >= d.l5_threshold:
                    return True, "L5", (f"latent sponge score {p:.2f} >= "
                                        f"{d.l5_threshold:.2f}")
            except Exception:
                pass
        # L4: per-client rate / quota. Estimate cost as the effective cap.
        if d.use_l4:
            est = d.output_cap if d.use_l1 else d.ceiling
            if not self.rate_limiter.allow(client_id, est_output_tokens=est):
                return True, "L4", "rate/quota limit exceeded"
        return False, None, None

    def _effective_cap(self, requested):
        d = self.defense
        if d.use_l1:
            # L1 defense caps hard, regardless of what the client asked for.
            return d.output_cap if requested is None \
                else min(int(requested), d.output_cap)
        # Undefended: honour the client's requested max (the dashboard "run to"
        # field), else fall back to the configured ceiling. The real
        # context-window bound is applied by the caller.
        return int(requested) if requested is not None else d.ceiling

    # -- L1 (time budget) + L3 (repeat monitor) live during generation ------
    @torch.no_grad()
    def _guarded_generate(self, input_ids, cap, jid=None, stop_event=None):
        d = self.defense
        device = next(self.model.parameters()).device
        if input_ids.dim() == 1:
            input_ids = input_ids.unsqueeze(0)
        input_ids = input_ids.to(device)
        prompt_len = input_ids.shape[1]
        attn = torch.ones_like(input_ids)

        crits = []
        time_crit = monitor = None
        if d.use_l1:                       # L1's wall-clock safety net
            time_crit = TimeBudgetCriteria(d.time_budget_s)
            crits.append(time_crit)
        if d.use_l3:                       # L3's repeated-n-gram kill switch
            monitor = RepeatMonitorCriteria(prompt_len, d.repeat_ngram,
                                            d.repeat_limit)
            crits.append(monitor)
        # live progress + STOP button (always on when a job id is supplied)
        if jid is not None and stop_event is not None:
            crits.append(_ProgressStop(self, jid, prompt_len, stop_event))

        kwargs = dict(attention_mask=attn, max_new_tokens=cap, do_sample=False,
                      pad_token_id=self.tokenizer.pad_token_id,
                      eos_token_id=self.eos_ids)
        if crits:
            kwargs["stopping_criteria"] = StoppingCriteriaList(crits)

        t0 = time.time()
        out = self.model.generate(input_ids, **kwargs)
        latency = time.time() - t0
        n_new = int(out.shape[1] - prompt_len)
        killed = bool(monitor.killed) if monitor is not None else False
        time_fired = bool(time_crit.fired) if time_crit is not None else False
        stopped_by_user = bool(stop_event.is_set()) if stop_event is not None else False
        hit_cap = ((n_new >= cap) or time_fired) and not stopped_by_user
        last_token = int(out[0, -1]) if n_new > 0 else -1
        stopped_on_eos = (last_token in set(self.eos_ids)) and not time_fired \
            and not killed and not stopped_by_user
        # Decode the generation the model actually produced, so the demo can show
        # what the sponge made the model babble (truncated for display). .tolist()
        # keeps this correct on any device (CPU / CUDA / MPS).
        out_text = self.tokenizer.decode(
            out[0, prompt_len:].tolist(), skip_special_tokens=True)
        return {"n_new": n_new, "hit_cap": hit_cap, "killed": killed,
                "time_fired": time_fired, "latency": latency,
                "stopped_on_eos": stopped_on_eos, "stopped_by_user": stopped_by_user,
                "out_text": out_text}

    def _kv_cache_mb(self, seq_len):
        """
        Analytic size of the KV cache the model holds for a sequence of
        `seq_len` tokens, the memory the attack inflates. Real formula from the
        model config (2 tensors K+V, per layer, per KV head): honest computed
        number, not a live VRAM read (the demo runs on CPU).
        """
        cfg = self.model.config
        layers = getattr(cfg, "num_hidden_layers", 0)
        n_heads = getattr(cfg, "num_attention_heads", 1)
        kv_heads = getattr(cfg, "num_key_value_heads", n_heads)
        hidden = getattr(cfg, "hidden_size", n_heads)
        head_dim = getattr(cfg, "head_dim", hidden // n_heads if n_heads else 0)
        try:
            bytes_per = torch.finfo(next(self.model.parameters()).dtype).bits // 8
        except Exception:
            bytes_per = 4
        total = 2 * layers * kv_heads * head_dim * seq_len * bytes_per
        return round(total / (1024 * 1024), 2)

    def _gpu_mem_mb(self):
        """Real GPU memory the model is holding, when on a GPU. On Apple Silicon
        (MPS) this is unified memory the Metal allocator is using; on CUDA it is
        device memory. Returns None on CPU (there is no separate GPU memory to
        read there, so the demo shows the analytic KV-cache size instead)."""
        try:
            dev = getattr(self, "device_str", "cpu")
            if dev.startswith("mps"):
                return round(torch.mps.current_allocated_memory() / (1024 * 1024), 1)
            if dev.startswith("cuda"):
                return round(torch.cuda.memory_allocated() / (1024 * 1024), 1)
        except Exception:
            pass
        return None

    # -- worker: one generation at a time -----------------------------------
    def _worker_loop(self):
        while True:
            job = self.q.get()
            if job is None:
                self.q.task_done()
                break
            if job[0] == "__SWITCH__":
                _, key, ev, holder = job
                holder.update(self._do_switch(key))
                ev.set()
                self.q.task_done()
                continue
            jid, input_ids, cap, enq_time, stop_event, ctx = job
            dequeue_time = time.time()
            try:
                g = self._guarded_generate(input_ids, cap, jid, stop_event)
            except Exception as e:
                g = {"n_new": -1, "hit_cap": False, "killed": False,
                     "time_fired": False, "latency": 0.0, "stopped_on_eos": False,
                     "stopped_by_user": False, "out_text": f"[error: {e}]"}
                print(f"[server] generation error: {e}", flush=True)
            self._finalize(jid, ctx, g, enq_time, dequeue_time, cap)
            with self.lock:
                ev = self.job_events.get(jid)
                self.stop_events.pop(jid, None)
            if ev is not None:
                ev.set()
            self.q.task_done()

    def _finalize(self, jid, ctx, g, enq_time, dequeue_time, cap):
        """Assemble the full result dict, record it, and mark the live job done."""
        out_tokens = int(g["n_new"])
        prefill = ctx["prompt_len"]
        total = prefill + max(out_tokens, 0)
        if self.defense.use_l4:
            self.rate_limiter.record(ctx["client_id"], out_tokens)
        result = {
            "blocked": False,
            "out_tokens": out_tokens,
            "gen_latency_s": round(g["latency"], 3),
            "queue_wait_s": round(dequeue_time - enq_time, 3),
            "total_latency_s": round(time.time() - enq_time, 3),
            "hit_cap": g["hit_cap"], "killed": g["killed"],
            "time_fired": g["time_fired"], "stopped_on_eos": g["stopped_on_eos"],
            "stopped_by_user": g.get("stopped_by_user", False),
            "gen_tok_per_s": round(out_tokens / g["latency"], 1)
                             if g["latency"] > 0 and out_tokens > 0 else 0.0,
            "output_text": g["out_text"][:800],
            "cap_applied": cap,
            "capped": bool(self.defense.use_l1 and g["hit_cap"]),
            "prefill_tokens": prefill,
            "total_tokens": total,
            "pct_of_ceiling": round(100.0 * total / self.context_window, 1)
                              if self.context_window else 0.0,
            "context_window": self.context_window,
            "kv_cache_mb": self._kv_cache_mb(total),
            "gpu_mem_mb": self._gpu_mem_mb(),
            "device": self.device_str,
            "defense": self.defense.as_dict(),
        }
        result.update(ctx["input_meta"])
        with self.lock:
            self.results[jid] = result
            self.stats["generated"] += 1
            if g["killed"]:
                self.stats["killed"] += 1
            live = self.live.get(jid)
            if live is not None:
                live["done"] = True
                live["result"] = result
                live["out_tokens"] = out_tokens
        self._record(ctx["kind"], ctx["prompt"], result)
        return result

    def _record(self, kind, prompt, result):
        with self.lock:
            self.log.append({
                "time": time.strftime("%H:%M:%S"),
                "kind": kind,
                "preview": (prompt[:80] + ("..." if len(prompt) > 80 else "")),
                "out_tokens": result.get("out_tokens", 0),
                "total_latency_s": result.get("total_latency_s", 0.0),
                "blocked": result.get("blocked", False),
                "stage": result.get("stage") or "",
                "capped": result.get("capped", False),
                "killed": result.get("killed", False),
                "stopped_on_eos": result.get("stopped_on_eos", False),
                "input_tokens_per_char": result.get("input_tokens_per_char", 0.0),
                "pct_of_ceiling": result.get("pct_of_ceiling", 0.0),
                "defense_enabled": self.defense.enabled,
            })

    # -- request lifecycle --------------------------------------------------
    def _enqueue(self, prompt, requested_max, kind, client_id):
        """Run the pre-generation defenses; if the request survives, queue it for
        the single worker and register its live-progress + stop handles. Returns
        (jid, ev) for a queued job, or (None, result) if a defense blocked it
        (in which case generation never happens)."""
        with self.lock:
            self.stats["requests"] += 1
        enq_time = time.time()

        prompt_chars = len(prompt)
        raw_prompt_tokens = len(self.tokenizer.encode(prompt, add_special_tokens=False))
        tok_per_char = round(raw_prompt_tokens / prompt_chars, 3) if prompt_chars else 0.0
        input_meta = {
            "prompt_preview": prompt[:400] + ("..." if len(prompt) > 400 else ""),
            "prompt_chars": prompt_chars,
            "prompt_tokens": raw_prompt_tokens,
            "input_tokens_per_char": tok_per_char,
            "ceiling": self.defense.ceiling,
            "context_window": self.context_window,
        }

        rejected, stage, reason = self._defense_reject(prompt, client_id)
        if rejected:
            with self.lock:
                self.stats["blocked"] += 1
            result = {
                "blocked": True, "stage": stage, "reason": reason,
                "out_tokens": 0, "gen_latency_s": 0.0, "queue_wait_s": 0.0,
                "total_latency_s": round(time.time() - enq_time, 3),
                "capped": False, "killed": False, "stopped_on_eos": False,
                "stopped_by_user": False,
                "pct_of_ceiling": 0.0, "kv_cache_mb": 0.0, "gen_tok_per_s": 0.0,
                "output_text": "", "defense": self.defense.as_dict(),
            }
            result.update(input_meta)
            self._record(kind, prompt, result)
            return None, result

        input_ids = model_utils.build_chat_prompt(
            self.tokenizer, prompt, chat=self.is_chat)
        # Clamp generation to the model's real context window: total tokens
        # (prompt + output) can never exceed max_position_embeddings, so the true
        # maximum output for THIS prompt is (context_window - prompt length).
        prompt_len = int(input_ids.shape[-1])
        room = max(1, self.context_window - prompt_len)
        cap = min(self._effective_cap(requested_max), room)

        jid = uuid.uuid4().hex
        ev = threading.Event()
        stop_event = threading.Event()
        ctx = {"prompt": prompt, "kind": kind, "client_id": client_id,
               "input_meta": input_meta, "prompt_len": prompt_len}
        with self.lock:
            self.job_events[jid] = ev
            self.stop_events[jid] = stop_event
            self.live[jid] = {"jid": jid, "kind": kind, "out_tokens": 0,
                              "text": "", "kv_cache_mb": 0.0, "pct": 0.0,
                              "done": False, "result": None, "cap": cap}
        self.q.put((jid, input_ids, cap, enq_time, stop_event, ctx))
        return jid, ev

    def handle_generate(self, prompt, requested_max=None, kind="adhoc",
                        client_id="demo-client"):
        """Blocking: enqueue and wait for the worker (used by the queue-DoS and
        scripted flows that need a synchronous result)."""
        jid, ev_or_result = self._enqueue(prompt, requested_max, kind, client_id)
        if jid is None:
            return ev_or_result
        ev_or_result.wait()
        with self.lock:
            result = self.results.pop(jid, None)
            self.job_events.pop(jid, None)
            self.live.pop(jid, None)
        return result

    def handle_generate_async(self, prompt, requested_max=None, kind="adhoc",
                              client_id="demo-client"):
        """Non-blocking: enqueue and return a job id the client polls via /live,
        so a long sponge can be watched climbing in real time and stopped."""
        jid, ev_or_result = self._enqueue(prompt, requested_max, kind, client_id)
        if jid is None:
            return {"jid": None, "result": ev_or_result}
        return {"jid": jid}

    def stop_job(self, jid):
        with self.lock:
            ev = self.stop_events.get(jid)
        if ev is not None:
            ev.set()
            return True
        return False

    def get_live(self, jid):
        with self.lock:
            live = self.live.get(jid)
            return dict(live) if live else None

    def pop_live(self, jid):
        with self.lock:
            self.live.pop(jid, None)
            self.job_events.pop(jid, None)
            self.results.pop(jid, None)


# --------------------------------------------------------------------------
# HTTP layer
# --------------------------------------------------------------------------
SERVICE: "ModelService" = None


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, obj):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def log_message(self, *args):
        pass  # keep the console clean for the demo

    def _send_html(self, code, text):
        body = text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path in ("/", "/index.html", "/dashboard"):
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "dashboard.html")
            try:
                with open(path, encoding="utf-8") as f:
                    self._send_html(200, f.read())
            except OSError:
                self._send_html(200, "<h1>dashboard.html not found</h1>")
        elif self.path == "/health":
            self._send(200, {"ok": True, "model": SERVICE.model_name,
                             "model_key": SERVICE.model_key, "chat": SERVICE.is_chat,
                             "device": SERVICE.device_str})
        elif self.path == "/stats":
            self._send(200, {"stats": SERVICE.stats,
                             "defense": SERVICE.defense.as_dict()})
        elif self.path == "/events":
            with SERVICE.lock:
                events = list(SERVICE.log)
                stats = dict(SERVICE.stats)
            self._send(200, {"model": SERVICE.model_name,
                             "model_key": SERVICE.model_key, "chat": SERVICE.is_chat,
                             "model_options": SERVICE.model_options,
                             "context_window": SERVICE.context_window,
                             "device": SERVICE.device_str,
                             "stats": stats, "defense": SERVICE.defense.as_dict(),
                             "events": events})
        elif self.path.startswith("/live"):
            from urllib.parse import urlparse, parse_qs
            jid = parse_qs(urlparse(self.path).query).get("jid", [None])[0]
            live = SERVICE.get_live(jid) if jid else None
            if live is None:
                self._send(404, {"error": "no such job"})
            else:
                self._send(200, live)
                if live.get("done"):     # deliver the final result once, then drop
                    SERVICE.pop_live(jid)
        else:
            self._send(404, {"error": "not found"})

    def do_POST(self):
        if self.path == "/generate":
            data = self._read_json()
            prompt = data.get("prompt", "")
            if not isinstance(prompt, str) or not prompt:
                self._send(400, {"error": "missing 'prompt'"})
                return
            result = SERVICE.handle_generate(
                prompt, data.get("max_new_tokens"), kind=data.get("kind", "adhoc"),
                client_id=data.get("client_id", "demo-client"))
            self._send(200, result)
        elif self.path == "/generate_async":
            data = self._read_json()
            prompt = data.get("prompt", "")
            if not isinstance(prompt, str) or not prompt:
                self._send(400, {"error": "missing 'prompt'"})
                return
            out = SERVICE.handle_generate_async(
                prompt, data.get("max_new_tokens"), kind=data.get("kind", "adhoc"),
                client_id=data.get("client_id", "demo-client"))
            self._send(200, out)
        elif self.path == "/stop":
            data = self._read_json()
            self._send(200, {"stopped": SERVICE.stop_job(data.get("jid"))})
        elif self.path == "/admin/defense":
            data = self._read_json()
            d = SERVICE.defense
            # `enabled` is a bulk convenience (used by the queue before/after):
            # it flips the two always-available robust layers (L1 cap + L2).
            if "enabled" in data:
                val = bool(data["enabled"])
                d.use_l1 = val
                d.use_l2 = val
            for flag in ("use_l1", "use_l2", "use_l3", "use_l4", "use_l6"):
                if flag in data:
                    setattr(d, flag, bool(data[flag]))
            if "use_l5" in data:
                d.use_l5 = bool(data["use_l5"])
                if d.use_l5 and SERVICE.detector is None:
                    SERVICE._fit_detector()
                    if SERVICE.detector is None:      # fit failed -> keep it off
                        d.use_l5 = False
            if "output_cap" in data:
                d.output_cap = max(1, int(data["output_cap"]))
            if "time_budget_s" in data:
                d.time_budget_s = float(data["time_budget_s"])
            if "ceiling" in data:
                d.ceiling = int(data["ceiling"])
            if "repeat_limit" in data:
                d.repeat_limit = max(1, int(data["repeat_limit"]))
            # L4 params: rebuild the limiter so a changed budget takes effect now.
            l4_changed = False
            if "l4_max_requests" in data:
                d.l4_max_requests = max(1, int(data["l4_max_requests"]))
                l4_changed = True
            if "l4_window_s" in data:
                d.l4_window_s = float(data["l4_window_s"])
                l4_changed = True
            if "l4_max_output_tokens" in data:
                v = data["l4_max_output_tokens"]
                d.l4_max_output_tokens = int(v) if v not in (None, "", 0) else None
                l4_changed = True
            # Reset L4's window when it is (re)enabled, so the demo starts clean.
            if data.get("reset_l4") or l4_changed or data.get("use_l4") is True:
                SERVICE._rebuild_rate_limiter()
            self._send(200, {"defense": d.as_dict()})
        elif self.path == "/admin/model":
            data = self._read_json()
            key = data.get("key", "")
            if not key:
                self._send(400, {"error": "missing 'key'"})
                return
            result = SERVICE.handle_switch(key)
            self._send(200 if result.get("ok") else 500, result)
        else:
            self._send(404, {"error": "not found"})


def main():
    global SERVICE
    SERVICE = ModelService()
    host = os.environ.get("DEMO_HOST", "0.0.0.0")
    port = _int_env("DEMO_PORT", 8000)
    httpd = ThreadingHTTPServer((host, port), Handler)
    print(f"[server] listening on http://{host}:{port}", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[server] shutting down.", flush=True)
        httpd.shutdown()


if __name__ == "__main__":
    main()
