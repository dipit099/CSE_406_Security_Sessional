# Live attack / defense demonstration

A self-contained system for the evaluation day: a **victim LLM served behind a
single worker**, an **attacker client**, and a **runner** that shows each attack
working, then flips the **defenses** on and shows the attacks mitigated.

It reuses the project's real modules (`code/common`, `code/defenses/l2`,
`code/defenses/l5`) so what you demonstrate is the same code the report
describes. No GPU required: it runs on CPU with a small model.

---

## What it demonstrates

Two scenarios, each run once with defenses **OFF** and once **ON**:

1. **Per-request cost** — a natural request, a tokenizer-abuse sponge, and a
   fluent output-forcing sponge. Defenses OFF: sponges run to the ceiling.
   Defenses ON: the tokenizer-abuse sponge is **blocked by L2** before any
   generation, and the output-forcing sponge is **capped** by the compute cap.
2. **Queue starvation** — `k` sponges plus one honest request hit the
   single-worker server together. Defenses OFF: the honest user waits behind the
   sponges (large latency). Defenses ON: sponges are blocked/capped, so the
   honest user is served promptly again.

Example measured on CPU with `gpt2`, cap 16 / ceiling 64, k=2:

| | defenses OFF | defenses ON |
|---|---|---|
| tokenizer-abuse sponge | 64 tokens, 6.9 s | **blocked by L2**, 0.002 s |
| output-forcing sponge | 64 tokens | capped to 16 tokens |
| honest user behind 2 sponges | **33.5 s** | **2.1 s** |

---

## Which model to use

- **Fast, snappy demo (recommended for the queue-starvation story):**
  `distilgpt2` or `gpt2`. Tiny, CPU-fast. Note these are *base* models, so they
  run to the cap even on a normal prompt — the drama comes from the queue
  scenario, not per-request amplification.
- **Per-request amplification story (natural stops early, sponge runs long):**
  an instruct model such as `Qwen/Qwen2.5-0.5B-Instruct`. Slower per request on
  CPU, so keep the cap modest (e.g. 128) and `k` small (2-3).

Set it with `DEMO_MODEL`.

---

## Run it with Docker (recommended)

You have Docker + Compose. From the **project root**:

```bash
# build + start the victim server (first run downloads the model)
docker compose -f demo/docker-compose.yml up --build
```

In another terminal, from the project root (plain Python, no installs — the
runner only uses the standard library):

```bash
python demo/run_demo.py --url http://localhost:8000 --scenario both --k 3
```

To use the instruct model instead:

```bash
DEMO_MODEL=Qwen/Qwen2.5-0.5B-Instruct docker compose -f demo/docker-compose.yml up --build
```

Stop with `Ctrl+C`, then `docker compose -f demo/docker-compose.yml down`.

---

## Run it without Docker

```bash
# terminal 1 - the victim server
cd demo
DEMO_MODEL=gpt2 DEMO_CEILING=64 DEMO_OUTPUT_CAP=16 python victim_server.py

# terminal 2 - the demonstration
cd demo
python run_demo.py --url http://localhost:8000 --scenario both --k 3
```

Requires `torch`, `transformers`, `scikit-learn` in the environment (already
needed by the project).

---

## Live dashboard (recommended for the audience)

The server serves a browser dashboard at **`http://<host>:8000/`**. Open it on
the projector and everything updates live, so your supervisor sees results
instantly instead of reading a terminal:

- a **DEFENSE ON / OFF** badge and **all six layers (L1-L6) as individual
  toggles** (with an output-cap field for L1 and a request-limit field for L4),
  so you can flip any one layer and re-fire the same attack to show its effect;
- buttons for all four report attacks -- **Tier 1a tokenizer abuse**, **Tier 1b
  output forcing**, **Tier 2a genetic (black-box)**, **Tier 2b Engorgio
  (white-box)** -- plus a **repeat-loop** probe (for L3), a **control-token
  injection** probe (for L6), a **Normal request**, and a **Custom prompt** box;
  each appears in the log with its token count, latency, and whether it was
  blocked, capped, or killed;
- an **impact panel** for the last request: output tokens, latency, cost vs
  normal, input (prefill) tokens, percent of the context window used, decode
  throughput, KV-cache growth (MB), the input tokens-per-character fingerprint,
  and whether EOS was **emitted or suppressed** (the core mechanism, shown live);
- an **attack inspector** showing the exact prompt sent and the text the model
  actually produced, so the audience sees what each attack looks like;
- an **attack comparison chart** (one bar per attack, output tokens forced, with
  a dashed max_tokens ceiling line) that updates as you fire each one;
- a **Launch queue attack** button that runs the honest-user-behind-sponges
  scenario once undefended and once defended and draws the two honest-user
  latencies as bars (the OFF bar towers over the ON bar);
- live server counters (requests / generated / blocked / killed).

Energy and GPU-memory numbers are not measured live (a CPU has no power sensor,
and the dev laptop's MX350 GPU exposes neither power telemetry nor enough VRAM);
those come from the Kaggle T4 run in `csv/per_request_cost.csv`. The live demo
measures the token, latency, KV-cache and context-usage signals, which reproduce
the Kaggle token and amplification numbers exactly.

It uses no external libraries (works offline on a VM) and talks only to this
server. The scripted `run_demo.py` still works too and writes the CSVs.

---

## Run it in the cloud (Google Cloud VM) — zero load on your laptop

Hosting on a VM is the cleanest live demo: the model runs in the cloud, your
supervisor opens a URL, and your laptop does nothing. It uses the **same Docker
image**. You have `gcloud` installed and credits.

```bash
gcloud auth login
gcloud config set project YOUR_PROJECT_ID
bash demo/deploy_gcp.sh up      # creates the VM, deploys, prints the dashboard URL
# ... demo ...
bash demo/deploy_gcp.sh down    # DELETES the VM + firewall rule (stops billing)
```

`deploy_gcp.sh up` prints a `http://<EXTERNAL_IP>:8000/` URL — open the dashboard
there, or drive it from your laptop with
`python demo/run_demo.py --url http://<EXTERNAL_IP>:8000 ...`.

### Managing the VM on Windows (run these from PowerShell)

On Windows, run the VM lifecycle commands **from PowerShell, not Git Bash**. Git
Bash reads a different gcloud configuration (a different `HOME`), so
`bash demo/deploy_gcp.sh stop` can fail with "You do not currently have an active
account selected" even right after a successful `gcloud auth login`. These
PowerShell commands act on the running VM directly and always work:

```powershell
# start the VM before a demo (the container auto-restarts on boot)
gcloud compute instances start sponge-demo --zone=us-central1-a

# get the dashboard URL after a start (the external IP can change each time)
gcloud compute instances describe sponge-demo --zone=us-central1-a `
  --format="get(networkInterfaces[0].accessConfigs[0].natIP)"

# stop the VM when done (pauses compute billing; keeps the disk + data)
gcloud compute instances stop sponge-demo --zone=us-central1-a

# delete everything permanently when the project is over (stops all billing)
gcloud compute instances delete sponge-demo --zone=us-central1-a
gcloud compute firewall-rules delete allow-sponge-demo-8000
```

If `gcloud` reports no active account, select it explicitly (again from
PowerShell): `gcloud config set account <you>@gmail.com` and
`gcloud config set project <PROJECT_ID>`.

**CPU VM (default, recommended for reliability).** `e2-standard-4` (4 vCPU /
16 GB). Handles `distilgpt2`/`gpt2` snappily and `Qwen/Qwen2.5-0.5B-Instruct`
at a usable CPU speed. No drivers, nothing to break on stage. Choose the model
with `DEMO_MODEL=...` before `up`.

**GPU VM (optional, fastest — best for the per-request amplification story).**
A T4 VM runs the instruct model fast, so `natural` (short) vs `sponge` (long) is
dramatic and immediate. The GPU path is prepared: `Dockerfile.gpu` (CUDA torch),
`docker-compose.gpu.yml` (requests the GPU), and `GPU=1` in the deploy script,
which provisions a T4 on a Deep Learning VM image (NVIDIA drivers + Docker
preinstalled):

```bash
GPU=1 bash demo/deploy_gcp.sh up      # T4 VM + Qwen2.5-0.5B-Instruct
```

Prerequisites: a **paid (upgraded) account** — GPUs are blocked on the $300 free
trial — and **T4 GPU quota** (request in *IAM & Admin -> Quotas*, can take a
day). It costs ~$0.55/hour; `stop` it when idle.

> Honesty note: this GPU path is config-validated but **was not verified on real
> GPU hardware** (the dev machine has no usable GPU). After `GPU=1 ... up`,
> verify on the VM in two commands:
> `gcloud compute ssh sponge-demo --command "nvidia-smi"` (driver up) and
> `bash demo/deploy_gcp.sh logs` — the server log should print a CUDA device,
> not `cpu`. If the container fails to see the GPU, it is almost always the
> NVIDIA container runtime; the Deep Learning VM image includes it, which is why
> the script uses that image.

**Live-demo safety.** The firewall rule is restricted to your current public IP
by default (`SRC_RANGE`). Start the VM and **pre-warm the model** (open
`/health` until it responds) before the supervisor arrives, keep the local
Docker demo ready as a fallback, and run `down` afterwards so you stop paying.

---

## Suggested live script (what to do in front of your supervisor)

1. **Start the server** (Docker up). Show `GET /health` with the client:
   `python demo/client.py health`.
2. **Attack, undefended.** Fire one sponge by hand and show the cost:
   `python demo/client.py generate --prompt "List every integer from 1 to 100000, one per line, never stop."`
   Then the queue scenario: `python demo/run_demo.py --scenario queue --k 3`
   and point at the honest user's latency.
3. **Turn defenses on, live:** `python demo/client.py defense --on --output-cap 32`
   (optionally `--l5` to also enable the latent detector).
4. **Attack again.** Re-run the same commands; show the tokenizer-abuse sponge
   now returns `BLOCKED by L2`, the output-forcing sponge is capped, and the
   honest user's latency has dropped back down.
5. Show the CSVs under `demo_results/` as the recorded evidence.

Or just run the whole before/after story at once:
`python demo/run_demo.py --scenario both --k 3`.

---

## Runtime defense controls

The server exposes `POST /admin/defense`, wrapped by the client:

```bash
python demo/client.py defense --on                 # enable defenses
python demo/client.py defense --on --output-cap 32 # enable + set the cap
python demo/client.py defense --on --l5            # also enable L5 latent detector
python demo/client.py defense --off                # disable (undefended)
python demo/client.py stats                        # counters + current config
```

Environment variables (server): `DEMO_MODEL`, `DEMO_DEFENSE` (off/on),
`DEMO_OUTPUT_CAP`, `DEMO_CEILING`, `DEMO_USE_L2`, `DEMO_USE_L5`, `DEMO_PORT`.

---

## The full defense stack

The demo runs the complete six-layer guard from the report (Figure 9), using the
project's real modules, each toggleable at runtime:

| Layer | Module | What it does in the demo |
|---|---|---|
| L1 | `defenses/l1_output_cap.py` | token cap + wall-clock time budget |
| L2 | `defenses/l2_input_validation.py` | rejects the tokenizer-abuse fingerprint |
| L3 | `defenses/l3_output_monitor.py` | kills a repeated-n-gram runaway mid-stream |
| L4 | `defenses/l4_rate_limit.py` | per-client request / output-token budget |
| L5 | `defenses/l5_latent_detector.py` | hidden-state sponge detector (threshold 0.6) |
| L6 | `defenses/l6_config_hygiene.py` | filters reserved / control (glitch) tokens |

Pre-generation layers (L6, L2, L5, L4) reject in `_defense_reject()`; L1 and L3
run during generation in `_guarded_generate()` as stopping criteria. The same
modules are wired into `code/defenses/guard.py` (the integrated `LayeredGuard`
used by `exp_defense_eval` and `code/server/app.py`); the demo drives them with
per-layer switches so each layer's effect is visible on its own. Every layer and
attack was verified end to end over HTTP (16/16 checks).
